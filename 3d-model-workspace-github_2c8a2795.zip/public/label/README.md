# Output Folder

This folder contains all saved labels and generated images from GlowStudio.

## Structure

```
output/
├── label-1234567890-abc123.png    # Saved label images
├── label-1234567891-def456.png    # More saved labels
└── ...
```

## Naming Convention

Files are named with the format:
```
{type}-{timestamp}-{random-id}.png
```

- `type`: The type of image (e.g., "label")
- `timestamp`: Unix timestamp in milliseconds
- `random-id`: Random 9-character string to ensure uniqueness

## Usage

### Labels
When you create a label using the Label Editor:
1. Draw or upload an image
2. Click "Save Label"
3. The image is saved to this folder
4. The label appears in the Labels panel

### Accessing Files
- Files are served at `/output/{filename}`
- You can directly access any file via URL
- Files persist across sessions

## Storage

- Files are stored in `public/output/` directory
- They are accessible via `/output/` URL path
- Files are stored locally on the server

## Backup

To backup your labels:
1. Copy the entire `public/output/` folder
2. Or download individual labels from the Labels panel

## Cleanup

To remove old labels:
1. Delete files directly from this folder
2. Or use the Delete button in the Labels panel
