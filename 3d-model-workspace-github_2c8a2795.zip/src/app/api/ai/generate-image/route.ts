import { NextRequest, NextResponse } from 'next/server';
import { ImageGenerationClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const { prompt, size } = await request.json();

    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      );
    }

    // Extract headers from request for proper forwarding
    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);

    // Initialize the image generation client
    const config = new Config();
    const client = new ImageGenerationClient(config, customHeaders);

    // Generate image
    const response = await client.generate({
      prompt,
      size: size || '2K',
      watermark: false,
    });

    const helper = client.getResponseHelper(response);

    if (helper.success && helper.imageUrls.length > 0) {
      // Download the image and convert to base64 to avoid CORS issues
      const imageUrl = helper.imageUrls[0];
      
      const imageResponse = await fetch(imageUrl);
      if (!imageResponse.ok) {
        throw new Error('Failed to download generated image');
      }
      
      const arrayBuffer = await imageResponse.arrayBuffer();
      const base64 = Buffer.from(arrayBuffer).toString('base64');
      const contentType = imageResponse.headers.get('content-type') || 'image/png';
      const dataUrl = `data:${contentType};base64,${base64}`;
      
      return NextResponse.json({
        success: true,
        imageUrl: dataUrl,
        originalUrl: helper.imageUrls[0],
      });
    } else {
      return NextResponse.json(
        { error: helper.errorMessages.join(', ') || 'Image generation failed' },
        { status: 500 }
      );
    }
  } catch (error) {
    console.error('AI image generation error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json(
      { error: `Failed to generate image: ${errorMessage}` },
      { status: 500 }
    );
  }
}
