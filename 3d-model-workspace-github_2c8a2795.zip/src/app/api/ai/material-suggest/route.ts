import { NextRequest, NextResponse } from 'next/server';
import { LLMClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';

interface MaterialSuggestion {
  name: string;
  type: 'matte' | 'glossy' | 'metallic' | 'shiny' | 'satin' | 'pearl' | 'chrome' | 'ceramic' | 'glass' | 'rubber';
  reason: string;
  presetIndex: number; // Maps to existing COSMETIC_PRESETS
}

export async function POST(request: NextRequest) {
  try {
    const { modelName, modelDescription } = await request.json();
    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);

    const config = new Config();
    const client = new LLMClient(config);

    const systemPrompt = `You are a professional material and texture expert for 3D beauty/cosmetic product visualization. 
Given a product description, suggest the most realistic and visually appealing material finishes.

You must respond with a JSON array of exactly 3-4 material suggestions. Each suggestion must have:
- "name": short display name (e.g., "Soft Matte", "Rose Gold Metallic")
- "type": one of: matte, glossy, metallic, shiny, satin, pearl, chrome, ceramic, glass, rubber
- "reason": one-line explanation why this fits
- "presetIndex": number 0-17 (maps to our cosmetic presets)

Available preset indices:
0=Matte Nude, 1=Shiny Pink, 2=Glossy Coral, 3=Metallic Rose Gold, 4=Pearly White,
5=Ceramic White, 6=Chrome Silver, 7=Rubber Black, 8=Satin Beige, 9=Glossy Red,
10=Metallic Gold, 11=Frosted Glass, 12=Velvet Purple, 13=Cream Matte, 14=Bronze Shimmer,
15=Crystal Clear, 16=Soft Peach, 17=Midnight Blue

Rules for beauty/cosmetic products:
- Lipstick/lip gloss → glossy or satin
- Perfume bottle → glass or metallic (cap)
- Cream/jar → matte or ceramic
- Compact powder → metallic or pearl
- Nail polish → glossy or shiny
- Skincare bottle → matte or satin
- Luxury packaging → metallic gold/rose gold or chrome

Respond ONLY with valid JSON array, no markdown, no explanation.`;

    const userPrompt = modelName || modelDescription
      ? `Suggest realistic material finishes for this beauty product: ${modelName || ''} ${modelDescription || ''}`
      : 'Suggest realistic material finishes for a generic beauty/cosmetic product. Give me 3 diverse options covering different styles (matte, metallic, glossy).';

    const messages: { role: 'system' | 'user'; content: string }[] = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ];

    const response = await client.invoke(messages, {
      model: 'doubao-seed-2-0-mini-260215',
      temperature: 0.6,
    });

    // Parse LLM response as JSON
    let suggestions: MaterialSuggestion[];
    try {
      // Try to extract JSON from response (handle potential markdown wrapping)
      let content = response.content.trim();
      if (content.startsWith('```')) {
        content = content.replace(/```json\n?|\n?```/g, '');
      }
      suggestions = JSON.parse(content);
    } catch {
      // Fallback defaults if parsing fails
      suggestions = [
        { name: 'Soft Matte', type: 'matte', reason: 'Natural, elegant finish for everyday wear', presetIndex: 0 },
        { name: 'Rose Gold Metallic', type: 'metallic', reason: 'Luxurious premium look for high-end products', presetIndex: 3 },
        { name: 'Glossy Finish', type: 'glossy', reason: 'Vibrant, eye-catching for bold statements', presetIndex: 2 },
      ];
    }

    // Validate and sanitize
    suggestions = suggestions.slice(0, 4).map((s: MaterialSuggestion) => ({
      name: s.name || 'Custom',
      type: ['matte','glossy','metallic','shiny','satin','pearl','chrome','ceramic','glass','rubber'].includes(s.type) ? s.type : 'matte',
      reason: s.reason || '',
      presetIndex: typeof s.presetIndex === 'number' && s.presetIndex >= 0 && s.presetIndex <= 17 ? s.presetIndex : 0,
    }));

    return NextResponse.json({ success: true, suggestions });
  } catch (error: unknown) {
    console.error('AI Material Suggest Error:', error);
    
    // Return fallback suggestions on error
    return NextResponse.json({
      success: true,
      suggestions: [
        { name: 'Soft Matte', type: 'matte', reason: 'Natural, elegant finish', presetIndex: 0 },
        { name: 'Metallic Gold', type: 'metallic', reason: 'Premium luxury look', presetIndex: 10 },
        { name: 'Glossy Coral', type: 'glossy', reason: 'Vibrant and fresh', presetIndex: 2 },
      ],
    });
  }
}
