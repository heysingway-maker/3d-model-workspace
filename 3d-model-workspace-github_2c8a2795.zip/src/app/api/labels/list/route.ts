import { NextResponse } from 'next/server';
import { readdir, stat } from 'fs/promises';
import path from 'path';

export async function GET() {
  try {
    const outputDir = path.join(process.cwd(), 'public', 'Label_Save');
    
    let files: string[] = [];
    try {
      files = await readdir(outputDir);
    } catch (e) {
      // Directory doesn't exist yet
      return NextResponse.json({ labels: [] });
    }

    // Filter PNG files and get their info
    const labels = await Promise.all(
      files
        .filter(f => f.endsWith('.png'))
        .map(async (filename) => {
          const filePath = path.join(outputDir, filename);
          const fileStat = await stat(filePath);
          
          // Extract date and sequence from filename
          // Format: Label-YYYYMMDD-NNN.png
          const match = filename.match(/Label-(\d{8})-(\d{3})\.png$/);
          const name = match 
            ? `Label ${match[1].slice(0, 4)}-${match[1].slice(4, 6)}-${match[1].slice(6, 8)} #${parseInt(match[2], 10)}`
            : filename.replace('.png', '');

          return {
            id: `file-${filename}`,
            name,
            imageData: `/Label_Save/${filename}`,
            createdAt: fileStat.birthtimeMs || fileStat.mtimeMs,
          };
        })
    );

    // Sort by creation time (newest first)
    labels.sort((a, b) => b.createdAt - a.createdAt);

    return NextResponse.json({ labels });
  } catch (error) {
    console.error('Error reading labels:', error);
    return NextResponse.json(
      { error: 'Failed to read labels' },
      { status: 500 }
    );
  }
}
