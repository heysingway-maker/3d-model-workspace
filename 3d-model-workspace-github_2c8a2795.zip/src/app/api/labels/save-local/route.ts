import { NextRequest, NextResponse } from 'next/server';
import { writeFile, mkdir, readdir } from 'fs/promises';
import path from 'path';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { imageData } = body;

    if (!imageData) {
      return NextResponse.json(
        { error: 'No image data provided' },
        { status: 400 }
      );
    }

    // Extract base64 data from data URL
    const base64Data = imageData.replace(/^data:image\/\w+;base64,/, '');
    const buffer = Buffer.from(base64Data, 'base64');

    // Create Label_Save directory if it doesn't exist
    const outputDir = path.join(process.cwd(), 'public', 'Label_Save');
    try {
      await mkdir(outputDir, { recursive: true });
    } catch (e) {
      // Directory might already exist
    }

    // Generate filename with format: Label-YYYYMMDD-NNN
    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10).replace(/-/g, ''); // YYYYMMDD
    const prefix = `Label-${dateStr}`;

    // Get existing files to determine sequence number
    let sequence = 1;
    try {
      const files = await readdir(outputDir);
      // Filter files that match today's prefix pattern
      const todayFiles = files.filter(f => f.startsWith(prefix));
      if (todayFiles.length > 0) {
        // Extract sequence numbers and find max
        const sequences = todayFiles.map(f => {
          const match = f.match(/Label-\d{8}-(\d{3})\.png$/);
          return match ? parseInt(match[1], 10) : 0;
        });
        const maxSeq = Math.max(...sequences, 0);
        sequence = maxSeq + 1;
      }
    } catch (e) {
      // Directory might not exist or be empty
    }

    // Format sequence as 3-digit number (001, 002, etc.)
    const sequenceStr = sequence.toString().padStart(3, '0');
    const filename = `${prefix}-${sequenceStr}.png`;

    // Save file to public/Label_Save directory
    const filePath = path.join(outputDir, filename);
    await writeFile(filePath, buffer);

    // Return public URL path
    const publicUrl = `/Label_Save/${filename}`;

    console.log('✅ Label saved to:', publicUrl);

    return NextResponse.json({
      success: true,
      url: publicUrl,
      filename,
      path: filePath,
    });
  } catch (error) {
    console.error('Error saving label:', error);
    return NextResponse.json(
      { error: 'Failed to save label' },
      { status: 500 }
    );
  }
}
