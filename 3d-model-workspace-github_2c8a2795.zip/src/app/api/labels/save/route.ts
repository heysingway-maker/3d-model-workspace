import { NextRequest, NextResponse } from 'next/server';
import { S3Storage } from 'coze-coding-dev-sdk';

// Initialize S3Storage
const getStorage = () => {
  return new S3Storage({
    endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
    accessKey: '',
    secretKey: '',
    bucketName: process.env.COZE_BUCKET_NAME,
    region: 'cn-beijing',
  });
};

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return NextResponse.json(
        { error: 'No file provided' },
        { status: 400 }
      );
    }

    // Convert File to Buffer
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // Generate unique filename
    const filename = `labels/label-${Date.now()}-${Math.random().toString(36).substr(2, 9)}.png`;

    // Upload to S3 storage
    const storage = getStorage();
    const url = await storage.uploadFile({
      fileContent: buffer,
      fileName: filename,
      contentType: 'image/png',
    });

    return NextResponse.json({
      success: true,
      url,
      filename,
    });
  } catch (error) {
    console.error('Error saving label texture:', error);
    return NextResponse.json(
      { error: 'Failed to save label texture' },
      { status: 500 }
    );
  }
}
