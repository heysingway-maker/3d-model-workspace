import { NextRequest, NextResponse } from 'next/server';
import { S3Storage } from 'coze-coding-dev-sdk';
import * as fs from 'fs';
import * as path from 'path';

// API 配置
const MESHY_API_KEY = process.env.MESHY_API_KEY || '';
const MESHY_API_BASE = 'https://api.meshy.ai';
const TRIPO_API_KEY = process.env.TRIPO_API_KEY || '';
const TRIPO_API_BASE = 'https://api.tripo3d.ai/v2/openapi';

// 本地存储路径
const LOCAL_MODEL_DIR = path.join(process.cwd(), 'public', '3D_Make_Save');

// 确保本地目录存在
if (!fs.existsSync(LOCAL_MODEL_DIR)) {
  fs.mkdirSync(LOCAL_MODEL_DIR, { recursive: true });
}

// 初始化对象存储
const storage = new S3Storage({
  endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
  accessKey: "",
  secretKey: "",
  bucketName: process.env.COZE_BUCKET_NAME,
  region: "cn-beijing",
});

// 缓存已完成的任务
const taskResultCache = new Map<string, {
  modelKey: string;
  previewImageUrl: string | null;
  timestamp: number;
}>();

// 存储锁
const storingTasks = new Map<string, Promise<{
  success: boolean;
  modelKey?: string;
  error?: string;
  previewImageUrl?: string | null;
}>>();

export const maxDuration = 300;

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ taskId: string }> }
) {
  try {
    const { taskId } = await params;
    const url = new URL(request.url);
    const provider = url.searchParams.get('provider') || 'meshy';

    console.log(`[Make3D] Checking task: ${taskId}, provider: ${provider}`);

    // 演示模式
    if (provider === 'demo' || taskId.startsWith('demo_')) {
      return await checkDemoTask(taskId);
    }

    if (provider === 'meshy') {
      return await checkMeshyTask(taskId);
    } else if (provider === 'tripo') {
      return await checkTripoTask(taskId);
    }

    return NextResponse.json({ error: `Unknown provider: ${provider}` }, { status: 400 });

  } catch (error) {
    console.error('[Make3D] Error:', error);
    return NextResponse.json(
      { error: 'Failed to check task: ' + (error instanceof Error ? error.message : String(error)) },
      { status: 500 }
    );
  }
}

// 演示模式：返回随机预置模型
async function checkDemoTask(taskId: string) {
  // 模拟延迟
  const elapsed = Date.now() - parseInt(taskId.replace('demo_', ''));
  const progress = Math.min(100, Math.floor(elapsed / 100)); // 约 10 秒完成
  
  if (progress < 100) {
    return NextResponse.json({
      status: 'processing',
      progress: progress,
      message: 'Demo mode: Generating sample model...',
    });
  }

  // 返回随机预置模型
  const demoModels = [
    'https://modelviewer.dev/shared-assets/models/Astronaut.glb',
    'https://modelviewer.dev/shared-assets/models/RobotExpressive.glb',
    'https://threejs.org/examples/models/gltf/DamagedHelmet/glTF/DamagedHelmet.gltf',
  ];
  
  const randomModel = demoModels[Math.floor(Math.random() * demoModels.length)];
  
  console.log('[Make3D] Demo mode: Returning sample model:', randomModel);
  
  return NextResponse.json({
    status: 'succeeded',
    modelUrl: randomModel,
    previewImageUrl: null,
    progress: 100,
    isDemo: true,
    message: 'Demo mode: This is a sample model. Configure MESHY_API_KEY for real AI generation.',
  });
}

async function checkMeshyTask(taskId: string) {
  if (!MESHY_API_KEY) {
    return NextResponse.json({ error: 'Meshy API Key not configured' }, { status: 500 });
  }

  // 获取当前域名
  const baseUrl = process.env.COZE_PROJECT_DOMAIN_DEFAULT || 'http://localhost:5000';

  // 1. 检查缓存
  const cached = taskResultCache.get(taskId);
  if (cached?.modelKey) {
    console.log('[Meshy] ✅ Using cached model');
    // 返回本地可访问的 URL
    const modelUrl = `${baseUrl}/3D_Make_Save/${cached.modelKey}`;
    return NextResponse.json({
      status: 'succeeded',
      modelUrl,
      previewImageUrl: cached.previewImageUrl,
      progress: 100,
    });
  }

  // 2. 检查是否正在存储
  const ongoingStorage = storingTasks.get(taskId);
  if (ongoingStorage) {
    console.log('[Meshy] ⏳ Storage in progress...');
    const result = await ongoingStorage;
    
    if (result.success && result.modelKey) {
      // 返回本地可访问的 URL
      const modelUrl = `${baseUrl}/3D_Make_Save/${result.modelKey}`;
      return NextResponse.json({
        status: 'succeeded',
        modelUrl,
        previewImageUrl: result.previewImageUrl,
        progress: 100,
      });
    } else {
      return NextResponse.json({
        status: 'failed',
        progress: 100,
        message: result.error || 'Storage failed',
      });
    }
  }

  // 3. 查询 Meshy API
  console.log('[Meshy] Querying API...');
  
  // 使用 image-to-3d 查询端点
  const response = await fetch(`${MESHY_API_BASE}/openapi/v1/image-to-3d/${taskId}`, {
    method: 'GET',
    headers: { 'Authorization': `Bearer ${MESHY_API_KEY}` },
  });

  const data = await response.json();
  
  console.log('[Meshy] Response status:', response.status);

  if (!response.ok) {
    console.error('[Meshy] API error:', data);
    return NextResponse.json(
      { error: data.message || data.error || `API error: ${response.status}` },
      { status: response.status }
    );
  }

  // Meshy AI 状态映射
  const status = data.status;
  const progress = data.progress || 0;
  
  console.log(`[Meshy] Status: ${status}, Progress: ${progress}%`);
  console.log(`[Meshy] Task type: ${data.type}`);

  let mappedStatus: string;
  
  switch (status) {
    case 'SUCCEEDED':
      mappedStatus = 'succeeded';
      break;
    case 'FAILED':
      mappedStatus = 'failed';
      break;
    case 'IN_PROGRESS':
    case 'PENDING':
    default:
      mappedStatus = 'processing';
  }

  if (mappedStatus === 'failed') {
    const errorMsg = data.task_error || data.error || data.message || 'Task failed';
    return NextResponse.json({ status: 'failed', progress: 0, message: errorMsg });
  }

  if (mappedStatus === 'succeeded') {
    // Meshy 返回的字段可能是 model_url 或 model_urls
    const modelUrl = data.model_url || data.model_urls?.glb || data.model_urls?.obj;
    const thumbnailUrl = data.thumbnail_url;
    
    if (!modelUrl) {
      console.error('[Meshy] No model URL in response:', JSON.stringify(data).substring(0, 500));
      return NextResponse.json({ status: 'failed', progress: 0, message: 'No model URL in response' });
    }

    console.log('[Meshy] ✅ Model ready, storing...');

    const storagePromise = storeModel(taskId, modelUrl, thumbnailUrl);
    storingTasks.set(taskId, storagePromise);

    const result = await storagePromise;
    storingTasks.delete(taskId);

    if (result.success && result.modelKey) {
      const baseUrl = process.env.COZE_PROJECT_DOMAIN_DEFAULT || 'http://localhost:5000';
      const finalUrl = `${baseUrl}/3D_Make_Save/${result.modelKey}`;
      return NextResponse.json({
        status: 'succeeded',
        modelUrl: finalUrl,
        previewImageUrl: result.previewImageUrl,
        progress: 100,
      });
    } else {
      return NextResponse.json({
        status: 'failed',
        progress: 100,
        message: result.error || 'Storage failed',
      });
    }
  }

  return NextResponse.json({ 
    status: mappedStatus, 
    progress: progress || 50, 
    message: '' 
  });
}

async function checkTripoTask(taskId: string) {
  if (!TRIPO_API_KEY) {
    return NextResponse.json({ error: 'Tripo API Key not configured' }, { status: 500 });
  }

  const baseUrl = process.env.COZE_PROJECT_DOMAIN_DEFAULT || 'http://localhost:5000';

  // 1. 检查缓存
  const cached = taskResultCache.get(taskId);
  if (cached?.modelKey) {
    console.log('[Tripo] ✅ Using cached model');
    const modelUrl = `${baseUrl}/3D_Make_Save/${cached.modelKey}`;
    return NextResponse.json({
      status: 'succeeded',
      modelUrl,
      previewImageUrl: cached.previewImageUrl,
      progress: 100,
    });
  }

  // 2. 检查是否正在存储
  const ongoingStorage = storingTasks.get(taskId);
  if (ongoingStorage) {
    console.log('[Tripo] ⏳ Storage in progress...');
    const result = await ongoingStorage;
    
    if (result.success && result.modelKey) {
      const modelUrl = `${baseUrl}/3D_Make_Save/${result.modelKey}`;
      return NextResponse.json({
        status: 'succeeded',
        modelUrl,
        previewImageUrl: result.previewImageUrl,
        progress: 100,
      });
    } else {
      return NextResponse.json({
        status: 'failed',
        progress: 100,
        message: result.error || 'Storage failed',
      });
    }
  }

  // 3. 查询 Tripo API
  console.log('[Tripo] Querying API...');
  
  const response = await fetch(`${TRIPO_API_BASE}/task/${taskId}`, {
    method: 'GET',
    headers: { 'Authorization': `Bearer ${TRIPO_API_KEY}` },
  });

  const data = await response.json();
  
  console.log('[Tripo] Response status:', response.status);

  // Tripo API 返回格式: { code: 0, data: { status: "...", ... } }
  if (data.code !== 0) {
    console.error('[Tripo] API error:', data);
    return NextResponse.json(
      { error: data.message || `API error: ${data.code}` },
      { status: 400 }
    );
  }

  const taskData = data.data;
  const status = taskData.status;
  const progress = taskData.progress || 0;
  
  console.log(`[Tripo] Status: ${status}, Progress: ${progress}%`);

  // Tripo 状态映射
  let mappedStatus: string;
  
  switch (status) {
    case 'success':
      mappedStatus = 'succeeded';
      break;
    case 'failed':
    case 'banned':
    case 'expired':
    case 'cancelled':
    case 'unknown':
      mappedStatus = 'failed';
      break;
    case 'running':
    case 'queued':
    default:
      mappedStatus = 'processing';
  }

  if (mappedStatus === 'failed') {
    const errorMsg = taskData.error || `Task ${status}`;
    return NextResponse.json({ status: 'failed', progress: 0, message: errorMsg });
  }

  if (mappedStatus === 'succeeded') {
    const output = taskData.output || {};
    const modelUrl = output.pbr_model || output.model;
    const renderedImage = output.rendered_image;
    
    if (!modelUrl) {
      return NextResponse.json({ status: 'failed', progress: 0, message: 'No model URL in response' });
    }

    const storagePromise = storeModel(taskId, modelUrl, renderedImage);
    storingTasks.set(taskId, storagePromise);

    const result = await storagePromise;
    storingTasks.delete(taskId);

    if (result.success && result.modelKey) {
      const tripoFinalUrl = `${baseUrl}/3D_Make_Save/${result.modelKey}`;
      return NextResponse.json({
        status: 'succeeded',
        modelUrl: tripoFinalUrl,
        previewImageUrl: result.previewImageUrl,
        progress: 100,
      });
    } else {
      return NextResponse.json({
        status: 'failed',
        progress: 100,
        message: result.error || 'Storage failed',
      });
    }
  }

  return NextResponse.json({ status: mappedStatus, progress, message: '' });
}

// 存储模型到本地和对象存储
async function storeModel(taskId: string, modelUrl: string, previewImageUrl: string | null) {
  console.log('[Make3D] 📥 Downloading model...');
  
  try {
    const response = await fetch(modelUrl, {
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; GlowStudio/1.0)' },
    });

    if (!response.ok) {
      return { success: false, error: `Download failed: HTTP ${response.status}` };
    }

    const buffer = Buffer.from(await response.arrayBuffer());
    console.log(`[Make3D] Downloaded: ${(buffer.length / 1024 / 1024).toFixed(2)} MB`);

    if (buffer.length === 0) {
      return { success: false, error: 'Model is empty' };
    }

    // 1. 保存到本地 public/3D_Make_Save 目录
    // Detect actual format from URL (Tripo may return .fbx, .glb, or .gltf)
    const urlPath = new URL(modelUrl).pathname;
    const extMatch = urlPath.match(/\.(glb|gltf|fbx|obj)(\?|$)/i);
    const detectedExt = extMatch ? extMatch[1].toLowerCase() : 'glb';
    console.log(`[Make3D] Detected model format from URL: ${detectedExt}`);
    
    const localFileName = `${taskId}.${detectedExt}`;
    const localFilePath = path.join(LOCAL_MODEL_DIR, localFileName);
    
    console.log('[Make3D] 📤 Saving to local:', localFilePath);
    fs.writeFileSync(localFilePath, buffer);
    console.log('[Make3D] ✅ Saved to local:', localFileName);

    // 2. 同时上传到对象存储（用于永久保存和分享）
    console.log('[Make3D] 📤 Uploading to cloud storage...');
    const modelKey = await storage.uploadFile({
      fileContent: buffer,
      fileName: `make3d-models/${taskId}.glb`,
      contentType: 'model/gltf-binary',
    });

    console.log('[Make3D] ✅ Stored to cloud:', modelKey);

    // 返回本地路径作为 modelKey（前端可以直接访问）
    taskResultCache.set(taskId, { modelKey: localFileName, previewImageUrl, timestamp: Date.now() });

    return { success: true, modelKey: localFileName, previewImageUrl };
    
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : 'Unknown error';
    console.error('[Make3D] ⚠️ Error:', errorMsg);
    return { success: false, error: errorMsg };
  }
}
