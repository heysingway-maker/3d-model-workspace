import { NextRequest, NextResponse } from 'next/server';
import { S3Storage } from 'coze-coding-dev-sdk';

// API 配置
const MESHY_API_KEY = process.env.MESHY_API_KEY || '';
const MESHY_API_BASE = 'https://api.meshy.ai';

// 备用：腾讯混元 3D
const HUNYUAN_API_KEY = process.env.HUNYUAN_3D_API_KEY || '';

// 备用：Tripo AI
const TRIPO_API_KEY = process.env.TRIPO_API_KEY || '';
const TRIPO_API_BASE = 'https://api.tripo3d.ai/v2/openapi';

// 初始化对象存储（用于上传图片）
function getStorage(): S3Storage {
  return new S3Storage({
    endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
    accessKey: "",
    secretKey: "",
    bucketName: process.env.COZE_BUCKET_NAME,
    region: "cn-beijing",
  });
}

export const maxDuration = 60;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { image, prompt, style } = body;

    if (!image) {
      return NextResponse.json(
        { error: 'Image is required' },
        { status: 400 }
      );
    }

    console.log('[Make3D] Starting 3D generation task...');
    console.log('[Make3D] Available APIs:', {
      meshy: !!MESHY_API_KEY,
      hunyuan: !!HUNYUAN_API_KEY,
      tripo: !!TRIPO_API_KEY,
    });

    // 优先使用 Meshy AI (image-to-3d 端点)
    if (MESHY_API_KEY) {
      try {
        return await createMeshyTask(image, prompt, style);
      } catch (error) {
        console.error('[Meshy] Error:', error);
        // 如果 Meshy 失败，尝试其他 API
      }
    }

    // 备用：Tripo AI
    if (TRIPO_API_KEY) {
      try {
        return await createTripoTask(image, prompt, style);
      } catch (error) {
        console.error('[Tripo] Error:', error);
      }
    }

    // 演示模式：返回预置模型
    console.log('[Make3D] No valid API, using demo mode');
    return NextResponse.json({
      success: true,
      taskId: `demo_${Date.now()}`,
      provider: 'demo',
      message: 'Demo mode: Using sample 3D model. Configure MESHY_API_KEY or TRIPO_API_KEY for real generation.',
    });

  } catch (error) {
    console.error('[Make3D] Error:', error);
    return NextResponse.json(
      { error: 'Failed to create 3D task: ' + (error instanceof Error ? error.message : String(error)) },
      { status: 500 }
    );
  }
}

async function createMeshyTask(image: string, prompt?: string, style?: string) {
  console.log('[Meshy] Starting image-to-3d task...');

  // 上传图片到存储获取 URL
  const imageUrl = await uploadImage(image, 'meshy');

  console.log('[Meshy] Using image URL:', imageUrl);
  console.log('[Meshy] Calling Meshy Image-to-3D API...');

  // Meshy AI Image-to-3D API
  // 文档: https://docs.meshy.ai/en/api/image-to-3d
  // 端点: POST /openapi/v1/image-to-3d
  const requestBody: Record<string, unknown> = {
    image_url: imageUrl,
    mode: 'preview',
    ai_model: 'meshy-6',
    topology: 'quad',
    should_remesh: true,
    should_texture: true,
  };

  if (prompt && prompt.trim()) {
    requestBody.prompt = prompt.trim();
  }

  const response = await fetch(`${MESHY_API_BASE}/openapi/v1/image-to-3d`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${MESHY_API_KEY}`,
    },
    body: JSON.stringify(requestBody),
  });

  const data = await response.json();

  console.log('[Meshy] Response status:', response.status);
  console.log('[Meshy] Response:', JSON.stringify(data).substring(0, 300));

  if (!response.ok) {
    const errorMsg = data.message || data.error || `API error: ${response.status}`;
    console.error('[Meshy] API error:', errorMsg);
    throw new Error(`Meshy API error: ${errorMsg}`);
  }

  const taskId = data.result;

  if (!taskId) {
    throw new Error('No task_id returned from Meshy API');
  }

  console.log(`[Meshy] ✅ Task created: ${taskId}`);

  return NextResponse.json({
    success: true,
    taskId: taskId,
    provider: 'meshy',
  });
}

async function createTripoTask(image: string, prompt?: string, style?: string) {
  console.log('[Tripo] Starting image_to_model task...');

  // 上传图片到存储获取 URL
  const imageUrl = await uploadImage(image, 'tripo');
  const imageType = image.includes('image/png') ? 'png' :
                    image.includes('image/webp') ? 'webp' : 'jpg';

  console.log('[Tripo] Using image URL:', imageUrl);
  console.log('[Tripo] Calling Tripo API...');

  const requestBody = {
    type: 'image_to_model',
    file: {
      type: imageType,
      url: imageUrl,
    },
    model_version: 'v2.5-20250123',
    pbr: true,
    texture: true,
  };

  const response = await fetch(`${TRIPO_API_BASE}/task`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${TRIPO_API_KEY}`,
    },
    body: JSON.stringify(requestBody),
  });

  const data = await response.json();

  console.log('[Tripo] Response status:', response.status);

  if (data.code !== 0) {
    const errorMsg = data.message || `API error: ${data.code}`;
    console.error('[Tripo] API error:', errorMsg);
    throw new Error(`Tripo API error: ${errorMsg}`);
  }

  const taskId = data.data?.task_id;

  if (!taskId) {
    throw new Error('No task_id returned from Tripo API');
  }

  console.log(`[Tripo] ✅ Task created: ${taskId}`);

  return NextResponse.json({
    success: true,
    taskId: taskId,
    provider: 'tripo',
  });
}

/**
 * 上传图片到对象存储并返回签名 URL
 * Meshy/Tripo API 需要可公开访问的图片 URL，不支持直接传 base64
 */
async function uploadImage(image: string, provider: string): Promise<string> {
  // 如果已经是 URL，直接返回
  if (!image.startsWith('data:image/')) {
    return image;
  }

  const storage = getStorage();

  const imageType = image.includes('image/png') ? 'png' :
                    image.includes('image/webp') ? 'webp' : 'jpg';

  const base64Data = image.split(',')[1] || image;
  const buffer = Buffer.from(base64Data, 'base64');

  console.log(`[Make3D] Uploading image (${buffer.length} bytes) for ${provider}`);

  const imageKey = await storage.uploadFile({
    fileContent: buffer,
    fileName: `make3d-input/${provider}-${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${imageType}`,
    contentType: `image/${imageType}`,
  });

  const imageUrl = await storage.generatePresignedUrl({
    key: imageKey,
    expireTime: 3600, // 1小时有效期
  });

  console.log(`[Make3D] Image uploaded: ${imageKey}`);

  return imageUrl;
}
