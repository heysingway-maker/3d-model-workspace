import { NextRequest, NextResponse } from 'next/server';
import { readFile } from 'fs/promises';
import path from 'path';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ filename: string }> }
) {
  try {
    const { filename } = await params;

    // 安全检查：只允许 .glb 或 .gltf 文件
    if (!filename.endsWith('.glb') && !filename.endsWith('.gltf')) {
      return NextResponse.json(
        { error: 'Invalid file type' },
        { status: 400 }
      );
    }

    // 构建文件路径
    const filePath = path.join(process.cwd(), 'public', 'assets', 'scenes', filename);

    // 读取文件
    const fileBuffer = await readFile(filePath);

    // 获取文件扩展名
    const ext = path.extname(filename);
    const contentType = ext === '.glb'
      ? 'model/gltf-binary'
      : 'model/gltf+json';

    // 返回文件
    return new NextResponse(fileBuffer, {
      headers: {
        'Content-Type': contentType,
        'Content-Length': fileBuffer.length.toString(),
        'Cache-Control': 'public, max-age=3600',
      },
    });
  } catch (error) {
    console.error('Error serving model file:', error);
    return NextResponse.json(
      { error: 'File not found' },
      { status: 404 }
    );
  }
}
