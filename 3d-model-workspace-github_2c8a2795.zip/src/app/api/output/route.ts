import { NextRequest, NextResponse } from 'next/server';
import { readdir, stat, unlink } from 'fs/promises';
import path from 'path';

// GET - List all files in Label_Save folder
export async function GET(request: NextRequest) {
  try {
    const outputDir = path.join(process.cwd(), 'public', 'Label_Save');
    
    let files: string[];
    try {
      files = await readdir(outputDir);
    } catch (e) {
      // Directory doesn't exist yet
      return NextResponse.json({ files: [], total: 0 });
    }

    // Filter out README.md and get file info
    const fileList = await Promise.all(
      files
        .filter(file => file !== 'README.md')
        .map(async (file) => {
          const filePath = path.join(outputDir, file);
          const stats = await stat(filePath);
          return {
            name: file,
            url: `/Label_Save/${file}`,
            size: stats.size,
            createdAt: stats.birthtime,
            modifiedAt: stats.mtime,
          };
        })
    );

    // Sort by creation date (newest first)
    fileList.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );

    return NextResponse.json({
      files: fileList,
      total: fileList.length,
    });
  } catch (error) {
    console.error('Error listing Label_Save files:', error);
    return NextResponse.json(
      { error: 'Failed to list files' },
      { status: 500 }
    );
  }
}

// DELETE - Delete a file from Label_Save folder
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const filename = searchParams.get('filename');

    if (!filename) {
      return NextResponse.json(
        { error: 'Filename is required' },
        { status: 400 }
      );
    }

    // Security check - only allow deleting from Label_Save folder
    if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
      return NextResponse.json(
        { error: 'Invalid filename' },
        { status: 400 }
      );
    }

    const outputDir = path.join(process.cwd(), 'public', 'Label_Save');
    const filePath = path.join(outputDir, filename);

    try {
      await unlink(filePath);
      return NextResponse.json({ success: true, message: `Deleted ${filename}` });
    } catch (e) {
      return NextResponse.json(
        { error: 'File not found' },
        { status: 404 }
      );
    }
  } catch (error) {
    console.error('Error deleting file:', error);
    return NextResponse.json(
      { error: 'Failed to delete file' },
      { status: 500 }
    );
  }
}
