import { NextRequest, NextResponse } from 'next/server';
import { S3Storage } from 'coze-coding-dev-sdk';
import { projectManager } from '@/storage/database';

// POST - Export and save mapped model
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: projectId } = await params;

    // Get project to verify it exists
    const project = await projectManager.getProjectById(projectId);
    if (!project) {
      return NextResponse.json(
        { error: 'Project not found' },
        { status: 404 }
      );
    }

    console.log(`Export request for project ${projectId}, current modelKey: ${project.modelKey}`);

    // Get the exported GLB file from request
    const formData = await request.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return NextResponse.json(
        { error: 'No file provided' },
        { status: 400 }
      );
    }

    console.log(`Received file: ${file.name}, size: ${file.size} bytes`);

    // Convert file to Buffer
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // Initialize S3Storage
    const storage = new S3Storage({
      endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
      accessKey: '',
      secretKey: '',
      bucketName: process.env.COZE_BUCKET_NAME,
      region: 'cn-beijing',
    });

    // Generate new model key with timestamp
    const timestamp = Date.now();
    const sanitizedName = project.name.replace(/[^a-zA-Z0-9_-]/g, '_');
    const fileName = `projects/${sanitizedName}_mapped_${timestamp}.glb`;

    console.log(`Uploading file with fileName: ${fileName}`);

    // Upload the exported GLB file
    const newModelKey = await storage.uploadFile({
      fileContent: buffer,
      fileName: fileName,
      contentType: 'model/gltf-binary',
    });

    console.log(`Upload complete, returned modelKey: ${newModelKey}`);

    // Verify the file was uploaded correctly
    const fileExists = await storage.fileExists({ fileKey: newModelKey });
    console.log(`File exists check for ${newModelKey}: ${fileExists}`);

    if (!fileExists) {
      console.error(`File upload verification failed for key: ${newModelKey}`);
      return NextResponse.json(
        { error: 'File upload verification failed' },
        { status: 500 }
      );
    }

    // Update project with new model key
    const updatedProject = await projectManager.updateProjectModelKey(projectId, newModelKey);
    console.log(`Project updated, new modelKey in DB: ${updatedProject?.modelKey}`);

    return NextResponse.json({
      success: true,
      modelKey: newModelKey,
      modelUrl: `/api/projects/${projectId}/model`,
    });
  } catch (error) {
    console.error('Export model error:', error);
    return NextResponse.json(
      { error: 'Failed to export model' },
      { status: 500 }
    );
  }
}
