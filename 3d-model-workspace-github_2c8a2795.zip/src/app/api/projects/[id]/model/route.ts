import { NextRequest, NextResponse } from 'next/server';
import { projectManager } from '@/storage/database';
import { S3Storage } from 'coze-coding-dev-sdk';
import * as fs from 'fs';
import * as path from 'path';

// 支持的 3D 模型格式
const MODEL_EXTENSIONS = ['.glb', '.gltf', '.fbx'];

// 初始化对象存储（用于查找远程模型）
function getStorage(): S3Storage | null {
  try {
    return new S3Storage({
      endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
      accessKey: '',
      secretKey: '',
      bucketName: process.env.COZE_BUCKET_NAME,
      region: 'cn-beijing',
    });
  } catch {
    return null;
  }
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: projectId } = await params;

    // Get project from database
    const project = await projectManager.getProjectById(projectId);

    if (!project) {
      console.log(`Project not found: ${projectId}`);
      return NextResponse.json(
        { error: 'Project not found' },
        { status: 404 }
      );
    }

    console.log(`Loading model for project ${projectId} (${project.name}), modelKey: ${project.modelKey}`);

    // 获取当前域名，用于返回本地可访问的路径
    const baseUrl = process.env.COZE_PROJECT_DOMAIN_DEFAULT || 'http://localhost:5000';

    // 获取项目名（用于匹配文件名）
    const projectName = project.name.toLowerCase().replace(/[^a-z0-9]/g, '');

    // sketch-placeholder 直接返回 404
    if (project.modelKey === 'sketch-placeholder') {
      return NextResponse.json(
        { error: 'This project does not have a 3D model. Please upload a model or create from sketch.' },
        { status: 404 }
      );
    }

    // ========== 策略1：在本地文件系统中搜索 ==========
    const localResult = await findLocalModel(projectId, projectName, project.modelKey, baseUrl);
    if (localResult) {
      console.log(`Found local model for "${project.name}": ${localResult.url}`);
      return NextResponse.redirect(localResult.url);
    }

    // ========== 策略2：从对象存储获取签名 URL ==========
    const storageResult = await findStorageModel(project.modelKey);
    if (storageResult) {
      console.log(`Found storage model for "${project.name}": redirecting to presigned URL`);
      return NextResponse.redirect(storageResult);
    }

    // 所有方式都找不到
    console.log(`No model found for project: ${project.name} (id: ${projectId}, key: ${project.modelKey})`);
    return NextResponse.json(
      { error: 'Model file not found. Please re-upload or generate a model.' },
      { status: 404 }
    );
  } catch (error) {
    console.error('Get model error:', error);
    return NextResponse.json(
      { error: 'Failed to load model file' },
      { status: 500 }
    );
  }
}

/**
 * 策略1：在本地 public/ 目录中搜索模型文件
 */
async function findLocalModel(
  projectId: string,
  projectName: string,
  modelKey: string,
  baseUrl: string
): Promise<{ url: string } | null> {

  // 定义搜索目录列表（按优先级排序）
  const searchDirs = [
    path.join(process.cwd(), 'public', '3D_Make_Save'),
    path.join(process.cwd(), 'public', 'models'),
    path.join(process.cwd(), 'public', 'assets', 'scenes'),
    path.join(process.cwd(), 'public'),
  ];

  /**
   * 递归搜索目录下所有支持的模型文件
   */
  function findModelFiles(dir: string, basePath: string = ''): string[] {
    const results: string[] = [];
    if (!fs.existsSync(dir)) return results;
    try {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        const relativePath = basePath ? `${basePath}/${entry.name}` : entry.name;
        if (entry.isDirectory()) {
          if (entry.name === 'node_modules' || entry.name.startsWith('.')) continue;
          results.push(...findModelFiles(fullPath, relativePath));
        } else if (entry.isFile()) {
          const ext = path.extname(entry.name).toLowerCase();
          if (MODEL_EXTENSIONS.includes(ext)) {
            results.push(relativePath);
          }
        }
      }
    } catch {
      // 忽略无权限等错误
    }
    return results;
  }

  interface Candidate {
    relativePath: string;
    fullPath: string;
    score: number;
  }
  const candidates: Candidate[] = [];

  for (const searchDir of searchDirs) {
    if (!fs.existsSync(searchDir)) continue;

    const allFiles = findModelFiles(searchDir);

    for (const file of allFiles) {
      const fullPath = path.join(searchDir, file);
      const fileName = path.basename(file).toLowerCase();
      const dirName = path.dirname(file).toLowerCase().split('/').pop() || '';
      let score = 0;

      // 规则1：文件名以项目名开头（最高优先级）
      if (fileName.startsWith(projectName + '_') || fileName.startsWith(projectName + '.')) {
        score += 100;
      }
      // 规则2：文件名包含项目名
      else if (fileName.includes(projectName) && projectName.length > 2) {
        score += 60;
      }
      // 规则3：所在子目录名匹配项目名
      if (dirName === projectName || dirName.startsWith(projectName)) {
        score += 40;
      }
      // 规则4：目录名包含项目 ID
      const fileDir = path.dirname(file);
      if (fileDir.includes(projectId)) {
        score += 80;
      }
      // 规则5：modelKey 中提取的文件名匹配
      const modelKeyBasename = path.basename(modelKey).toLowerCase();
      if (fileName === modelKeyBasename || fileName.startsWith(modelKeyBasename.replace(/\.[^.]+$/, ''))) {
        score += 90;
      }

      if (score > 0) {
        candidates.push({ relativePath: file, fullPath, score });
      }
    }
  }

  // 按分数降序排列，取最高分
  candidates.sort((a, b) => b.score - a.score);

  if (candidates.length > 0) {
    const best = candidates[0];
    const publicDir = path.join(process.cwd(), 'public');
    let urlPath = best.fullPath.slice(publicDir.length).replace(/\\/g, '/');
    return { url: `${baseUrl}${urlPath}` };
  }

  // 兜底：modelKey 本身是本地路径
  if (modelKey && !modelKey.startsWith('http') && !modelKey.startsWith('projects/')) {
    const possibleLocalPath = path.join(process.cwd(), 'public', modelKey);
    if (fs.existsSync(possibleLocalPath)) {
      return { url: `${baseUrl}/${modelKey.replace(/\\/g, '/')}` };
    }
  }

  return null;
}

/**
 * 策略2：从对象存储中查找并生成签名 URL
 */
async function findStorageModel(modelKey: string): Promise<string | null> {
  if (!modelKey || modelKey === 'pending-upload') return null;

  const storage = getStorage();
  if (!storage) return null;

  try {
    // 尝试用 modelKey 作为 fileKey 检查是否存在
    const exists = await storage.fileExists({ fileKey: modelKey });
    if (exists) {
      const signedUrl = await storage.generatePresignedUrl({
        key: modelKey,
        expireTime: 3600, // 1小时有效期
      });
      console.log(`Storage file found: ${modelKey}`);
      return signedUrl;
    }

    // 如果 modelKey 以 projects/ 开头，直接尝试生成签名 URL（不检查存在性，因为 listFiles 可能权限不足）
    if (modelKey.startsWith('projects/')) {
      try {
        const signedUrl = await storage.generatePresignedUrl({
          key: modelKey,
          expireTime: 3600,
        });
        console.log(`Generated presigned URL for storage key: ${modelKey}`);
        return signedUrl;
      } catch {
        // 签名 URL 生成失败，说明文件可能不存在
      }
    }
  } catch (e) {
    console.log('Storage lookup failed:', e instanceof Error ? e.message : e);
  }

  return null;
}
