import { NextRequest, NextResponse } from 'next/server';
import { projectManager } from '@/storage/database';
import { S3Storage } from 'coze-coding-dev-sdk';

// Initialize S3Storage
const getStorage = () => {
  return new S3Storage({
    endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
    accessKey: '',
    secretKey: '',
    bucketName: process.env.COZE_BUCKET_NAME,
    region: 'cn-beijing',
  });
};

// POST - Upload preview image
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const formData = await request.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return NextResponse.json(
        { error: 'Missing preview file' },
        { status: 400 }
      );
    }

    // Validate file type
    const validTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      return NextResponse.json(
        { error: 'Only PNG, JPEG, and WebP images are supported' },
        { status: 400 }
      );
    }

    // Convert file to Buffer
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // Upload to S3
    const storage = getStorage();
    const previewKey = await storage.uploadFile({
      fileContent: buffer,
      fileName: `previews/${id}_${Date.now()}.png`,
      contentType: file.type,
    });

    // Update project with preview key
    const project = await projectManager.updateProjectPreview(id, previewKey);

    if (!project) {
      return NextResponse.json(
        { error: 'Project not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      previewUrl: `/api/projects/${id}/preview`,
    });
  } catch (error) {
    console.error('Upload preview error:', error);
    return NextResponse.json(
      { error: 'Failed to upload preview' },
      { status: 500 }
    );
  }
}

// GET - Get preview image
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    // Get project to find preview key
    const project = await projectManager.getProjectById(id);

    if (!project || !project.previewKey) {
      return NextResponse.json(
        { error: 'Preview not found' },
        { status: 404 }
      );
    }

    // Get file from S3
    const storage = getStorage();
    const fileData = await storage.readFile({ fileKey: project.previewKey });

    if (!fileData) {
      return NextResponse.json(
        { error: 'Preview file not found' },
        { status: 404 }
      );
    }

    // Return file
    return new NextResponse(new Uint8Array(fileData), {
      headers: {
        'Content-Type': 'image/png',
        'Cache-Control': 'public, max-age=31536000', // 1 year cache
      },
    });
  } catch (error) {
    console.error('Get preview error:', error);
    return NextResponse.json(
      { error: 'Failed to load preview' },
      { status: 500 }
    );
  }
}
