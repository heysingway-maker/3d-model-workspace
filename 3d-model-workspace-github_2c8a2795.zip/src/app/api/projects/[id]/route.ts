import { NextRequest, NextResponse } from 'next/server';
import { projectManager } from '@/storage/database';
import { S3Storage } from 'coze-coding-dev-sdk';

// Initialize S3Storage
const getStorage = () => {
  return new S3Storage({
    endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
    accessKey: '',
    secretKey: '',
    bucketName: process.env.COZE_BUCKET_NAME,
    region: 'cn-beijing',
  });
};

// GET - Get project by ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const project = await projectManager.getProjectById(id);

    if (!project) {
      return NextResponse.json(
        { error: 'Project not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      id: project.id,
      name: project.name,
      description: project.description,
      modelKey: project.modelKey, // 添加 modelKey 字段
      modelUrl: `/api/projects/${project.id}/model`,
      previewUrl: project.previewKey ? `/api/projects/${project.id}/preview` : null,
      createdAt: project.createdAt,
      updatedAt: project.updatedAt,
    });
  } catch (error) {
    console.error('Get project error:', error);
    return NextResponse.json(
      { error: 'Failed to load project' },
      { status: 500 }
    );
  }
}

// PATCH - Update project
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { name, description } = body;

    const project = await projectManager.updateProject(id, {
      name,
      description,
    });

    if (!project) {
      return NextResponse.json(
        { error: 'Project not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      id: project.id,
      name: project.name,
      description: project.description,
      modelUrl: `/api/projects/${project.id}/model`,
      previewUrl: project.previewKey ? `/api/projects/${project.id}/preview` : null,
      createdAt: project.createdAt,
      updatedAt: project.updatedAt,
    });
  } catch (error) {
    console.error('Update project error:', error);
    return NextResponse.json(
      { error: 'Failed to update project' },
      { status: 500 }
    );
  }
}

// DELETE - Delete project
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    // Get project to get the model key for deletion
    const project = await projectManager.getProjectById(id);

    if (!project) {
      return NextResponse.json(
        { error: 'Project not found' },
        { status: 404 }
      );
    }

    // Delete from database
    const deleted = await projectManager.deleteProject(id);

    if (!deleted) {
      return NextResponse.json(
        { error: 'Failed to delete project' },
        { status: 500 }
      );
    }

    // Delete files from S3 (optional - you might want to keep backups)
    try {
      const storage = getStorage();
      // Note: S3Storage might not have a deleteFile method, check the SDK
      // If not available, we'll just clean up the database record
    } catch (error) {
      console.warn('Failed to delete S3 files:', error);
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete project error:', error);
    return NextResponse.json(
      { error: 'Failed to delete project' },
      { status: 500 }
    );
  }
}
