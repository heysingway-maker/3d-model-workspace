import { NextRequest, NextResponse } from 'next/server';
import { projectManager } from '@/storage/database';
import * as fs from 'fs';
import * as path from 'path';

// POST - Save mapped model to local public directory (overwrite mode)
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: projectId } = await params;

    // Get project to verify it exists and get name
    const project = await projectManager.getProjectById(projectId);
    if (!project) {
      return NextResponse.json(
        { error: 'Project not found' },
        { status: 404 }
      );
    }

    console.log(`Local save request for project ${projectId}: ${project.name}`);

    // Get the exported GLB file from request
    const formData = await request.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return NextResponse.json(
        { error: 'No file provided' },
        { status: 400 }
      );
    }

    console.log(`Received file: ${file.name}, size: ${file.size} bytes`);

    // Sanitize project name for folder name
    const sanitizedName = project.name.replace(/[^a-zA-Z0-9]/g, '_');
    
    // Create project-specific directory in public/3D_Make_Save/{项目名}/
    const baseDir = path.join(process.cwd(), 'public', '3D_Make_Save');
    const projectDir = path.join(baseDir, sanitizedName);
    
    // Ensure directories exist
    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true });
    }
    if (!fs.existsSync(projectDir)) {
      fs.mkdirSync(projectDir, { recursive: true });
    }

    // Get today's date in YYYYMMDD format
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    const todayDate = `${year}${month}${day}`;

    // Find existing files for this project
    let latestSeq = 0;
    let latestFile = '';
    const existingFiles = fs.readdirSync(projectDir).filter(f => f.endsWith('.glb'));

    if (existingFiles.length > 0) {
      // Find the highest sequence number
      existingFiles.forEach(f => {
        const match = f.match(/(\d{8})_(\d+)\.glb$/);
        if (match) {
          const seq = parseInt(match[2], 10);
          if (seq >= latestSeq) {
            latestSeq = seq;
            latestFile = f;
          }
        }
      });
    }

    // Generate new file name with incremented sequence
    const nextSeq = latestSeq + 1;
    const paddedSeq = String(nextSeq).padStart(3, '0');
    const fileName = `${sanitizedName}_${todayDate}_${paddedSeq}.glb`;
    const filePath = path.join(projectDir, fileName);

    console.log(`Saving to: ${filePath}`);

    // Convert file to buffer and save
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    fs.writeFileSync(filePath, buffer);

    // Delete old files for this project (overwrite mode - keep only latest)
    if (latestFile && latestFile !== fileName) {
      const oldFilePath = path.join(projectDir, latestFile);
      if (fs.existsSync(oldFilePath)) {
        fs.unlinkSync(oldFilePath);
        console.log(`Deleted old file: ${latestFile}`);
      }
    }

    // Construct the public URL path
    const publicPath = `/3D_Make_Save/${sanitizedName}/${fileName}`;

    console.log(`File saved successfully: ${publicPath}`);

    return NextResponse.json({
      success: true,
      message: 'Model saved successfully',
      path: publicPath,
      fileName: fileName,
      size: file.size
    });

  } catch (error) {
    console.error('Error saving model locally:', error);
    return NextResponse.json(
      { error: 'Failed to save model locally' },
      { status: 500 }
    );
  }
}
