import { NextRequest, NextResponse } from 'next/server';
import { S3Storage } from 'coze-coding-dev-sdk';
import { projectManager } from '@/storage/database/projectManager';

// 初始化对象存储
const storage = new S3Storage({
  endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
  accessKey: '',
  secretKey: '',
  bucketName: process.env.COZE_BUCKET_NAME,
  region: 'cn-beijing',
});

interface ImportRequest {
  modelUrl: string;
  name: string;
  description?: string;
}

// 带重试的 fetch
async function fetchWithRetry(url: string, maxRetries: number = 3): Promise<Response> {
  let lastError: Error | null = null;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; GlowStudio/1.0)',
        },
      });
      
      if (response.ok) {
        return response;
      }
      
      // 如果是 403/401，可能是 URL 过期，不需要重试
      if (response.status === 403 || response.status === 401) {
        throw new Error(`Model URL expired or unauthorized (${response.status})`);
      }
      
      lastError = new Error(`HTTP ${response.status}`);
      console.log(`Download attempt ${i + 1} failed: ${response.status}`);
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      console.log(`Download attempt ${i + 1} error:`, lastError.message);
    }
    
    // 等待后重试
    if (i < maxRetries - 1) {
      await new Promise(resolve => setTimeout(resolve, 1000 * (i + 1)));
    }
  }
  
  throw lastError || new Error('Download failed');
}

export async function POST(request: NextRequest) {
  try {
    const body: ImportRequest = await request.json();
    const { modelUrl, name, description } = body;

    if (!modelUrl || !name) {
      return NextResponse.json(
        { error: 'Model URL and name are required' },
        { status: 400 }
      );
    }

    console.log('Importing model from URL:', modelUrl.substring(0, 100) + '...');

    // Step 1: Download model from URL with retry
    let modelBuffer: Buffer;
    
    try {
      const modelResponse = await fetchWithRetry(modelUrl, 3);
      const arrayBuffer = await modelResponse.arrayBuffer();
      modelBuffer = Buffer.from(arrayBuffer);
    } catch (fetchError) {
      console.error('Failed to download model:', fetchError);
      return NextResponse.json(
        { error: `Failed to download model: ${fetchError instanceof Error ? fetchError.message : 'Unknown error'}` },
        { status: 400 }
      );
    }

    if (modelBuffer.length === 0) {
      return NextResponse.json(
        { error: 'Downloaded model is empty' },
        { status: 400 }
      );
    }

    console.log('Model downloaded, size:', modelBuffer.length);

    // Step 2: Upload to object storage
    const modelKey = await storage.uploadFile({
      fileContent: modelBuffer,
      fileName: `models/${Date.now()}-${name.replace(/[^a-zA-Z0-9]/g, '_')}.glb`,
      contentType: 'model/gltf-binary',
    });

    console.log('Model uploaded to storage, key:', modelKey);

    // Step 3: Create project in database
    const project = await projectManager.createProject({
      name,
      description: description || 'Imported from AI generation',
      modelKey,
    });

    console.log('Project created:', project.id);

    return NextResponse.json({
      success: true,
      project: {
        id: project.id,
        name: project.name,
        description: project.description,
        modelUrl: `/api/projects/${project.id}/model`,
        previewUrl: null,
        createdAt: project.createdAt,
      },
    });
  } catch (error) {
    console.error('Import model error:', error);
    return NextResponse.json(
      { error: 'Failed to import model: ' + (error instanceof Error ? error.message : String(error)) },
      { status: 500 }
    );
  }
}
