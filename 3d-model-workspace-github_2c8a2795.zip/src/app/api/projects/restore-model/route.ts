import { NextRequest, NextResponse } from 'next/server';
import { projectManager } from '@/storage/database';
import { S3Storage } from 'coze-coding-dev-sdk';
import { mkdir, writeFile } from 'fs/promises';
import path from 'path';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { projectId } = body;

    if (!projectId) {
      return NextResponse.json({ error: 'Project ID is required' }, { status: 400 });
    }

    // Get project from database
    const project = await projectManager.getProjectById(projectId);

    if (!project) {
      return NextResponse.json({ error: 'Project not found' }, { status: 404 });
    }

    console.log(`Restoring model for project ${projectId}, modelKey: ${project.modelKey}`);

    // Initialize S3Storage
    const storage = new S3Storage({
      endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
      accessKey: '',
      secretKey: '',
      bucketName: process.env.COZE_BUCKET_NAME,
      region: 'cn-beijing',
    });

    // Check if file exists in S3
    const exists = await storage.fileExists({ fileKey: project.modelKey });

    if (!exists) {
      return NextResponse.json({ error: 'Model file not found in storage' }, { status: 404 });
    }

    // Download file from S3
    console.log('Downloading from S3...');
    const fileData = await storage.readFile({ fileKey: project.modelKey });

    if (!fileData) {
      return NextResponse.json({ error: 'Failed to read file from storage' }, { status: 500 });
    }

    // Save to local directory
    const outputDir = path.join(process.cwd(), 'public', '3D_Make_Save');
    await mkdir(outputDir, { recursive: true });

    // Extract filename from modelKey
    const filename = project.modelKey.split('/').pop() || 'model.glb';
    const outputPath = path.join(outputDir, filename);
    
    await writeFile(outputPath, Buffer.from(fileData));
    console.log(`Saved to: ${outputPath}`);

    // Update project with local path
    await projectManager.updateProjectModelKey(projectId, filename);

    const baseUrl = process.env.COZE_PROJECT_DOMAIN_DEFAULT || 'http://localhost:5000';

    return NextResponse.json({
      success: true,
      message: 'Model restored successfully',
      modelUrl: `${baseUrl}/3D_Make_Save/${filename}`,
    });

  } catch (error) {
    console.error('Restore model error:', error);
    return NextResponse.json(
      { error: 'Failed to restore model', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
