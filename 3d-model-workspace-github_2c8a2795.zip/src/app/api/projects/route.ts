import { NextRequest, NextResponse } from 'next/server';
import { projectManager } from '@/storage/database';

// Get all projects with search support
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const limit = parseInt(searchParams.get('limit') || '100');
    const skip = parseInt(searchParams.get('skip') || '0');

    const projects = await projectManager.getProjects({
      search,
      limit,
      skip,
    });

    return NextResponse.json({
      projects: projects.map((p) => ({
        id: p.id,
        name: p.name,
        description: p.description,
        modelKey: p.modelKey, // 添加 modelKey 字段
        modelUrl: `/api/projects/${p.id}/model`,
        previewUrl: p.previewKey ? `/api/projects/${p.id}/preview` : null,
        createdAt: p.createdAt,
      })),
    });
  } catch (error) {
    console.error('Get projects error:', error);
    return NextResponse.json(
      { error: 'Failed to load projects' },
      { status: 500 }
    );
  }
}

// Create a new project (for sketch mode)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, description, isSketch } = body;

    // 创建项目记录
    // 草图模式使用占位符 modelKey，后续会更新
    const project = await projectManager.createProject({
      name: name || `Sketch Project ${new Date().toLocaleDateString()}`,
      description: description || (isSketch ? 'Created from sketch' : undefined),
      modelKey: isSketch ? 'sketch-placeholder' : 'pending-upload',
    });

    return NextResponse.json({
      success: true,
      project: {
        id: project.id,
        name: project.name,
        description: project.description,
        modelUrl: `/api/projects/${project.id}/model`,
        previewUrl: null,
        createdAt: project.createdAt,
      },
    });
  } catch (error) {
    console.error('Create project error:', error);
    return NextResponse.json(
      { error: 'Failed to create project' },
      { status: 500 }
    );
  }
}
