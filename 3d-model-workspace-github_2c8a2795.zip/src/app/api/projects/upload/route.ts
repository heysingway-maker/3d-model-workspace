import { NextRequest, NextResponse } from 'next/server';
import { S3Storage } from 'coze-coding-dev-sdk';
import { projectManager } from '@/storage/database';

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const name = formData.get('name') as string;
    const description = formData.get('description') as string | null;

    if (!file || !name) {
      return NextResponse.json(
        { error: 'Missing file or project name' },
        { status: 400 }
      );
    }

    // Validate file type
    if (!file.name.endsWith('.glb')) {
      return NextResponse.json(
        { error: 'Only GLB format is supported' },
        { status: 400 }
      );
    }

    // Convert file to Buffer
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // Initialize S3Storage
    const storage = new S3Storage({
      endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
      accessKey: '',
      secretKey: '',
      bucketName: process.env.COZE_BUCKET_NAME,
      region: 'cn-beijing',
    });

    // Sanitize file name (remove special characters and spaces)
    const sanitizedName = name.replace(/[^a-zA-Z0-9_-]/g, '_');
    const timestamp = Date.now();

    // Upload file to object storage
    const modelKey = await storage.uploadFile({
      fileContent: buffer,
      fileName: `projects/${sanitizedName}_${timestamp}.glb`,
      contentType: 'model/gltf-binary',
    });

    // Create project in database
    const project = await projectManager.createProject({
      name,
      description: description || undefined,
      modelKey,
      previewKey: undefined,
    });

    return NextResponse.json({
      id: project.id,
      name: project.name,
      description: project.description,
      modelUrl: `/api/projects/${project.id}/model`,
      previewUrl: project.previewKey ? `/api/projects/${project.id}/preview` : null,
      createdAt: project.createdAt,
    });
  } catch (error) {
    console.error('Upload error:', error);
    return NextResponse.json(
      { error: 'Upload failed, please try again' },
      { status: 500 }
    );
  }
}
