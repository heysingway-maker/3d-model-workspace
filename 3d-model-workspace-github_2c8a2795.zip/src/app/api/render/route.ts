import { NextRequest, NextResponse } from 'next/server';
import { ImageGenerationClient, Config, HeaderUtils, S3Storage } from 'coze-coding-dev-sdk';
import { writeFile, mkdir } from 'fs/promises';
import path from 'path';

export async function POST(request: NextRequest) {
  try {
    const { prompt, image, size = '2K' } = await request.json();

    // 验证参数
    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      );
    }

    // 提取请求头并转发
    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);

    // 初始化 Image Generation Client
    const config = new Config();
    const client = new ImageGenerationClient(config, customHeaders);

    // 优化 prompt，确保生成高质量渲染图
    const enhancedPrompt = `${prompt}, high quality 3D render, photorealistic, professional product photography, studio lighting, advanced materials, detailed textures, 8K resolution`;

    console.log('Starting image generation...');
    console.log('Prompt:', enhancedPrompt);
    console.log('Has image:', !!image);

    // 如果提供了图片，先上传到对象存储获取 URL
    let imageUrl: string | undefined;
    
    if (image) {
      // 初始化存储
      const storage = new S3Storage({
        endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
        accessKey: "",
        secretKey: "",
        bucketName: process.env.COZE_BUCKET_NAME,
        region: "cn-beijing",
      });

      if (image.startsWith('data:')) {
        // 解析 base64 数据
        const base64Match = image.match(/^data:image\/(\w+);base64,(.+)$/);
        if (base64Match) {
          const imageType = base64Match[1];
          const base64Data = base64Match[2];
          
          // 将 base64 转换为 Buffer
          const buffer = Buffer.from(base64Data, 'base64');
          
          console.log('Uploading image to storage, size:', buffer.length);
          
          // 上传到对象存储
          const fileKey = await storage.uploadFile({
            fileContent: buffer,
            fileName: `render-input/${Date.now()}.${imageType}`,
            contentType: `image/${imageType}`,
          });
          
          // 生成签名 URL（有效期 1 小时）
          imageUrl = await storage.generatePresignedUrl({
            key: fileKey,
            expireTime: 3600,
          });
          
          console.log('Image uploaded, signed URL generated');
        }
      } else {
        // 已经是 URL
        imageUrl = image;
      }
    }

    // 构建请求参数
    const generateParams: Parameters<typeof client.generate>[0] = {
      prompt: enhancedPrompt,
      size: size,
      watermark: false,
      responseFormat: 'url',
    };

    // 如果有图片，添加 image 参数
    if (imageUrl) {
      generateParams.image = imageUrl;
    }

    const response = await client.generate(generateParams);

    const helper = client.getResponseHelper(response);

    if (!helper.success) {
      console.error('Generation failed:', helper.errorMessages);
      return NextResponse.json(
        { error: 'Failed to generate image', details: helper.errorMessages },
        { status: 500 }
      );
    }

    console.log('Generation successful! Image URL:', helper.imageUrls[0]);

    // 下载生成的图片并保存到本地
    const generatedImageUrl = helper.imageUrls[0];
    let localPath: string | null = null;

    try {
      // 获取当前域名用于构建完整 URL
      const baseUrl = process.env.COZE_PROJECT_DOMAIN_DEFAULT || 'http://localhost:5000';
      const imageFetchUrl = generatedImageUrl.startsWith('http') 
        ? generatedImageUrl 
        : `${baseUrl}${generatedImageUrl}`;

      console.log('Downloading generated image from:', imageFetchUrl);

      const imageResponse = await fetch(imageFetchUrl);
      if (!imageResponse.ok) {
        console.error('Failed to download generated image:', imageResponse.status);
      } else {
        const imageBuffer = await imageResponse.arrayBuffer();
        const imageData = Buffer.from(imageBuffer);

        // 保存到本地 /AI_Render/ 目录
        const outputDir = path.join(process.cwd(), 'public', 'AI_Render');
        await mkdir(outputDir, { recursive: true });

        const filename = `render-${Date.now()}.png`;
        const outputPath = path.join(outputDir, filename);
        await writeFile(outputPath, imageData);

        // 返回本地相对路径
        localPath = `/AI_Render/${filename}`;
        console.log('Image saved locally:', localPath);
      }
    } catch (downloadError) {
      console.error('Failed to save image locally:', downloadError);
      // 继续使用原始 URL，但不保证长期可用
    }

    return NextResponse.json({
      success: true,
      imageUrl: localPath || generatedImageUrl, // 优先返回本地路径
      originalUrl: generatedImageUrl, // 保留原始 URL 作为备份
      model: response.model,
    });

  } catch (error) {
    console.error('Render API error:', error);
    return NextResponse.json(
      { error: 'Internal server error', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
