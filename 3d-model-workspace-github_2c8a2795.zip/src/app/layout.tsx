import type { Metadata, Viewport } from 'next';
import { Inspector } from 'react-dev-inspector';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: 'GlowStudio | AI-Powered 3D Visualization for Beauty',
    template: '%s | GlowStudio',
  },
  description: 'Advanced AI-powered 3D visualization platform for beauty products. Upload GLB models, create projects, and visualize cosmetics with intelligent AI-driven capabilities.',
  keywords: [
    '3D Visualization',
    'Beauty Products',
    'GLB Models',
    'AI-powered',
    'Cosmetics',
    'Digital Commerce',
    'Packaging Design',
    'Marketing',
  ],
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const isDev = process.env.NODE_ENV === 'development';

  return (
    <html lang="en" className="dark">
      <body className={`antialiased`}>
        {isDev && <Inspector />}
        {children}
      </body>
    </html>
  );
}
