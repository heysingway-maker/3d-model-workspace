'use client';

import dynamic from 'next/dynamic';
import { Suspense, useState, useEffect } from 'react';
import { useParams, useRouter, useSearchParams } from 'next/navigation';
import { ArrowLeft, Settings, ZoomIn, ZoomOut, RotateCcw, Info, AlertCircle, Sparkles, Plus, Undo, Redo, Edit3, Wand2, Tag, Save, Download, Loader2, Check, PenTool, X } from 'lucide-react';
import { toast } from 'sonner';
import { Toaster } from '@/components/ui/sonner';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ModelViewer } from '@/components/ModelViewer';
import { BottomToolbar } from '@/components/BottomToolbar';
import { RightPanel } from '@/components/RightPanel';
import { AIMuseumView } from '@/components/AIMuseumView';
import { SceneSelectionDialog } from '@/components/SceneSelectionDialog';
import FloatingWorkspace from '@/components/FloatingWorkspace';
import { LabelsPanel } from '@/components/LabelsPanel';
import { DecalMapping } from '@/components/DecalMapping';
import { useSceneStore } from '@/store/sceneStore';
import { useHistoryStore } from '@/store/historyStore';
import { useAIMuseumStore } from '@/store/aimuseumStore';
import { useCanvasStore } from '@/store/canvasStore';
import { useLabelStore, Label } from '@/store/labelStore';
import { useDecalUndo } from '@/hooks/useDecalUndo';
import { SelectionBox } from '@/components/SelectionBox';

type ToolType = 'transform' | 'material' | 'light' | 'environment' | 'post' | 'text' | null;

function LoadingSpinner() {
  return (
    <div className="flex flex-col items-center justify-center gap-4">
      <div className="h-12 w-12 animate-spin rounded-full border-4 border-border/20 border-t-gradient-to-r from-rose-500 to-purple-600" />
      <p className="text-sm text-muted-foreground/60">Loading 3D Model...</p>
    </div>
  );
}

function ErrorDisplay({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center gap-4 p-8">
      <AlertCircle className="h-16 w-16 text-destructive/60" />
      <div className="text-center">
        <h3 className="text-lg font-semibold mb-2">Loading Failed</h3>
        <p className="text-sm text-muted-foreground/60 mb-4">{message}</p>
        <Button onClick={onRetry} variant="outline">
          Retry
        </Button>
      </div>
    </div>
  );
}

// 草图模式欢迎提示组件
function SketchModeWelcome({ onClose, onStartDrawing }: { onClose: () => void; onStartDrawing: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <Card className="max-w-md border-white/10 bg-card/90 backdrop-blur-xl p-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500/20 to-purple-500/20">
              <PenTool className="h-6 w-6 text-indigo-400" />
            </div>
            <div>
              <h2 className="text-xl font-semibold">Sketch Mode</h2>
              <p className="text-sm text-muted-foreground">Create 3D from your drawing</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="space-y-4 mb-6">
          <div className="flex items-start gap-3 p-3 rounded-lg bg-white/5">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-indigo-500/20 text-sm font-medium text-indigo-400">1</div>
            <div>
              <p className="font-medium">Draw your sketch</p>
              <p className="text-sm text-muted-foreground">Use the drawing tools to create your design</p>
            </div>
          </div>
          
          <div className="flex items-start gap-3 p-3 rounded-lg bg-white/5">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-indigo-500/20 text-sm font-medium text-indigo-400">2</div>
            <div>
              <p className="font-medium">Generate 3D with AI</p>
              <p className="text-sm text-muted-foreground">Click the magic wand button to convert to 3D</p>
            </div>
          </div>
          
          <div className="flex items-start gap-3 p-3 rounded-lg bg-white/5">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-indigo-500/20 text-sm font-medium text-indigo-400">3</div>
            <div>
              <p className="font-medium">Edit & refine</p>
              <p className="text-sm text-muted-foreground">Adjust materials, lighting, and export</p>
            </div>
          </div>
        </div>
        
        <div className="flex gap-3">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancel
          </Button>
          <Button 
            onClick={onStartDrawing}
            className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
          >
            <Sparkles className="h-4 w-4 mr-2" />
            Start Drawing
          </Button>
        </div>
      </Card>
    </div>
  );
}

function Viewer({ modelUrl, onError, onLoad, projectId, onImportModel, onSceneReady }: { modelUrl: string; onError: () => void; onLoad: () => void; projectId: string; onImportModel: () => void; onSceneReady: (scene: any) => void }) {
  return <ModelViewer initialUrl={modelUrl} onError={onError} onLoad={onLoad} projectId={projectId} onImportModel={onImportModel} onSceneReady={onSceneReady} />;
}

export default function WorkspacePage() {
  const params = useParams();
  const router = useRouter();
  const searchParams = useSearchParams();
  const isSketchMode = searchParams.get('mode') === 'sketch';
  
  const [showSketchWelcome, setShowSketchWelcome] = useState(isSketchMode);
  const projectId = params.id as string;

  const [showControls, setShowControls] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [retryKey, setRetryKey] = useState(0);
  const [projectData, setProjectData] = useState<any>(null);
  const [activeTool, setActiveTool] = useState<ToolType>(null);
  const [scene, setScene] = useState<any>(null);

  // History store
  const { past, future, undo: historyUndo, redo: historyRedo } = useHistoryStore();
  const { undo: sceneUndo, redo: sceneRedo } = useSceneStore();

  // AI Museum store
  const { isAIMuseumMode, toggleAIMuseumMode, openSceneSelection, sceneSelectionOpen, closeSceneSelection } = useAIMuseumStore();

  // Canvas store
  const { openWorkspace } = useCanvasStore();

  // Label store
  const { labels, openLabelEditor, openDecalMapping, closeDecalMapping, isDecalMappingOpen, activeLabelId } = useLabelStore();

  // Decal undo hook - handles CTRL+Z for decal operations
  useDecalUndo();

  const [showLabelsPanel, setShowLabelsPanel] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);

  const handleBack = () => {
    router.push('/');
  };

  const handleError = () => {
    setError('Failed to load 3D model. Please check if the file was uploaded correctly.');
    setIsLoading(false);
  };

  const handleRetry = () => {
    setError(null);
    setIsLoading(true);
    setRetryKey(prev => prev + 1);
  };

  const handleModelLoad = () => {
    setIsLoading(false);
    setError(null);
  };

  // Export and save mapped model (both cloud and local)
  const handleExportAndSave = async () => {
    if (!(window as any).exportScene) {
      console.error('Export function not available');
      toast.error('保存失败', { description: '导出功能不可用，请等待场景加载完成' });
      return;
    }

    setIsExporting(true);
    setExportSuccess(false);

    try {
      console.log('Starting export...');
      
      // Export scene to GLB
      const glbBlob = await (window as any).exportScene();
      
      console.log('Export result:', glbBlob ? `Blob size: ${glbBlob.size}` : 'null');
      
      if (!glbBlob || glbBlob.size === 0) {
        throw new Error('Failed to export scene - empty or null result');
      }

      // Create form data for cloud upload
      const formData = new FormData();
      formData.append('file', glbBlob, 'model.glb');

      console.log('Uploading to server (cloud storage)...');
      
      // Upload to cloud storage and update project
      const response = await fetch(`/api/projects/${projectId}/export`, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('Cloud server error:', errorData);
        throw new Error(errorData.error || 'Failed to save model to cloud');
      }

      const cloudResult = await response.json();
      console.log('Model saved to cloud successfully:', cloudResult);

      // Also save to local public directory (overwrite mode)
      console.log('Saving to local storage...');
      const localFormData = new FormData();
      localFormData.append('file', glbBlob, 'model.glb');
      
      const localResponse = await fetch(`/api/projects/${projectId}/save-local`, {
        method: 'POST',
        body: localFormData,
      });

      if (localResponse.ok) {
        const localResult = await localResponse.json();
        console.log('Model saved to local storage:', localResult);
        toast.success('模型保存成功', {
          description: `已保存至 ${localResult.path}`,
          duration: 3000,
        });
      } else {
        console.warn('Local save failed, but cloud save succeeded');
        toast.warning('模型已保存至云端', {
          description: '本地保存失败',
          duration: 3000,
        });
      }

      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);

    } catch (error) {
      console.error('Export failed:', error);
      toast.error('保存失败', {
        description: error instanceof Error ? error.message : '未知错误',
        duration: 4000,
      });
    } finally {
      setIsExporting(false);
    }
  };

  // Download mapped model locally
  const handleDownloadModel = async () => {
    if (!(window as any).exportScene) {
      console.error('Export function not available');
      return;
    }

    try {
      const glbBlob = await (window as any).exportScene();
      
      if (!glbBlob) {
        throw new Error('Failed to export scene');
      }

      // Download file
      const url = URL.createObjectURL(glbBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${projectData?.name || 'model'}_mapped.glb`;
      link.click();
      URL.revokeObjectURL(url);

    } catch (error) {
      console.error('Download failed:', error);
      alert('Failed to download model. Please try again.');
    }
  };

  // Handle Undo
  const handleUndo = () => {
    sceneUndo();
  };

  // Handle Redo
  const handleRedo = () => {
    sceneRedo();
  };

  // Keyboard shortcuts for Undo/Redo/Save
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if typing in an input field
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
        return;
      }

      // Cmd+Z / Ctrl+Z - Undo
      if ((e.metaKey || e.ctrlKey) && e.key === 'z' && !e.shiftKey) {
        e.preventDefault();
        console.log('⌨️ Undo shortcut triggered');
        useSceneStore.getState().undo();
      }
      // Cmd+Shift+Z / Ctrl+Shift+Z / Ctrl+Y - Redo
      if (((e.metaKey || e.ctrlKey) && e.shiftKey && e.key === 'z') ||
          ((e.metaKey || e.ctrlKey) && e.key === 'y')) {
        e.preventDefault();
        console.log('⌨️ Redo shortcut triggered');
        useSceneStore.getState().redo();
      }
      // Cmd+S / Ctrl+S - Save
      if ((e.metaKey || e.ctrlKey) && e.key === 's') {
        e.preventDefault();
        console.log('⌨️ Save shortcut triggered');
        handleExportAndSave();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleExportAndSave]);

  // 处理导入模型
  const handleImportModel = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.glb,.gltf,.fbx';

    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      try {
        // 通过 window.loadModel 函数调用 ModelViewer 中的加载逻辑
        if ((window as any).loadModel) {
          await (window as any).loadModel(file);
        }
      } catch (error) {
        console.error('Failed to import model:', error);
        setError('Failed to import model');
      }
    };

    input.click();
  };

  // 关闭右侧面板
  const handleCloseRightPanel = () => {
    setActiveTool(null);
  };

  // Listen for MODEL_READY event from FloatingWorkspace / Make3DPreview
  useEffect(() => {
    const handleModelReady = (event: CustomEvent) => {
      const { modelUrl, modelName } = event.detail;

      console.log('[MODEL_READY] Received event, model:', modelName);

      // Clear any previous error state when importing a new model
      setError(null);
      setIsLoading(true);

      // Call window.loadModel to load the new model into the scene
      if ((window as any).loadModel) {
        // loadModel expects a URL string (not File object)
        // The modelUrl from Make3DPreview is already a Blob URL string
        // modelName contains the correct extension for format auto-detection
        console.log('[MODEL_READY] Calling loadModel with url:', modelUrl.substring(0, 60) + '..., name:', modelName);
        (window as any).loadModel(modelUrl, modelName, [0, 0, 0], true)
          .then(() => {
            console.log('[MODEL_READY] ✅ Model loaded into scene');
            setIsLoading(false);
          })
          .catch((error: unknown) => {
            console.error('[MODEL_READY] Failed to load model:', error);
            setError('Failed to load generated model: ' + (error instanceof Error ? error.message : 'Unknown error'));
            setIsLoading(false);
          });
      } else {
        console.warn('[MODEL_READY] window.loadModel not available yet');
        setError('Model loader not ready. Please try again.');
        setIsLoading(false);
      }
    };

    // Add event listener
    window.addEventListener('MODEL_READY', handleModelReady as EventListener);

    // Cleanup event listener
    return () => {
      window.removeEventListener('MODEL_READY', handleModelReady as EventListener);
    };
  }, []);

  // Load project data from database
  useEffect(() => {
    const loadProject = async () => {
      try {
        const response = await fetch(`/api/projects/${projectId}`);
        if (response.ok) {
          const data = await response.json();
          setProjectData(data);
          
          // 如果是草图模式或模型不存在，直接标记加载完成
          if (isSketchMode || data.modelKey === 'sketch-placeholder' || data.modelKey === 'pending-upload') {
            setIsLoading(false);
          }
        } else {
          setError('Project not found');
        }
      } catch (error) {
        console.error('Failed to load project:', error);
        setError('Failed to load project data');
      }
    };

    loadProject();
  }, [projectId, isSketchMode]);

  // 判断是否有有效模型
  const hasValidModel = projectData && 
    projectData.modelKey && 
    projectData.modelKey !== 'sketch-placeholder' && 
    projectData.modelKey !== 'pending-upload';

  const displayProjectData = projectData || {
    name: 'Beauty Product Visualization',
    modelUrl: hasValidModel ? `/api/projects/${projectId}/model` : null,
  };

  return (
    <div className="flex h-screen flex-col bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border/10 backdrop-blur-sm">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleBack}
              className="hover:bg-border/10"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-xl font-light text-white">
                {displayProjectData.name}
              </h1>
              <p className="text-sm text-muted-foreground/60">3D Visualization Workspace</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Mode Toggle - Merged Toggle Switch */}
            <div className="flex items-center gap-1 p-1 bg-gray-800/50 rounded-full">
              {/* Edit Model Mode Button */}
              <button
                onClick={() => toggleAIMuseumMode(false)}
                className={`relative flex items-center justify-center w-9 h-9 rounded-full transition-all ${
                  !isAIMuseumMode
                    ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-500/25'
                    : 'text-gray-400 hover:text-white'
                }`}
                title="Edit Model"
              >
                <Edit3 className="w-4 h-4" />
              </button>

              {/* AI Museum Mode Button */}
              <button
                onClick={() => isAIMuseumMode ? null : openSceneSelection()}
                className={`relative flex items-center justify-center w-9 h-9 rounded-full transition-all ${
                  isAIMuseumMode
                    ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-500/25'
                    : 'text-gray-400 hover:text-white'
                }`}
                title="AI Museum"
              >
                <Sparkles className="w-4 h-4" />
              </button>
            </div>

            {/* Undo Button */}
            <Button
              variant="ghost"
              size="icon"
              onClick={handleUndo}
              disabled={past.length === 0}
              className="hover:bg-border/10 disabled:opacity-30 disabled:cursor-not-allowed"
              title="Undo (Cmd+Z)"
            >
              <Undo className="h-5 w-5" />
            </Button>

            {/* Redo Button */}
            <Button
              variant="ghost"
              size="icon"
              onClick={handleRedo}
              disabled={future.length === 0}
              className="hover:bg-border/10 disabled:opacity-30 disabled:cursor-not-allowed"
              title="Redo (Cmd+Shift+Z)"
            >
              <Redo className="h-5 w-5" />
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={handleImportModel}
              className="hover:bg-border/10"
              title="Import Model"
            >
              <Plus className="h-5 w-5" />
            </Button>

            {/* Labels Button */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowLabelsPanel(!showLabelsPanel)}
              className={`hover:bg-border/10 ${showLabelsPanel ? 'bg-violet-600/20 text-violet-400' : ''}`}
              title="Labels"
            >
              <Tag className="h-5 w-5" />
            </Button>

            {/* Export & Save Button */}
            <Button
              variant="ghost"
              size="icon"
              onClick={handleExportAndSave}
              disabled={isExporting}
              className={`hover:bg-border/10 ${exportSuccess ? 'text-green-400' : ''}`}
              title={exportSuccess ? 'Saved!' : 'Save Mapped Model'}
            >
              {isExporting ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : exportSuccess ? (
                <Check className="h-5 w-5" />
              ) : (
                <Save className="h-5 w-5" />
              )}
            </Button>

            {/* Download Model Button */}
            <Button
              variant="ghost"
              size="icon"
              onClick={handleDownloadModel}
              className="hover:bg-border/10"
              title="Download Mapped Model"
            >
              <Download className="h-5 w-5" />
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowInfo(!showInfo)}
              className="hover:bg-border/10"
            >
              <Info className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex flex-1 overflow-hidden">
        {/* AI Museum Mode */}
        {isAIMuseumMode ? (
          <AIMuseumView />
        ) : (
          /* Edit Model Mode - 3D Viewer */
          <div className="relative flex-1">
            {isLoading && !error && (
              <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm z-10">
                <LoadingSpinner />
              </div>
            )}

            {error && (
              <div className="absolute inset-0 flex items-center justify-center bg-background/90 backdrop-blur-sm z-10">
                <ErrorDisplay message={error} onRetry={handleRetry} />
              </div>
            )}

            {/* 只在有有效模型时渲染 Viewer */}
            {hasValidModel ? (
              <Suspense fallback={<LoadingSpinner />}>
                <Viewer
                  key={retryKey}
                  modelUrl={displayProjectData.modelUrl}
                  onError={handleError}
                  onLoad={handleModelLoad}
                  projectId={projectId}
                  onImportModel={handleImportModel}
                  onSceneReady={setScene}
                />
              </Suspense>
            ) : (
              /* 草图模式 - 显示提示和绘图按钮 */
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-900/50">
                <div className="text-center p-8 max-w-md">
                  <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-violet-500/20 to-indigo-500/20 flex items-center justify-center">
                    <PenTool className="w-10 h-10 text-violet-400" />
                  </div>
                  <h2 className="text-2xl font-light text-white mb-3">
                    {isSketchMode ? 'Sketch Mode' : 'No Model Yet'}
                  </h2>
                  <p className="text-gray-400 mb-6">
                    {isSketchMode 
                      ? 'Draw your design and generate a 3D model with AI'
                      : 'Start by creating a 3D model from your sketch'}
                  </p>
                  <Button
                    onClick={() => openWorkspace()}
                    className="bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700"
                  >
                    <Wand2 className="w-4 h-4 mr-2" />
                    {isSketchMode ? 'Start Drawing' : 'Create 3D Model'}
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Bottom Toolbar - Only show in Edit Mode */}
      {!isAIMuseumMode && <BottomToolbar activeTool={activeTool} onToolChange={setActiveTool} />}

      {/* Right Panel - Only show in Edit Mode */}
      {!isAIMuseumMode && <RightPanel activeTool={activeTool} onClose={handleCloseRightPanel} scene={scene} />}

      {/* Info Modal */}
      {showInfo && (
        <Card className="absolute top-20 right-6 w-80 border-border/20 bg-card/90 backdrop-blur-sm">
          <div className="p-6">
            <h3 className="text-lg font-semibold mb-3">Controls</h3>
            <div className="space-y-3 text-sm text-muted-foreground/80">
              <p>
                <span className="font-medium text-foreground">Rotate:</span>
                Left-click and drag
              </p>
              <p>
                <span className="font-medium text-foreground">Zoom:</span>
                Scroll wheel
              </p>
              <p>
                <span className="font-medium text-foreground">Pan:</span>
                Right-click and drag
              </p>
              <p>
                <span className="font-medium text-foreground">Select Model:</span>
                Click on model
              </p>
              <div className="mt-4 pt-3 border-t border-border/20">
                <p className="font-medium text-foreground mb-2">Shortcuts</p>
                <p>
                  <span className="font-medium text-foreground">Undo:</span>
                  Ctrl/Cmd + Z
                </p>
                <p>
                  <span className="font-medium text-foreground">Redo:</span>
                  Ctrl/Cmd + Shift + Z
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-border/20">
                <p className="text-xs">
                  Tip: Use mouse to rotate, zoom, and pan the model
                </p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowInfo(false)}
              className="mt-4 w-full border-border/20 bg-transparent hover:bg-border/5"
            >
              Close
            </Button>
          </div>
        </Card>
      )}

      {/* Scene Selection Dialog */}
      <SceneSelectionDialog
        isOpen={sceneSelectionOpen}
        onClose={closeSceneSelection}
      />

      {/* Generate Button - Floating Button */}
      <Button
        onClick={() => openWorkspace()}
        className="fixed bottom-6 right-6 z-30 h-14 w-14 rounded-full bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-500/30 hover:shadow-violet-500/50 hover:scale-105 transition-all"
        title="Generate AI Model"
      >
        <Wand2 className="w-6 h-6" />
      </Button>

      {/* Floating Workspace */}
      <FloatingWorkspace projectId={projectId} />

      {/* Sketch Mode Welcome Dialog */}
      {showSketchWelcome && (
        <SketchModeWelcome
          onClose={() => setShowSketchWelcome(false)}
          onStartDrawing={() => {
            setShowSketchWelcome(false);
            // 打开 FloatingWorkspace
            useCanvasStore.getState().openWorkspace();
          }}
        />
      )}

      {/* Labels Panel with integrated Decal Mode Panel */}
      {showLabelsPanel && (
        <div className="fixed top-20 right-6 z-30">
          <LabelsPanel onClose={() => setShowLabelsPanel(false)} />
        </div>
      )}

      {/* Selection Box for box selection mode */}
      <SelectionBox />

      {/* Toast notifications */}
      <Toaster position="top-center" richColors closeButton />
    </div>
  );
}
