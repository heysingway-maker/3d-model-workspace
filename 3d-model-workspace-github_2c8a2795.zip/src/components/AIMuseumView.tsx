'use client';

import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Plus, Camera, MousePointer2, Move, X, Image as ImageIcon, Upload, Sliders, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { useAIMuseumStore } from '@/store/aimuseumStore';
import { useSceneStore } from '@/store/sceneStore';
import { AIMuseumViewer } from './AIMuseumViewer';

export function AIMuseumView() {
  const { mode, setMode, viewSnapshots, addViewSnapshot, removeViewSnapshot, activeSnapshotId, setActiveSnapshot, photographyParams, updatePhotographyParams, customHdrUrl, setCustomHdr, selectedScene } = useAIMuseumStore();
  const { models, selectedObjectUuid } = useSceneStore();

  const [cameraPosition, setCameraPosition] = useState<THREE.Vector3 | null>(null);
  const [cameraTarget, setCameraTarget] = useState<THREE.Vector3 | null>(null);

  // 调试：监听 selectedScene 变化
  useEffect(() => {
    if (selectedScene) {
      console.log('Selected scene:', selectedScene);
      console.log('Scene URL:', selectedScene.sceneUrl);
      console.log('Models in scene:', models.length);
    }
  }, [selectedScene, models]);

  // 处理相机位置变化
  const handleCameraChange = (position: THREE.Vector3, target: THREE.Vector3) => {
    setCameraPosition(position);
    setCameraTarget(target);
  };

  // 添加视角快照
  const handleAddSnapshot = async () => {
    if (!cameraPosition || !cameraTarget) return;

    // 创建缩略图（使用 Canvas）
    const canvas = document.createElement('canvas');
    canvas.width = 200;
    canvas.height = 150;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#1a1a2e';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#7c3aed';
      ctx.font = '16px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('View Preview', canvas.width / 2, canvas.height / 2);
    }

    const newSnapshot = {
      id: `snapshot-${Date.now()}`,
      name: `View ${viewSnapshots.length + 1}`,
      thumbnail: canvas.toDataURL('image/png'),
      cameraPosition: [cameraPosition.x, cameraPosition.y, cameraPosition.z] as [number, number, number],
      cameraTarget: [cameraTarget.x, cameraTarget.y, cameraTarget.z] as [number, number, number],
      timestamp: Date.now(),
    };

    addViewSnapshot(newSnapshot);
  };

  // 导出渲染图像
  const handleExportRender = () => {
    const renderer = document.querySelector('.aimuseum-viewer canvas') as HTMLCanvasElement;
    if (!renderer) return;

    const link = document.createElement('a');
    link.download = `glowstudio-render-${Date.now()}.png`;
    link.href = renderer.toDataURL('image/png');
    link.click();
  };

  // 上传 HDR
  const handleHdrUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setCustomHdr(url);
    }
  };

  const sceneUrl = selectedScene?.sceneUrl || '';

  return (
    <div className="flex h-screen flex-col">
      {/* 3D Scene Container */}
      <div className="flex-1 relative bg-gradient-to-br from-gray-900 to-gray-950">
        {!sceneUrl ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-violet-500/20 to-indigo-500/20 flex items-center justify-center animate-pulse">
                <Camera className="w-12 h-12 text-violet-400/60" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">No Scene Selected</h3>
              <p className="text-sm text-gray-400">Please select a scene from the dialog</p>
            </div>
          </div>
        ) : (
          <div className="absolute inset-0 aimuseum-viewer">
            <AIMuseumViewer
              sceneUrl={sceneUrl}
              onCameraChange={handleCameraChange}
              onReady={() => console.log('Scene ready')}
            />
          </div>
        )}

        {/* Left Panel - Scene List */}
        <div className="absolute left-0 top-0 bottom-16 w-64 bg-gray-900/95 backdrop-blur-md border-r border-border/10">
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-between p-4 border-b border-border/10">
              <h3 className="text-sm font-semibold text-white">Scene List</h3>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleAddSnapshot}
                className="h-7 w-7 hover:bg-white/10"
                title="Add current view"
              >
                <Plus className="w-4 h-4 text-gray-400" />
              </Button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {viewSnapshots.length === 0 ? (
                <div className="text-center py-8">
                  <Camera className="w-8 h-8 mx-auto mb-2 text-gray-600" />
                  <p className="text-xs text-gray-500">No views yet</p>
                  <p className="text-[10px] text-gray-600 mt-1">Click + to add view</p>
                </div>
              ) : (
                viewSnapshots.map((snapshot) => (
                  <ViewSnapshotItem
                    key={snapshot.id}
                    snapshot={snapshot}
                    isActive={activeSnapshotId === snapshot.id}
                    onSelect={() => setActiveSnapshot(snapshot.id)}
                    onDelete={() => removeViewSnapshot(snapshot.id)}
                  />
                ))
              )}
            </div>
          </div>
        </div>

        {/* Right Panel - Photography Params */}
        <div className="absolute right-0 top-0 bottom-16 w-72 bg-gray-900/95 backdrop-blur-md border-l border-border/10">
          <div className="flex flex-col h-full">
            <div className="flex items-center gap-2 p-4 border-b border-border/10">
              <Sliders className="w-4 h-4 text-gray-400" />
              <h3 className="text-sm font-semibold text-white">Photography</h3>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-6">
              {/* Contrast */}
              <ParamSlider
                label="Contrast"
                value={photographyParams.contrast}
                min={0.5}
                max={2}
                step={0.1}
                onChange={(value) => updatePhotographyParams({ contrast: value })}
              />

              {/* Saturation */}
              <ParamSlider
                label="Saturation"
                value={photographyParams.saturation}
                min={0}
                max={2}
                step={0.1}
                onChange={(value) => updatePhotographyParams({ saturation: value })}
              />

              {/* Brightness */}
              <ParamSlider
                label="Brightness"
                value={photographyParams.brightness}
                min={0.5}
                max={2}
                step={0.1}
                onChange={(value) => updatePhotographyParams({ brightness: value })}
              />

              {/* Exposure */}
              <ParamSlider
                label="Exposure"
                value={photographyParams.exposure}
                min={0.5}
                max={2}
                step={0.1}
                onChange={(value) => updatePhotographyParams({ exposure: value })}
              />

              {/* Temperature */}
              <ParamSlider
                label="Temperature"
                value={photographyParams.temperature}
                min={0.5}
                max={2}
                step={0.1}
                onChange={(value) => updatePhotographyParams({ temperature: value })}
              />

              {/* HDR Upload */}
              <div>
                <label className="text-xs font-medium text-gray-300 mb-2 block">HDR Environment</label>
                <div className="flex items-center gap-2">
                  <label className="flex-1">
                    <input
                      type="file"
                      accept=".hdr,.exr"
                      className="hidden"
                      onChange={handleHdrUpload}
                    />
                    <div className="flex items-center justify-center gap-2 h-9 px-4 py-2 rounded-md border border-gray-700 bg-gray-800/50 text-sm text-gray-400 cursor-pointer hover:bg-gray-800 transition-all">
                      <Upload className="w-4 h-4" />
                      {customHdrUrl ? 'HDR Loaded' : 'Upload HDR'}
                    </div>
                  </label>
                  {customHdrUrl && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setCustomHdr(null)}
                      className="h-9 w-9 hover:bg-white/10"
                    >
                      <X className="w-4 h-4 text-gray-400" />
                    </Button>
                  )}
                </div>
                <p className="text-[10px] text-gray-500 mt-1">Upload custom HDR for environment lighting</p>
              </div>

              {/* Export Render */}
              <div className="pt-4 border-t border-border/10">
                <Button
                  onClick={handleExportRender}
                  className="w-full bg-gradient-to-r from-violet-600 to-indigo-600 text-white hover:from-violet-500 hover:to-indigo-500 shadow-lg shadow-violet-500/25"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Export Render
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Mode Info */}
        {mode === 'move' && selectedObjectUuid && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 px-4 py-2 bg-violet-500/20 backdrop-blur-sm border border-violet-500/30 rounded-full">
            <p className="text-xs text-violet-300">
              Move Mode: Use Gizmo to position selected product
            </p>
          </div>
        )}
      </div>

      {/* Bottom Mode Toggle */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 p-1 bg-gray-900/90 backdrop-blur-md border border-border/20 rounded-full">
        <Button
          variant={mode === 'move' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setMode('move')}
          className={`h-9 px-4 rounded-full font-medium transition-all ${
            mode === 'move'
              ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-500/25'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          <Move className="w-4 h-4 mr-2" />
          Move Mode
        </Button>
        <Button
          variant={mode === 'view' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setMode('view')}
          className={`h-9 px-4 rounded-full font-medium transition-all ${
            mode === 'view'
              ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-500/25'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          <MousePointer2 className="w-4 h-4 mr-2" />
          View Mode
        </Button>
      </div>
    </div>
  );
}

interface ViewSnapshotItemProps {
  snapshot: any;
  isActive: boolean;
  onSelect: () => void;
  onDelete: () => void;
}

function ViewSnapshotItem({ snapshot, isActive, onSelect, onDelete }: ViewSnapshotItemProps) {
  return (
    <button
      onClick={onSelect}
      className={`group relative w-full p-2 rounded-lg border transition-all ${
        isActive
          ? 'border-violet-500/50 bg-violet-500/10'
          : 'border-border/10 hover:border-border/20 bg-gray-800/30'
      }`}
    >
      {/* Thumbnail */}
      <div className="aspect-video bg-gradient-to-br from-gray-700 to-gray-800 rounded-md mb-2 overflow-hidden">
        <img
          src={snapshot.thumbnail}
          alt={snapshot.name}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Name */}
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-gray-300">{snapshot.name}</span>
        <button
          onClick={(e) => {
            e.stopPropagation();
            onDelete();
          }}
          className="opacity-0 group-hover:opacity-100 transition-opacity h-5 w-5 hover:bg-white/10 rounded flex items-center justify-center"
        >
          <X className="w-3 h-3 text-gray-400" />
        </button>
      </div>

      {/* Active Indicator */}
      {isActive && (
        <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-violet-500 shadow-lg shadow-violet-500/50" />
      )}
    </button>
  );
}

interface ParamSliderProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (value: number) => void;
}

function ParamSlider({ label, value, min, max, step, onChange }: ParamSliderProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <label className="text-xs font-medium text-gray-300">{label}</label>
        <span className="text-xs text-violet-400 font-mono">{value.toFixed(1)}</span>
      </div>
      <Slider
        value={[value]}
        onValueChange={(values) => onChange(values[0])}
        min={min}
        max={max}
        step={step}
        className="w-full"
      />
    </div>
  );
}
