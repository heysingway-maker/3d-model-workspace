'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { TransformControls } from 'three/examples/jsm/controls/TransformControls.js';
import { RGBELoader } from 'three/examples/jsm/loaders/RGBELoader.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { IUniform } from 'three';
import { useAIMuseumStore } from '@/store/aimuseumStore';
import { useSceneStore } from '@/store/sceneStore';

interface AIMuseumViewerProps {
  sceneUrl: string;
  onCameraChange?: (position: THREE.Vector3, target: THREE.Vector3) => void;
  onReady?: () => void;
}

export function AIMuseumViewer({ sceneUrl, onCameraChange, onReady }: AIMuseumViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const transformControlsRef = useRef<TransformControls | null>(null);
  const composerRef = useRef<EffectComposer | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  const { mode, photographyParams, customHdrUrl } = useAIMuseumStore();
  const { models, selectedObjectUuid } = useSceneStore();

  const [isMounted, setIsMounted] = useState(false);

  // 初始化场景
  useEffect(() => {
    if (!containerRef.current) return;

    setIsMounted(true);

    // 创建场景
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x1a1a2e);
    sceneRef.current = scene;

    // 创建相机
    const camera = new THREE.PerspectiveCamera(
      50,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.set(5, 3, 5);
    cameraRef.current = camera;

    // 创建渲染器
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      preserveDrawingBuffer: true, // 用于导出图像
    });

    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;

    console.log('Renderer size:', width, 'x', height);

    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.0;

    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    console.log('Renderer created and appended to container');

    // 创建 OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 1;
    controls.maxDistance = 20;
    controls.maxPolarAngle = Math.PI / 2;
    controlsRef.current = controls;

    // 创建 TransformControls
    const transformControls = new TransformControls(camera, renderer.domElement);
    transformControls.addEventListener('dragging-changed', (event) => {
      controls.enabled = !event.value;
    });
    // TransformControls 不需要添加到场景中，它自己处理渲染
    transformControlsRef.current = transformControls;
    console.log('TransformControls created');

    // 创建后期处理
    const composer = new EffectComposer(renderer);
    const renderPass = new RenderPass(scene, camera);
    composer.addPass(renderPass);

    // Bloom
    const bloomPass = new UnrealBloomPass(
      new THREE.Vector2(containerRef.current.clientWidth, containerRef.current.clientHeight),
      1.5,
      0.4,
      0.85
    );
    composer.addPass(bloomPass);

    // Vignette
    const vignetteShader = {
      uniforms: {
        tDiffuse: { value: null },
        darkness: { value: 1.2 },
        offset: { value: 0.8 },
      },
      vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform sampler2D tDiffuse;
        uniform float darkness;
        uniform float offset;
        varying vec2 vUv;
        void main() {
          vec4 color = texture2D(tDiffuse, vUv);
          vec2 center = vUv - 0.5;
          float dist = length(center);
          color.rgb *= smoothstep(darkness, offset, dist);
          gl_FragColor = color;
        }
      `,
    };
    const vignettePass = new ShaderPass(vignetteShader);
    composer.addPass(vignettePass);

    composerRef.current = composer;

    // 添加灯光
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1.0);
    directionalLight.position.set(5, 10, 7.5);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 2048;
    directionalLight.shadow.mapSize.height = 2048;
    directionalLight.shadow.camera.near = 0.5;
    directionalLight.shadow.camera.far = 50;
    scene.add(directionalLight);

    // 添加网格辅助线
    const gridHelper = new THREE.GridHelper(20, 20, 0x444444, 0x222222);
    scene.add(gridHelper);
    console.log('Grid helper added');

    // 添加测试立方体（验证渲染是否正常）
    const testGeometry = new THREE.BoxGeometry(1, 1, 1);
    const testMaterial = new THREE.MeshStandardMaterial({ color: 0x7c3aed });
    const testCube = new THREE.Mesh(testGeometry, testMaterial);
    testCube.position.set(0, 0.5, 0);
    testCube.castShadow = true;
    testCube.receiveShadow = true;
    testCube.name = 'test-cube';
    scene.add(testCube);
    console.log('Test cube added to scene');

    // 动画循环
    let frameCount = 0;
    const animate = () => {
      animationFrameRef.current = requestAnimationFrame(animate);
      controls.update();

      // 每60帧输出一次渲染状态
      frameCount++;
      if (frameCount % 60 === 0) {
        console.log('Rendering frame:', frameCount);
        console.log('Camera position:', camera.position);
        console.log('Camera target:', controls.target);
        console.log('Scene children count:', scene.children.length);
        console.log('Visible objects:');
        scene.traverse((child: any) => {
          if (child.isMesh && child.visible) {
            console.log(`  - ${child.name || 'unnamed'} at`, child.position);
          }
        });
      }

      composer.render();
    };

    console.log('Starting animation loop');
    animate();

    // 窗口大小调整
    const handleResize = () => {
      if (!containerRef.current || !camera || !renderer || !composer) return;

      camera.aspect = containerRef.current.clientWidth / containerRef.current.clientHeight;
      camera.updateProjectionMatrix();

      renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
      composer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      setIsMounted(false);
      window.removeEventListener('resize', handleResize);

      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }

      if (transformControls) {
        transformControls.detach();
        transformControls.dispose();
      }

      if (controls) {
        controls.dispose();
      }

      if (renderer) {
        renderer.dispose();
        if (containerRef.current && renderer.domElement) {
          containerRef.current.removeChild(renderer.domElement);
        }
      }

      if (composer) {
        composer.dispose();
      }
    };
  }, []);

  // 加载场景
  useEffect(() => {
    if (!sceneRef.current || !sceneUrl) return;

    console.log('Loading scene:', sceneUrl);

    const loader = new GLTFLoader();
    loader.load(
      sceneUrl,
      (gltf) => {
        console.log('Scene loaded successfully:', gltf);
        console.log('GLTF info:', {
          scene: gltf.scene,
          scenes: gltf.scenes,
          cameras: gltf.cameras,
          animations: gltf.animations,
          asset: gltf.asset,
        });

        const model = gltf.scene;

        // 计算场景边界框
        const box = new THREE.Box3().setFromObject(model);
        console.log('Scene bounding box:', box);
        console.log('Scene size:', box.getSize(new THREE.Vector3()));
        console.log('Scene center:', box.getCenter(new THREE.Vector3()));

        // 检查场景是否有有效的几何体
        let vertexCount = 0;
        let meshCount = 0;
        model.traverse((child: any) => {
          if (child.isMesh && child.geometry) {
            meshCount++;
            if (child.geometry.attributes && child.geometry.attributes.position) {
              vertexCount += child.geometry.attributes.position.count;
            }
          }
        });
        console.log('Scene statistics:', { meshCount, vertexCount });

        if (meshCount === 0) {
          console.warn('Scene has no meshes! This might be the issue.');
        }
        if (vertexCount === 0) {
          console.warn('Scene has no vertices! This might be the issue.');
        }

        // 居中场景
        const center = box.getCenter(new THREE.Vector3());
        model.position.sub(center);

        // 重新计算边界框（居中后）
        const newBox = new THREE.Box3().setFromObject(model);
        const size = newBox.getSize(new THREE.Vector3());

        // 调整相机位置以适应场景大小
        const maxDim = Math.max(size.x, size.y, size.z);
        const cameraDistance = maxDim * 2;

        if (cameraRef.current) {
          cameraRef.current.position.set(cameraDistance, cameraDistance * 0.6, cameraDistance);
          cameraRef.current.lookAt(0, 0, 0);
          controlsRef.current!.target.set(0, 0, 0);
          controlsRef.current!.update();
          console.log('Camera position updated:', cameraRef.current.position);
        }

        model.traverse((child: any) => {
          if (child.isMesh) {
            child.castShadow = true;
            child.receiveShadow = true;

            // 检查材质
            if (child.material) {
              console.log(`Mesh ${child.name}:`, {
                color: child.material.color?.getHexString(),
                roughness: child.material.roughness,
                metalness: child.material.metalness,
                transparent: child.material.transparent,
                opacity: child.material.opacity,
                side: child.material.side,
              });

              // 如果材质颜色接近黑色，设置一个默认颜色
              if (child.material.color) {
                const colorValue = child.material.color.getHex();
                if (colorValue === 0x000000 || colorValue === 0xffffff) {
                  child.material.color.setHex(0x888888); // 灰色
                  console.log(`Updated material color for ${child.name} from hex ${colorValue.toString(16)} to 0x888888`);
                }
              }
            }
            console.log('Added mesh to scene:', child.name);
          }
        });

        sceneRef.current!.add(model);
        console.log('Scene added to Three.js scene');
        console.log('Scene hierarchy:');
        model.traverse((child: any) => {
          if (child.isMesh || child.isGroup) {
            console.log(`  - ${child.name || 'unnamed'} (${child.type}) at position:`, child.position);
          }
        });

        // 强制场景可见
        model.visible = true;
        model.traverse((child: any) => {
          if (child.isMesh) {
            child.visible = true;
          }
        });
        console.log('Forced scene and all children to visible');

        // 添加边界框可视化（帮助定位场景）
        const boxHelper = new THREE.Box3Helper(newBox, 0x7c3aed);
        boxHelper.name = 'scene-bbox';
        sceneRef.current!.add(boxHelper);
        console.log('Added bounding box helper for scene');

        // 移除测试立方体
        const testCube = sceneRef.current!.getObjectByName('test-cube');
        if (testCube) {
          sceneRef.current!.remove(testCube);
          console.log('Test cube removed');
        }

        if (onReady) {
          onReady();
        }
      },
      (progress) => {
        const percent = progress.total > 0 ? ((progress.loaded / progress.total) * 100).toFixed(1) : 'unknown';
        console.log(`Loading progress: ${progress.loaded} / ${progress.total} (${percent}%)`);
      },
      (error) => {
        console.error('Failed to load scene:', error);
        console.error('Error details:', error);
      }
    );
  }, [sceneUrl, onReady]);

  // 加载产品模型
  useEffect(() => {
    if (!sceneRef.current || !isMounted) return;

    console.log('Loading product models, count:', models.length);

    // 清除旧的产品模型
    const productGroup = sceneRef.current.getObjectByName('products');
    if (productGroup) {
      sceneRef.current.remove(productGroup);
    }

    const newProductGroup = new THREE.Group();
    newProductGroup.name = 'products';

    models.forEach((model) => {
      if (!model.url) {
        console.log('Product model has no URL:', model.id);
        return;
      }

      console.log('Loading product:', model.name, 'from', model.url);

      const loader = new GLTFLoader();
      loader.load(
        model.url,
        (gltf) => {
          console.log('Product loaded:', model.name, gltf);
          const productModel = gltf.scene;
          productModel.position.set(...model.position);
          productModel.rotation.set(
            (model.rotation[0] * Math.PI) / 180,
            (model.rotation[1] * Math.PI) / 180,
            (model.rotation[2] * Math.PI) / 180
          );
          productModel.scale.set(...model.scale);
          productModel.name = model.id;
          productModel.visible = model.visible;

          productModel.traverse((child: any) => {
            if (child.isMesh) {
              child.castShadow = true;
              child.receiveShadow = true;
              child.userData.modelId = model.id;

              // 应用材质
              if (child.material) {
                child.material = new THREE.MeshPhysicalMaterial({
                  color: model.material.color,
                  roughness: model.material.roughness,
                  metalness: model.material.metalness,
                  transparent: model.material.transparent < 1.0,
                  opacity: model.material.transparent,
                });
              }
              console.log('Product mesh:', child.name);
            }
          });

          newProductGroup.add(productModel);
          console.log('Product added to group:', model.name);
        },
        (progress) => {
          console.log('Product loading progress:', model.name, (progress.loaded / progress.total) * 100);
        },
        (error) => {
          console.error('Failed to load product model:', model.name, error);
        }
      );
    });

    sceneRef.current.add(newProductGroup);
    console.log('Product group added to scene');
  }, [models, isMounted]);

  // 更新 TransformControls
  useEffect(() => {
    if (!transformControlsRef.current || !sceneRef.current) return;

    const productGroup = sceneRef.current.getObjectByName('products');
    if (!productGroup) return;

    if (mode === 'move' && selectedObjectUuid) {
      const selectedObject = productGroup.getObjectByName(selectedObjectUuid);
      if (selectedObject) {
        transformControlsRef.current.attach(selectedObject);
      } else {
        transformControlsRef.current.detach();
      }
    } else {
      transformControlsRef.current.detach();
    }
  }, [mode, selectedObjectUuid]);

  // 更新摄影参数
  useEffect(() => {
    if (!rendererRef.current || !composerRef.current) return;

    const renderer = rendererRef.current;
    const composer = composerRef.current;

    renderer.toneMappingExposure = photographyParams.exposure;

    // 更新 Vignette 参数
    const vignettePass = composer.passes[2] as ShaderPass;
    if (vignettePass && vignettePass.uniforms) {
      vignettePass.uniforms.darkness.value = photographyParams.brightness;
    }
  }, [photographyParams]);

  // 加载自定义 HDR
  useEffect(() => {
    if (!sceneRef.current || !customHdrUrl) return;

    const loader = new RGBELoader();
    loader.load(
      customHdrUrl,
      (texture) => {
        texture.mapping = THREE.EquirectangularReflectionMapping;
        sceneRef.current!.environment = texture;
        sceneRef.current!.background = texture;
      },
      undefined,
      (error) => {
        console.error('Failed to load HDR:', error);
      }
    );
  }, [customHdrUrl]);

  // 捕获相机位置
  const captureCameraPosition = useCallback(() => {
    if (!cameraRef.current || !controlsRef.current) return null;

    return {
      position: cameraRef.current.position.clone(),
      target: controlsRef.current.target.clone(),
    };
  }, []);

  // 导出渲染图像
  const exportRender = useCallback(() => {
    if (!rendererRef.current) return null;

    const renderer = rendererRef.current;
    renderer.render(sceneRef.current!, cameraRef.current!);

    const dataURL = renderer.domElement.toDataURL('image/png');
    return dataURL;
  }, []);

  // 暴露方法给父组件
  useEffect(() => {
    if (onCameraChange) {
      const interval = setInterval(() => {
        const cam = captureCameraPosition();
        if (cam) {
          onCameraChange(cam.position, cam.target);
        }
      }, 500);

      return () => clearInterval(interval);
    }
  }, [captureCameraPosition, onCameraChange]);

  return (
    <div ref={containerRef} className="w-full h-full" style={{ minHeight: '100%' }} />
  );
}
