'use client';

import {
  Move3D,
  Palette,
  Lightbulb,
  Globe,
  Sparkles,
  Type,
} from 'lucide-react';

import { Button } from '@/components/ui/button';

type ToolType = 'transform' | 'material' | 'light' | 'environment' | 'post' | 'text' | null;

interface BottomToolbarProps {
  activeTool: ToolType;
  onToolChange: (tool: ToolType) => void;
}

const tools = [
  {
    id: 'transform' as const,
    icon: Move3D,
  },
  {
    id: 'material' as const,
    icon: Palette,
  },
  {
    id: 'light' as const,
    icon: Lightbulb,
  },
  {
    id: 'environment' as const,
    icon: Globe,
  },
  {
    id: 'post' as const,
    icon: Sparkles,
  },
  {
    id: 'text' as const,
    icon: Type,
  },
];

export function BottomToolbar({ activeTool, onToolChange }: BottomToolbarProps) {
  return (
    <>
      {/* Bottom Toolbar - Figma Style with Premium Look */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-30">
        <div className="relative">
          {/* Glow Effect - Using violet-600 to indigo-600 gradient */}
          <div className="absolute inset-0 bg-gradient-to-r from-violet-600/20 via-indigo-600/20 to-violet-600/20 blur-xl -z-10 rounded-xl" />

          {/* Main Toolbar */}
          <div className="flex items-center gap-1 bg-gradient-to-br from-background/95 to-background/90 backdrop-blur-xl border border-border/40 rounded-xl shadow-2xl shadow-black/40 p-1.5">
            {tools.map((tool, index) => {
              const Icon = tool.icon;
              const isActive = activeTool === tool.id;

              return (
                <div key={tool.id} className="flex items-center">
                  {index > 0 && (
                    <div className="w-px h-7 bg-gradient-to-b from-transparent via-border/50 to-transparent mx-1.5" />
                  )}
                  <Button
                    variant="ghost"
                    onClick={() => onToolChange(isActive ? null : tool.id)}
                    className={`
                      h-9 w-9 p-0 rounded-lg relative overflow-hidden
                      transition-all duration-300 ease-out
                      ${isActive
                        ? 'bg-gradient-to-br from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-500/50 ring-2 ring-violet-500/30'
                        : 'text-muted-foreground hover:text-white hover:bg-gradient-to-br hover:from-violet-600 hover:to-indigo-600 hover:shadow-lg hover:shadow-violet-500/30'
                      }
                    `}
                    title={tool.id.charAt(0).toUpperCase() + tool.id.slice(1)}
                  >
                    <Icon className="h-4 w-4 relative z-10" />
                  </Button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}
