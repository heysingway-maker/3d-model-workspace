'use client';

import { useEffect, useState, useRef, useMemo } from 'react';
import { createPortal } from 'react-dom';
import * as THREE from 'three';
import { useColorSwatchStore, ColorSwatch } from '@/store/colorSwatchStore';
import { Trash2, Eye, EyeOff, Edit3 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ColorSwatchOverlayProps {
  camera: THREE.PerspectiveCamera | null;
  scene: THREE.Scene | null;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
}

export function ColorSwatchOverlay({ camera, scene, canvasRef }: ColorSwatchOverlayProps) {
  const [swatchPositions, setSwatchPositions] = useState<Map<string, { x: number; y: number }>>(new Map());
  const [editingSwatch, setEditingSwatch] = useState<ColorSwatch | null>(null);
  const [toggledVisibility, setToggledVisibility] = useState<Set<string>>(new Set());
  const animationFrameRef = useRef<number>(0);
  const cameraRef = useRef(camera);
  const sceneRef = useRef(scene);

  const {
    colorSwatches,
    removeColorSwatch,
    updateColorSwatch,
    hoveredSwatchId,
    setHoveredSwatch,
  } = useColorSwatchStore();

  // Derive visible swatches from store state and local toggles
  const visibleSwatches = useMemo(() => {
    const visible = new Set(colorSwatches.filter(s => s.visible).map(s => s.id));
    toggledVisibility.forEach(id => {
      if (visible.has(id)) {
        visible.delete(id);
      }
    });
    return visible;
  }, [colorSwatches, toggledVisibility]);

  // Keep refs updated via useEffect
  useEffect(() => {
    cameraRef.current = camera;
    sceneRef.current = scene;
  }, [camera, scene]);

  // Animation loop for smooth position updates
  useEffect(() => {
    const updatePositions = () => {
      const cam = cameraRef.current;
      const scn = sceneRef.current;
      const canvas = canvasRef.current;
      if (!cam || !scn || !canvas) return;

      const newPositions = new Map<string, { x: number; y: number }>();
      const rect = canvas.getBoundingClientRect();

      colorSwatches.forEach((swatch) => {
        if (!visibleSwatches.has(swatch.id)) return;

        // Get world position of the swatch
        const worldPos = new THREE.Vector3(swatch.position.x, swatch.position.y, swatch.position.z);

        // Project to screen coordinates
        const screenPos = worldPos.clone().project(cam);

        // Check if in front of camera
        if (screenPos.z > 1) return;

        // Convert to DOM coordinates
        const x = ((screenPos.x + 1) / 2) * rect.width + rect.left;
        const y = ((-screenPos.y + 1) / 2) * rect.height + rect.top;

        newPositions.set(swatch.id, { x, y });
      });

      setSwatchPositions(newPositions);
    };

    const animate = () => {
      updatePositions();
      animationFrameRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameRef.current);
    };
  }, [colorSwatches, visibleSwatches, canvasRef]);

  const handleEditSwatch = (swatch: ColorSwatch) => {
    setEditingSwatch(swatch);
  };

  const handleSaveEdit = (updates: Partial<ColorSwatch>) => {
    if (editingSwatch) {
      updateColorSwatch(editingSwatch.id, updates);
      setEditingSwatch(null);
    }
  };

  const handleDeleteSwatch = (id: string) => {
    removeColorSwatch(id);
  };

  const handleToggleVisibility = (id: string) => {
    setToggledVisibility(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  return createPortal(
    <div className="fixed inset-0 pointer-events-none z-10">
      {/* Color Swatches */}
      {colorSwatches.map((swatch) => {
        const pos = swatchPositions.get(swatch.id);
        if (!pos || !visibleSwatches.has(swatch.id)) return null;

        const isHovered = hoveredSwatchId === swatch.id;

        return (
          <div
            key={swatch.id}
            className="absolute pointer-events-auto"
            style={{
              left: pos.x,
              top: pos.y,
              transform: 'translate(-50%, -50%)',
            }}
            onMouseEnter={() => setHoveredSwatch(swatch.id)}
            onMouseLeave={() => setHoveredSwatch(null)}
          >
            {/* Swatch Card */}
            <div
              className={`
                relative rounded-xl shadow-2xl transition-all duration-200 cursor-pointer overflow-hidden
                ${isHovered ? 'scale-105 shadow-2xl ring-2 ring-white/50' : 'ring-1 ring-white/20'}
              `}
              style={{
                backgroundColor: 'rgba(0, 0, 0, 0.85)',
                backdropFilter: 'blur(12px)',
                minWidth: '160px',
              }}
            >
              {/* Color Preview */}
              <div
                className="h-12 w-full"
                style={{ backgroundColor: swatch.colorCode }}
              />
              
              {/* Info Content */}
              <div className="p-3 space-y-2">
                {/* Color Code & Name */}
                <div className="flex items-center gap-2">
                  <div className="text-xs font-mono text-gray-400">{swatch.colorCode}</div>
                  <div className="text-sm font-medium text-white truncate">{swatch.colorName}</div>
                </div>
                
                {/* Product Info */}
                <div className="space-y-1 text-xs">
                  {swatch.styleName && (
                    <div className="text-gray-300">{swatch.styleName}</div>
                  )}
                  {swatch.price && (
                    <div className="text-lg font-bold text-emerald-400">{swatch.price}</div>
                  )}
                  {swatch.stock && (
                    <div className={`font-medium ${
                      swatch.stock === '缺货' || swatch.stock === '已售罄' 
                        ? 'text-red-400' 
                        : 'text-green-400'
                    }`}>
                      {swatch.stock}
                    </div>
                  )}
                </div>
              </div>

              {/* Actions (shown on hover) */}
              {isHovered && (
                <div className="absolute top-2 right-2 flex gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-white/80 hover:text-white hover:bg-white/20 bg-black/40"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleEditSwatch(swatch);
                    }}
                  >
                    <Edit3 className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-white/80 hover:text-white hover:bg-white/20 bg-black/40"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleVisibility(swatch.id);
                    }}
                  >
                    {visibleSwatches.has(swatch.id) ? (
                      <Eye className="w-3 h-3" />
                    ) : (
                      <EyeOff className="w-3 h-3" />
                    )}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-red-400/80 hover:text-red-400 hover:bg-red-500/20 bg-black/40"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteSwatch(swatch.id);
                    }}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>
          </div>
        );
      })}

      {/* Edit Modal */}
      {editingSwatch && createPortal(
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
          onClick={() => setEditingSwatch(null)}
        >
          <div
            className="bg-gray-900 border border-white/10 rounded-xl p-4 w-80"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Color Preview */}
            <div
              className="h-16 w-full rounded-lg mb-4"
              style={{ backgroundColor: editingSwatch.colorCode }}
            />
            
            <h3 className="text-sm font-medium text-white mb-3">Edit Color Swatch</h3>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-gray-400 block mb-1">Color Code</label>
                <input
                  type="text"
                  value={editingSwatch.colorCode}
                  onChange={(e) => setEditingSwatch({ ...editingSwatch, colorCode: e.target.value })}
                  className="w-full bg-black/50 border border-white/10 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-violet-500"
                  placeholder="#FF6B6B"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">Color Name</label>
                <input
                  type="text"
                  value={editingSwatch.colorName}
                  onChange={(e) => setEditingSwatch({ ...editingSwatch, colorName: e.target.value })}
                  className="w-full bg-black/50 border border-white/10 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-violet-500"
                  placeholder="珊瑚红"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">Style / 款式</label>
                <input
                  type="text"
                  value={editingSwatch.styleName}
                  onChange={(e) => setEditingSwatch({ ...editingSwatch, styleName: e.target.value })}
                  className="w-full bg-black/50 border border-white/10 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-violet-500"
                  placeholder="滋润款"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">Price / 价格</label>
                <input
                  type="text"
                  value={editingSwatch.price}
                  onChange={(e) => setEditingSwatch({ ...editingSwatch, price: e.target.value })}
                  className="w-full bg-black/50 border border-white/10 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-violet-500"
                  placeholder="¥199"
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 block mb-1">Stock / 库存</label>
                <input
                  type="text"
                  value={editingSwatch.stock}
                  onChange={(e) => setEditingSwatch({ ...editingSwatch, stock: e.target.value })}
                  className="w-full bg-black/50 border border-white/10 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-violet-500"
                  placeholder="充足"
                />
              </div>
              <div className="flex gap-2 pt-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setEditingSwatch(null)}
                  className="flex-1 bg-white/5 border-white/10 hover:bg-white/10"
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => handleSaveEdit(editingSwatch)}
                  className="flex-1 bg-violet-600 hover:bg-violet-700"
                >
                  Save
                </Button>
              </div>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>,
    document.body
  );
}
