'use client';

import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { DecalGeometry } from 'three/examples/jsm/geometries/DecalGeometry.js';
import { useEffect, useRef, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ZoomIn, ZoomOut, Check, X, Trash2, RotateCcw, Move3d } from 'lucide-react';

interface DecalMappingProps {
  modelUrl: string;
  labelImage: string;
  onDecalCreated: (decalMesh: THREE.Mesh, textureBlob: Blob) => void;
  onCancel: () => void;
}

export function DecalMapping({ modelUrl, labelImage, onDecalCreated, onCancel }: DecalMappingProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const modelGroupRef = useRef<THREE.Group | null>(null);
  const mainMeshRef = useRef<THREE.Mesh | null>(null);
  const decalMeshRef = useRef<THREE.Mesh | null>(null);
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster());
  const mouseRef = useRef<THREE.Vector2>(new THREE.Vector2());
  const textureRef = useRef<THREE.Texture | null>(null);
  const animationFrameRef = useRef<number>(0);

  const [decalSize, setDecalSize] = useState(0.3);
  const [decalRotation, setDecalRotation] = useState(0);
  const [decalPosition, setDecalPosition] = useState<THREE.Vector3 | null>(null);
  const [isPlaced, setIsPlaced] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isTextureLoading, setIsTextureLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load texture
  useEffect(() => {
    setIsTextureLoading(true);
    const loader = new THREE.TextureLoader();
    loader.load(
      labelImage,
      (texture) => {
        texture.flipY = false;
        texture.colorSpace = THREE.SRGBColorSpace;
        textureRef.current = texture;
        setIsTextureLoading(false);
        console.log('✅ Texture loaded');
      },
      undefined,
      (err) => {
        console.error('Failed to load texture:', err);
        setError('Failed to load label image');
        setIsTextureLoading(false);
      }
    );
  }, [labelImage]);

  // Initialize scene
  useEffect(() => {
    if (!containerRef.current) return;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x1a1a2e);
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(
      50,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.set(0, 0.5, 2.5);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1;
    renderer.setClearColor(0x1a1a2e, 1);
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.enableZoom = true;
    controls.enablePan = true;
    controls.enableRotate = true;
    controls.minDistance = 0.5;
    controls.maxDistance = 5;
    controlsRef.current = controls;

    // Lights - ensure model is well lit
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xffffff, 1.5);
    mainLight.position.set(5, 8, 5);
    mainLight.castShadow = true;
    mainLight.shadow.mapSize.width = 1024;
    mainLight.shadow.mapSize.height = 1024;
    scene.add(mainLight);

    const fillLight = new THREE.DirectionalLight(0xffffff, 0.5);
    fillLight.position.set(-3, 3, -3);
    scene.add(fillLight);

    const backLight = new THREE.DirectionalLight(0xffffff, 0.3);
    backLight.position.set(0, 2, -5);
    scene.add(backLight);

    // Ground plane
    const groundGeometry = new THREE.PlaneGeometry(10, 10);
    const groundMaterial = new THREE.ShadowMaterial({ opacity: 0.15 });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.5;
    ground.receiveShadow = true;
    scene.add(ground);

    // Animation loop
    const animate = () => {
      animationFrameRef.current = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    // Resize handler
    const handleResize = () => {
      if (!containerRef.current || !camera || !renderer) return;
      camera.aspect = containerRef.current.clientWidth / containerRef.current.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    // Click handler for placing decal
    const handleClick = (event: MouseEvent) => {
      if (!containerRef.current || !camera || !scene || !modelGroupRef.current || !mainMeshRef.current) return;
      if (isTextureLoading || isLoading) return;

      const rect = containerRef.current.getBoundingClientRect();
      mouseRef.current.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouseRef.current.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycasterRef.current.setFromCamera(mouseRef.current, camera);
      
      // Only intersect with the actual model meshes, not helpers
      const meshes: THREE.Mesh[] = [];
      modelGroupRef.current.traverse((child) => {
        if (child instanceof THREE.Mesh && !child.name.includes('helper') && !child.name.includes('decal')) {
          meshes.push(child);
        }
      });

      const intersects = raycasterRef.current.intersectObjects(meshes, true);

      if (intersects.length > 0) {
        const intersection = intersects[0];
        const position = intersection.point.clone();
        
        // Transform to local coordinates of the mesh
        const localPosition = mainMeshRef.current.worldToLocal(position.clone());
        const normal = intersection.face?.normal?.clone() || new THREE.Vector3(0, 1, 0);
        
        // Transform normal to world space
        normal.transformDirection(mainMeshRef.current.matrixWorld);
        
        console.log('✅ Clicked on model at local position:', localPosition);
        
        setDecalPosition(localPosition);
        createOrUpdateDecal(localPosition, normal);
        setIsPlaced(true);
      }
    };

    renderer.domElement.addEventListener('click', handleClick);

    return () => {
      cancelAnimationFrame(animationFrameRef.current);
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('click', handleClick);
      controls.dispose();
      renderer.dispose();
      
      // Cleanup textures and geometries
      if (textureRef.current) {
        textureRef.current.dispose();
      }
      if (decalMeshRef.current) {
        decalMeshRef.current.geometry?.dispose();
        if (decalMeshRef.current.material instanceof THREE.Material) {
          decalMeshRef.current.material.dispose();
        }
      }
      
      if (containerRef.current && renderer.domElement.parentNode === containerRef.current) {
        containerRef.current.removeChild(renderer.domElement);
      }
    };
  }, [modelUrl, isTextureLoading, isLoading]);

  // Create or update decal
  const createOrUpdateDecal = useCallback((localPosition: THREE.Vector3, normal: THREE.Vector3) => {
    if (!sceneRef.current || !mainMeshRef.current || !textureRef.current) {
      console.log('Missing refs for decal creation:', {
        hasScene: !!sceneRef.current,
        hasMesh: !!mainMeshRef.current,
        hasTexture: !!textureRef.current
      });
      return;
    }

    // Remove existing decal
    if (decalMeshRef.current) {
      sceneRef.current.remove(decalMeshRef.current);
      decalMeshRef.current.geometry?.dispose();
      if (decalMeshRef.current.material instanceof THREE.Material) {
        decalMeshRef.current.material.dispose();
      }
      decalMeshRef.current = null;
    }

    // Create decal material
    const material = new THREE.MeshPhongMaterial({
      map: textureRef.current,
      transparent: true,
      depthTest: true,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -4,
    });

    // Calculate orientation based on normal
    // Default orientation with rotation
    const euler = new THREE.Euler();
    euler.setFromVector3(new THREE.Vector3(0, 0, 1), 'XYZ');
    euler.z = THREE.MathUtils.degToRad(decalRotation);

    // Size
    const size = new THREE.Vector3(decalSize, decalSize, decalSize);

    try {
      // Create decal geometry
      const geometry = new DecalGeometry(mainMeshRef.current, localPosition, euler, size);
      const mesh = new THREE.Mesh(geometry, material);
      mesh.name = 'decal-mesh';
      
      // Add to the main mesh so it follows the model's transform
      mainMeshRef.current.add(mesh);
      decalMeshRef.current = mesh;
      
      console.log('✅ Decal created successfully');
    } catch (err) {
      console.error('Failed to create decal geometry:', err);
    }
  }, [decalSize, decalRotation]);

  // Update decal when parameters change
  useEffect(() => {
    if (decalPosition && mainMeshRef.current && textureRef.current) {
      const normal = new THREE.Vector3(0, 0, 1);
      normal.transformDirection(mainMeshRef.current.matrixWorld);
      createOrUpdateDecal(decalPosition, normal);
    }
  }, [decalSize, decalRotation, decalPosition, createOrUpdateDecal]);

  // Load GLB model
  useEffect(() => {
    if (!sceneRef.current || !cameraRef.current || !rendererRef.current) return;

    const scene = sceneRef.current;
    const camera = cameraRef.current;
    const renderer = rendererRef.current;

    const loadModel = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        const { GLTFLoader } = await import('three/examples/jsm/loaders/GLTFLoader.js');
        const loader = new GLTFLoader();

        loader.load(
          modelUrl,
          (gltf) => {
            const model = gltf.scene;
            modelGroupRef.current = model;

            // Center and scale model
            const box = new THREE.Box3().setFromObject(model);
            const center = box.getCenter(new THREE.Vector3());
            const size = box.getSize(new THREE.Vector3());
            const maxDim = Math.max(size.x, size.y, size.z);
            const scale = 1.5 / maxDim;

            model.scale.setScalar(scale);
            model.position.sub(center.multiplyScalar(scale));

            // Find and configure main mesh
            let foundMesh: THREE.Mesh | null = null;
            let meshCount = 0;
            
            model.traverse((child) => {
              if (child instanceof THREE.Mesh) {
                meshCount++;
                
                // Ensure mesh is visible
                child.visible = true;
                child.castShadow = true;
                child.receiveShadow = true;
                
                // Preserve original material or create a default one
                if (!child.material) {
                  child.material = new THREE.MeshStandardMaterial({
                    color: 0xffffff,
                    roughness: 0.5,
                    metalness: 0.1,
                  });
                }
                
                // Mark first mesh as main mesh
                if (!foundMesh) {
                  foundMesh = child;
                }
              }
            });

            if (foundMesh) {
              mainMeshRef.current = foundMesh;
              console.log('✅ Model loaded, found', meshCount, 'meshes, mainMesh:', (foundMesh as THREE.Mesh).name);
            } else {
              console.error('❌ No mesh found in model!');
            }

            scene.add(model);
            
            // Initial render to ensure model is visible
            renderer.render(scene, camera);
            
            setIsLoading(false);
          },
          (progress) => {
            if (progress.total > 0) {
              console.log('Loading:', (progress.loaded / progress.total * 100).toFixed(1) + '%');
            }
          },
          (err) => {
            console.error('Error loading model:', err);
            setError('Failed to load model');
            setIsLoading(false);
          }
        );
      } catch (err) {
        console.error('Failed to initialize model loader:', err);
        setError('Failed to initialize');
        setIsLoading(false);
      }
    };

    loadModel();
  }, [modelUrl]);

  // Confirm and apply decal
  const handleConfirm = () => {
    if (!decalMeshRef.current || !textureRef.current) {
      console.error('No decal to apply');
      return;
    }

    console.log('✅ Applying decal...');

    // Create blob from texture
    const canvas = document.createElement('canvas');
    const texture = textureRef.current;
    const img = texture.image as HTMLImageElement;
    
    if (img && img.width && img.height) {
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0);
        canvas.toBlob((blob) => {
          if (blob) {
            onDecalCreated(decalMeshRef.current!, blob);
          } else {
            console.error('Failed to create blob');
          }
        }, 'image/png');
      }
    } else {
      // Fallback: create empty blob
      canvas.width = 512;
      canvas.height = 512;
      canvas.toBlob((blob) => {
        if (blob) {
          onDecalCreated(decalMeshRef.current!, blob);
        }
      }, 'image/png');
    }
  };

  // Remove decal
  const handleRemove = () => {
    if (decalMeshRef.current) {
      // Remove from parent (either scene or mainMesh)
      if (decalMeshRef.current.parent) {
        decalMeshRef.current.parent.remove(decalMeshRef.current);
      }
      decalMeshRef.current.geometry?.dispose();
      if (decalMeshRef.current.material instanceof THREE.Material) {
        decalMeshRef.current.material.dispose();
      }
      decalMeshRef.current = null;
    }
    setIsPlaced(false);
    setDecalPosition(null);
  };

  // Camera controls
  const handleZoomIn = () => {
    if (!cameraRef.current || !controlsRef.current) return;
    cameraRef.current.position.z = Math.max(cameraRef.current.position.z - 0.3, 0.3);
    controlsRef.current.update();
  };

  const handleZoomOut = () => {
    if (!cameraRef.current || !controlsRef.current) return;
    cameraRef.current.position.z = Math.min(cameraRef.current.position.z + 0.3, 5);
    controlsRef.current.update();
  };

  const handleResetView = () => {
    if (!cameraRef.current || !controlsRef.current) return;
    cameraRef.current.position.set(0, 0.5, 2.5);
    controlsRef.current.update();
  };

  const isReady = !isLoading && !isTextureLoading && !error;

  return (
    <Card className="fixed inset-4 z-50 bg-gray-900/95 backdrop-blur-xl border-gray-800/50 rounded-2xl flex overflow-hidden">
      {/* Left Panel - 3D Viewer */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-gray-800/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-600 to-indigo-600 flex items-center justify-center">
                <Move3d className="w-4 h-4 text-white" />
              </div>
              <div>
                <h2 className="text-sm font-semibold text-white">Place Label on Model</h2>
                <p className="text-xs text-gray-400">
                  {isLoading ? 'Loading model...' : 
                   isTextureLoading ? 'Loading texture...' : 
                   !isPlaced ? 'Click on the model to place label' : 
                   'Adjust and confirm'}
                </p>
              </div>
            </div>
            
            {/* Camera Controls */}
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="icon"
                onClick={handleZoomOut}
                disabled={!isReady}
                className="h-8 w-8 bg-gray-800/50 border-gray-700/50 text-gray-300 hover:bg-gray-800"
              >
                <ZoomOut className="w-4 h-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={handleZoomIn}
                disabled={!isReady}
                className="h-8 w-8 bg-gray-800/50 border-gray-700/50 text-gray-300 hover:bg-gray-800"
              >
                <ZoomIn className="w-4 h-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={handleResetView}
                disabled={!isReady}
                className="h-8 w-8 bg-gray-800/50 border-gray-700/50 text-gray-300 hover:bg-gray-800"
              >
                <RotateCcw className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* 3D Viewport */}
        <div ref={containerRef} className="flex-1 relative bg-gradient-to-b from-gray-900 to-gray-950" />
        
        {/* Status Bar */}
        <div className="px-4 py-2 bg-gray-800/30 border-t border-gray-800/20">
          <div className="flex items-center justify-between text-xs text-gray-400">
            <div className="flex items-center gap-4">
              <span>Left-click to place</span>
              <span>Drag to rotate</span>
              <span>Scroll to zoom</span>
            </div>
            {isPlaced && (
              <span className="text-green-400">Label placed - adjust below</span>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-4 border-t border-gray-800/30 bg-gray-900/50">
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={onCancel}
              className="h-10 px-4 bg-gray-800/50 border-gray-700/50 text-gray-300 hover:bg-gray-700"
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>

            <div className="flex-1" />

            <Button
              variant="outline"
              size="sm"
              onClick={handleRemove}
              disabled={!isPlaced}
              className="h-10 px-4 bg-gray-800/50 border-gray-700/50 text-gray-300 hover:bg-gray-700 disabled:opacity-40"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Remove
            </Button>

            <Button
              variant="default"
              size="sm"
              onClick={handleConfirm}
              disabled={!isPlaced || !isReady}
              className="h-10 px-6 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-medium disabled:opacity-40"
            >
              <Check className="w-4 h-4 mr-2" />
              Apply Label
            </Button>
          </div>
        </div>
      </div>

      {/* Right Panel - Controls */}
      <div className="w-80 border-l border-gray-800/30 bg-gray-900/50 flex flex-col">
        <div className="p-4 border-b border-gray-800/30">
          <h3 className="text-sm font-medium text-white">Label Settings</h3>
          {error && (
            <p className="text-xs text-red-400 mt-1">{error}</p>
          )}
          {(isLoading || isTextureLoading) && (
            <p className="text-xs text-yellow-400 mt-1">
              {isLoading ? 'Loading model...' : 'Loading texture...'}
            </p>
          )}
        </div>

        <div className="flex-1 p-4 space-y-6 overflow-y-auto">
          {/* Size Control */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-medium text-gray-300">Size</label>
              <span className="text-xs text-violet-400 font-mono">{decalSize.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.1"
              max="1.0"
              step="0.05"
              value={decalSize}
              onChange={(e) => setDecalSize(parseFloat(e.target.value))}
              disabled={!isReady}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-violet-500"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>Small</span>
              <span>Large</span>
            </div>
          </div>

          {/* Rotation Control */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-medium text-gray-300">Rotation</label>
              <span className="text-xs text-violet-400 font-mono">{decalRotation}°</span>
            </div>
            <input
              type="range"
              min="0"
              max="360"
              step="15"
              value={decalRotation}
              onChange={(e) => setDecalRotation(parseInt(e.target.value))}
              disabled={!isReady}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-violet-500"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>0°</span>
              <span>360°</span>
            </div>
          </div>

          {/* Quick Presets */}
          <div className="space-y-2">
            <label className="text-xs font-medium text-gray-300">Quick Size</label>
            <div className="grid grid-cols-4 gap-2">
              {[0.15, 0.25, 0.4, 0.6].map((size) => (
                <button
                  key={size}
                  onClick={() => setDecalSize(size)}
                  disabled={!isReady}
                  className={`py-2 px-3 text-xs rounded-lg border transition-colors ${
                    Math.abs(decalSize - size) < 0.01
                      ? 'bg-violet-600 border-violet-500 text-white'
                      : 'bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700'
                  } disabled:opacity-40`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Tips */}
          <div className="p-3 rounded-lg bg-blue-900/30 border border-blue-800/50">
            <p className="text-xs text-blue-300">
              <strong>Tips:</strong> Click anywhere on the model to place the label. 
              Adjust size and rotation above, then click "Apply Label" to confirm.
            </p>
          </div>
        </div>
      </div>
    </Card>
  );
}
