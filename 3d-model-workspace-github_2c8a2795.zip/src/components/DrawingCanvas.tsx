'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { useCanvasStore } from '@/store/canvasStore';

export default function DrawingCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const ctxRef = useRef<CanvasRenderingContext2D | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentPoints, setCurrentPoints] = useState<{ x: number; y: number }[]>([]);
  const [startPoint, setStartPoint] = useState<{ x: number; y: number } | null>(null);
  const layerImagesRef = useRef<Map<string, HTMLImageElement>>(new Map());

  const { canvasData, toolState, addStroke, saveHistory } = useCanvasStore();
  const activeLayerId = canvasData.activeLayerId;

  // Preload layer images
  const preloadImages = useCallback(async () => {
    const imageLayers = canvasData.layers.filter(
      (layer) => (layer.type === 'background' || layer.type === 'image') && layer.backgroundImage
    );

    const loadPromises = imageLayers.map((layer) => {
      return new Promise<void>((resolve) => {
        if (layerImagesRef.current.has(layer.id)) {
          resolve();
          return;
        }
        const img = new Image();
        img.src = layer.backgroundImage!;
        img.onload = () => {
          layerImagesRef.current.set(layer.id, img);
          resolve();
        };
        img.onerror = () => {
          console.error(`Failed to load image for layer ${layer.id}`);
          resolve();
        };
        // If already cached
        if (img.complete) {
          layerImagesRef.current.set(layer.id, img);
          resolve();
        }
      });
    });

    await Promise.all(loadPromises);
  }, [canvasData.layers]);

  // Render canvas with all layers
  const renderCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = ctxRef.current;
    if (!canvas || !ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Fill with white background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Sort layers by zIndex
    const sortedLayers = [...canvasData.layers].sort((a, b) => a.zIndex - b.zIndex);

    // Render each layer
    sortedLayers.forEach((layer) => {
      if (!layer.visible) return;

      // Render background image (for both background and image type layers)
      if ((layer.type === 'background' || layer.type === 'image') && layer.backgroundImage) {
        const img = layerImagesRef.current.get(layer.id);
        if (img && img.complete) {
          ctx.globalAlpha = 1;
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        }
      }

      // Render strokes
      layer.strokes.forEach((stroke) => {
        ctx.globalAlpha = stroke.opacity;
        ctx.strokeStyle = stroke.tool === 'eraser' ? '#ffffff' : stroke.color;
        ctx.lineWidth = stroke.size;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';

        if (stroke.points.length < 2) return;

        ctx.beginPath();
        ctx.moveTo(stroke.points[0].x, stroke.points[0].y);

        for (let i = 1; i < stroke.points.length; i++) {
          ctx.lineTo(stroke.points[i].x, stroke.points[i].y);
        }

        ctx.stroke();
      });
    });

    // Reset global alpha
    ctx.globalAlpha = 1;
  }, []);

  // Initialize canvas and load images
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    ctxRef.current = ctx;

    // Preload images then render
    preloadImages().then(() => {
      renderCanvas();
    });
  }, [canvasData, preloadImages, renderCanvas]);

  // Handle mouse down
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    // Check if there's an active layer
    if (!activeLayerId) {
      console.warn('No active layer selected');
      return;
    }

    // Check if active layer is locked
    const activeLayer = canvasData.layers.find((l) => l.id === activeLayerId);
    if (activeLayer?.locked) {
      console.warn('Active layer is locked');
      return;
    }

    setIsDrawing(true);

    if (toolState.tool === 'rectangle' || toolState.tool === 'circle' || toolState.tool === 'line') {
      setStartPoint({ x, y });
      setCurrentPoints([{ x, y }]);
    } else {
      setCurrentPoints([{ x, y }]);
    }
  };

  // Handle mouse move
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;

    const canvas = canvasRef.current;
    const ctx = ctxRef.current;
    if (!canvas || !ctx) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    if (toolState.tool === 'pen' || toolState.tool === 'eraser') {
      // Freehand drawing
      setCurrentPoints((prev) => [...prev, { x, y }]);

      // Render in real-time
      ctx.globalAlpha = toolState.brushOpacity;
      ctx.strokeStyle = toolState.tool === 'eraser' ? '#ffffff' : toolState.brushColor;
      ctx.lineWidth = toolState.brushSize;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      if (currentPoints.length > 0) {
        ctx.beginPath();
        ctx.moveTo(currentPoints[currentPoints.length - 1].x, currentPoints[currentPoints.length - 1].y);
        ctx.lineTo(x, y);
        ctx.stroke();
      }
    } else if (toolState.tool === 'rectangle' || toolState.tool === 'circle' || toolState.tool === 'line') {
      // Shape preview
      setCurrentPoints((prev) => [...prev.slice(0, 1), { x, y }]);

      // Re-render canvas with preview
      renderCanvas();

      // Draw shape preview
      ctx.globalAlpha = toolState.brushOpacity;
      ctx.strokeStyle = toolState.brushColor;
      ctx.lineWidth = toolState.brushSize;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      if (startPoint) {
        ctx.beginPath();
        if (toolState.tool === 'rectangle') {
          const width = x - startPoint.x;
          const height = y - startPoint.y;
          ctx.rect(startPoint.x, startPoint.y, width, height);
        } else if (toolState.tool === 'circle') {
          const radius = Math.sqrt(Math.pow(x - startPoint.x, 2) + Math.pow(y - startPoint.y, 2));
          ctx.arc(startPoint.x, startPoint.y, radius, 0, Math.PI * 2);
        } else if (toolState.tool === 'line') {
          ctx.moveTo(startPoint.x, startPoint.y);
          ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
    }

    ctx.globalAlpha = 1;
  };

  // Handle mouse up
  const handleMouseUp = () => {
    if (!isDrawing) return;

    setIsDrawing(false);

    if (currentPoints.length > 0 && activeLayerId) {
      // Add stroke to store
      addStroke({
        points: currentPoints,
        color: toolState.brushColor,
        size: toolState.brushSize,
        opacity: toolState.brushOpacity,
        layerId: activeLayerId,
        tool: toolState.tool,
      });

      // Save to history
      saveHistory();
    }

    setCurrentPoints([]);
    setStartPoint(null);
    // Note: renderCanvas will be called automatically when canvasData updates via useEffect
  };

  // Handle mouse leave
  const handleMouseLeave = () => {
    if (isDrawing) {
      handleMouseUp();
    }
  };

  return (
    <canvas
      ref={canvasRef}
      width={canvasData.width}
      height={canvasData.height}
      className="w-full h-full bg-white cursor-crosshair"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseLeave}
    />
  );
}
