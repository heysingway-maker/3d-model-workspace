'use client';

import { useState, useRef } from 'react';
import {
  Pencil,
  Eraser,
  Square,
  Circle,
  Minus,
  MousePointer2,
  Undo2,
  Redo2,
  Download,
  ChevronDown,
  ChevronUp,
  ImagePlus,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCanvasStore, ToolType } from '@/store/canvasStore';

export default function DrawingToolbar() {
  const {
    toolState,
    setTool,
    setBrushSize,
    setBrushColor,
    setBrushOpacity,
    undo,
    redo,
    canUndo,
    canRedo,
    exportToImage,
    addLayerFromImage,
    saveHistory,
  } = useCanvasStore();

  const [showProperties, setShowProperties] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const tools: { type: ToolType; icon: React.ReactNode; label: string }[] = [
    { type: 'pen', icon: <Pencil className="w-4 h-4" />, label: 'Pen' },
    { type: 'eraser', icon: <Eraser className="w-4 h-4" />, label: 'Eraser' },
    { type: 'rectangle', icon: <Square className="w-4 h-4" />, label: 'Rectangle' },
    { type: 'circle', icon: <Circle className="w-4 h-4" />, label: 'Circle' },
    { type: 'line', icon: <Minus className="w-4 h-4" />, label: 'Line' },
  ];

  const presetColors = [
    '#000000',
    '#ffffff',
    '#ef4444',
    '#f97316',
    '#eab308',
    '#22c55e',
    '#06b6d4',
    '#3b82f6',
    '#8b5cf6',
    '#d946ef',
    '#f43f5e',
    '#a1a1aa',
  ];

  const handleExportImage = () => {
    const dataUrl = exportToImage('png');
    if (dataUrl) {
      const link = document.createElement('a');
      link.download = `drawing-${Date.now()}.png`;
      link.href = dataUrl;
      link.click();
    }
  };

  // Handle image upload
  const handleImageUpload = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check if it's an image file
    if (!file.type.startsWith('image/')) {
      alert('Please select an image file');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const imageData = event.target?.result as string;
      if (imageData) {
        // Add image as a new layer
        const layerName = file.name.replace(/\.[^/.]+$/, ''); // Remove extension
        addLayerFromImage(layerName, imageData);
        saveHistory();
      }
    };
    reader.readAsDataURL(file);

    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="h-12 bg-gray-900/80 border-b border-gray-800/30 flex items-center justify-between px-3">
      {/* Left: Tool Selection */}
      <div className="flex items-center gap-1">
        {tools.map((tool) => (
          <Button
            key={tool.type}
            variant="ghost"
            size="icon"
            onClick={() => setTool(tool.type)}
            className={`h-9 w-9 ${
              toolState.tool === tool.type
                ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-500/20'
                : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
            }`}
            title={tool.label}
          >
            {tool.icon}
          </Button>
        ))}
        
        {/* Divider */}
        <div className="w-px h-6 bg-gray-700/50 mx-1" />
        
        {/* Image Upload Button */}
        <Button
          variant="ghost"
          size="icon"
          onClick={handleImageUpload}
          className="h-9 w-9 text-gray-400 hover:text-white hover:bg-gray-800/50"
          title="Add Image"
        >
          <ImagePlus className="w-4 h-4" />
        </Button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
        />
      </div>

      {/* Middle: Properties */}
      {showProperties && (
        <div className="flex items-center gap-6">
          {/* Brush Size */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500 w-8">Size</span>
            <input
              type="range"
              min="1"
              max="50"
              value={toolState.brushSize}
              onChange={(e) => setBrushSize(Number(e.target.value))}
              className="w-24 h-1.5 bg-gray-800/50 rounded-full appearance-none cursor-pointer accent-violet-500"
            />
            <span className="text-xs text-gray-500 w-10 text-right">{toolState.brushSize}px</span>
          </div>

          {/* Opacity */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500 w-8">Opacity</span>
            <input
              type="range"
              min="0.1"
              max="1"
              step="0.1"
              value={toolState.brushOpacity}
              onChange={(e) => setBrushOpacity(Number(e.target.value))}
              className="w-24 h-1.5 bg-gray-800/50 rounded-full appearance-none cursor-pointer accent-violet-500"
            />
            <span className="text-xs text-gray-500 w-10 text-right">{Math.round(toolState.brushOpacity * 100)}%</span>
          </div>

          {/* Color Palette */}
          <div className="flex items-center gap-1.5">
            {presetColors.map((color, index) => (
              <button
                key={color}
                onClick={() => setBrushColor(color)}
                className={`w-6 h-6 rounded-md border-2 transition-all hover:scale-110 ${
                  toolState.brushColor === color
                    ? 'border-violet-500 shadow-lg shadow-violet-500/20 scale-110'
                    : 'border-gray-700/50 hover:border-gray-600/50'
                } ${index < 2 ? 'rounded-full' : ''}`}
                style={{ backgroundColor: color }}
                title={color}
              />
            ))}
            {/* Custom Color Picker */}
            <input
              type="color"
              value={toolState.brushColor}
              onChange={(e) => setBrushColor(e.target.value)}
              className="w-6 h-6 rounded-md cursor-pointer border-2 border-gray-700/50 hover:border-gray-600/50"
              title="Custom Color"
            />
          </div>
        </div>
      )}

      {/* Right: Actions */}
      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="icon"
          onClick={undo}
          disabled={!canUndo()}
          className="h-9 w-9 text-gray-400 hover:text-white hover:bg-gray-800/50 disabled:opacity-30 disabled:cursor-not-allowed"
          title="Undo (Ctrl+Z)"
        >
          <Undo2 className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={redo}
          disabled={!canRedo()}
          className="h-9 w-9 text-gray-400 hover:text-white hover:bg-gray-800/50 disabled:opacity-30 disabled:cursor-not-allowed"
          title="Redo (Ctrl+Y)"
        >
          <Redo2 className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setShowProperties(!showProperties)}
          className="h-9 w-9 text-gray-400 hover:text-white hover:bg-gray-800/50"
          title="Toggle Properties"
        >
          {showProperties ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={handleExportImage}
          className="h-9 w-9 text-gray-400 hover:text-white hover:bg-gray-800/50"
          title="Export to Image"
        >
          <Download className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
