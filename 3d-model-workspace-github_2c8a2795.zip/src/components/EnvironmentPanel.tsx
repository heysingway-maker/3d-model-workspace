'use client';

import { useState, useEffect, useRef } from 'react';
import { useSceneStore, EnvironmentPreset, HDRI_PRESETS } from '@/store/sceneStore';
import * as THREE from 'three';
import { Sun, Upload, Settings, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';

type TabType = 'preset' | 'custom' | 'setting';

interface EnvironmentPanelProps {
  scene?: THREE.Scene | null;
}

// Preset configurations
const presetConfig: Record<
  EnvironmentPreset,
  {
    name: string;
    description: string;
    icon: string;
    backgroundColor: string;
    environmentIntensity: number;
    lightColor: string;
    ambientColor: string;
  }
> = {
  none: {
    name: 'None',
    description: '纯色背景，无环境光',
    icon: '⬛',
    backgroundColor: '#1a1a2e',
    environmentIntensity: 0.8,
    lightColor: '#ffffff',
    ambientColor: '#ffffff',
  },
  studio_09: {
    name: 'Studio 09',
    description: '专业摄影棚 - 白色调',
    icon: '📷',
    backgroundColor: '#2d2d3a',
    environmentIntensity: 1.2,
    lightColor: '#ffffff',
    ambientColor: '#e8e8ff',
  },
  studio_03: {
    name: 'Studio 03',
    description: '明亮摄影棚 - 高亮度',
    icon: '💡',
    backgroundColor: '#3d3d4a',
    environmentIntensity: 1.5,
    lightColor: '#fff5e6',
    ambientColor: '#f0f8ff',
  },
  brown_02: {
    name: 'Brown Studio',
    description: '暖色调摄影棚 - 温馨氛围',
    icon: '🌅',
    backgroundColor: '#4a3c2e',
    environmentIntensity: 1.8,
    lightColor: '#ffcc99',
    ambientColor: '#ff9966',
  },
  neon: {
    name: 'Neon Studio',
    description: '霓虹灯摄影棚 - 夜间效果',
    icon: '✨',
    backgroundColor: '#1a1a3e',
    environmentIntensity: 0.6,
    lightColor: '#e6f0ff',
    ambientColor: '#4060a0',
  },
  warehouse: {
    name: 'Warehouse',
    description: '仓库工业光照',
    icon: '🏭',
    backgroundColor: '#C0C0C0',
    environmentIntensity: 1.0,
    lightColor: '#ffffff',
    ambientColor: '#e0e0e0',
  },
};

export function EnvironmentPanel({ scene }: EnvironmentPanelProps) {
  const { environment, updateEnvironment } = useSceneStore();
  const [activeTab, setActiveTab] = useState<TabType>('preset');
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Handle preset selection
  const handlePresetSelect = (preset: EnvironmentPreset) => {
    const config = presetConfig[preset];
    // 只改变光照效果，不改变背景颜色
    updateEnvironment({
      preset,
      environmentIntensity: config.environmentIntensity,
      lightColor: config.lightColor,
      ambientColor: config.ambientColor,
      hdriUrl: HDRI_PRESETS[preset], // 更新 HDRI URL
      // 不更新 backgroundColor，保持用户自定义的背景色
    });
  };

  // Handle HDRI upload
  const handleHDRIUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);

    try {
      // Read file as data URL
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;

        // Update environment with HDRI URL
        updateEnvironment({
          preset: 'none',
          hdriUrl: dataUrl,
        });

        setUploading(false);
      };
      reader.onerror = () => {
        console.error('Failed to read file');
        setUploading(false);
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Failed to upload HDRI:', error);
      setUploading(false);
    }
  };

  // Clear custom HDRI
  const handleClearHDRI = () => {
    updateEnvironment({
      hdriUrl: null,
    });
  };

  return (
    <div className="flex flex-col h-full">
      {/* Tab Headers */}
      <div className="flex border-b border-white/10">
        <button
          onClick={() => setActiveTab('preset')}
          className={`flex-1 px-4 py-3 text-xs font-medium transition-colors ${
            activeTab === 'preset'
              ? 'text-violet-400 border-b-2 border-violet-400'
              : 'text-white/50 hover:text-white/80'
          }`}
        >
          Preset
        </button>
        <button
          onClick={() => setActiveTab('custom')}
          className={`flex-1 px-4 py-3 text-xs font-medium transition-colors ${
            activeTab === 'custom'
              ? 'text-violet-400 border-b-2 border-violet-400'
              : 'text-white/50 hover:text-white/80'
          }`}
        >
          Custom
        </button>
        <button
          onClick={() => setActiveTab('setting')}
          className={`flex-1 px-4 py-3 text-xs font-medium transition-colors ${
            activeTab === 'setting'
              ? 'text-violet-400 border-b-2 border-violet-400'
              : 'text-white/50 hover:text-white/80'
          }`}
        >
          Settings
        </button>
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {/* Preset Tab */}
        {activeTab === 'preset' && (
          <div className="space-y-3">
            {/* Environment Background Toggle */}
            {environment.preset !== 'none' && environment.hdriUrl && (
              <div className="p-3 rounded-lg bg-white/5 border border-white/10">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium text-white">Show Environment Background</div>
                    <p className="text-xs text-white/50 mt-0.5">
                      {environment.showEnvironmentBackground
                        ? 'HDRI background is visible'
                        : 'Background hidden, lighting effects preserved'}
                    </p>
                  </div>
                  <button
                    onClick={() =>
                      updateEnvironment({ showEnvironmentBackground: !environment.showEnvironmentBackground })
                    }
                    className={`relative w-12 h-6 rounded-full transition-colors ${
                      environment.showEnvironmentBackground ? 'bg-violet-500' : 'bg-white/20'
                    }`}
                  >
                    <div
                      className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${
                        environment.showEnvironmentBackground ? 'left-7' : 'left-1'
                      }`}
                    />
                  </button>
                </div>
              </div>
            )}

            {Object.entries(presetConfig).map(([key, config]) => (
              <button
                key={key}
                onClick={() => handlePresetSelect(key as EnvironmentPreset)}
                className={`w-full p-3 rounded-lg border transition-all text-left ${
                  environment.preset === key
                    ? 'bg-violet-500/10 border-violet-500/30'
                    : 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center text-2xl bg-white/5">
                    {config.icon}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-white">{config.name}</span>
                      {environment.preset === key && <Check className="w-4 h-4 text-violet-400" />}
                    </div>
                    <p className="text-xs text-white/50 mt-0.5">{config.description}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}

        {/* Custom Tab */}
        {activeTab === 'custom' && (
          <div className="space-y-4">
            <div>
              <label className="text-xs font-medium text-white/80 mb-2 block">
                Upload Custom HDRI
              </label>
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-white/20 rounded-lg p-6 text-center hover:border-violet-500/50 transition-colors cursor-pointer"
              >
                <Upload className="w-8 h-8 mx-auto mb-2 text-white/50" />
                <p className="text-sm text-white/70 mb-1">
                  {environment.hdriUrl ? 'Replace HDRI' : 'Click to upload HDRI file'}
                </p>
                <p className="text-xs text-white/40">
                  Supports .hdr, .exr, .jpg, .png files
                </p>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept=".hdr,.exr,.jpg,.jpeg,.png"
                onChange={handleHDRIUpload}
                className="hidden"
              />
            </div>

            {/* Current HDRI Preview */}
            {environment.hdriUrl && (
              <div className="relative">
                <div className="p-3 rounded-lg bg-white/5 border border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-white/70">Custom HDRI</span>
                    <button
                      onClick={handleClearHDRI}
                      className="p-1 rounded hover:bg-red-500/20 text-red-400 transition-colors"
                      title="Remove HDRI"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="aspect-video rounded bg-gradient-to-br from-violet-500/20 to-indigo-500/20 flex items-center justify-center">
                    <Sun className="w-8 h-8 text-violet-400/50" />
                  </div>
                </div>
              </div>
            )}

            {uploading && (
              <div className="text-center py-4">
                <div className="inline-flex items-center gap-2 text-sm text-violet-400">
                  <div className="w-4 h-4 border-2 border-violet-400 border-t-transparent rounded-full animate-spin" />
                  Uploading...
                </div>
              </div>
            )}
          </div>
        )}

        {/* Settings Tab */}
        {activeTab === 'setting' && (
          <div className="space-y-6">
            {/* Background Color */}
            <div className="space-y-2">
              <label className="text-xs font-medium text-white/80">Background Color</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={environment.backgroundColor}
                  onChange={(e) => updateEnvironment({ backgroundColor: e.target.value })}
                  className="w-10 h-10 rounded-lg border border-white/20 cursor-pointer bg-transparent"
                />
                <input
                  type="text"
                  value={environment.backgroundColor}
                  onChange={(e) => updateEnvironment({ backgroundColor: e.target.value })}
                  className="flex-1 h-10 px-3 rounded-lg bg-white/5 border border-white/10 text-white text-sm"
                  placeholder="#000000"
                />
              </div>
            </div>

            {/* Environment Intensity */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-white/80">Environment Intensity</label>
                <span className="text-xs text-violet-400">{environment.environmentIntensity.toFixed(1)}</span>
              </div>
              <Slider
                value={[environment.environmentIntensity]}
                onValueChange={(value) => updateEnvironment({ environmentIntensity: value[0] })}
                min={0}
                max={3}
                step={0.1}
              />
            </div>

            {/* Environment Rotation */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-white/80">Environment Rotation</label>
                <span className="text-xs text-violet-400">{environment.environmentRotation}°</span>
              </div>
              <Slider
                value={[environment.environmentRotation]}
                onValueChange={(value) => updateEnvironment({ environmentRotation: value[0] })}
                min={0}
                max={360}
                step={1}
              />
            </div>

            {/* Background Blur */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-white/80">Background Blur</label>
                <span className="text-xs text-violet-400">{environment.backgroundBlur}</span>
              </div>
              <Slider
                value={[environment.backgroundBlur]}
                onValueChange={(value) => updateEnvironment({ backgroundBlur: value[0] })}
                min={0}
                max={1}
                step={0.01}
              />
            </div>

            {/* Current Preset Info */}
            {environment.preset !== 'none' && (
              <div className="p-3 rounded-lg bg-violet-500/10 border border-violet-500/30">
                <div className="flex items-center gap-2 text-xs">
                  <Sun className="w-4 h-4 text-violet-400" />
                  <span className="text-white/70">Using preset:</span>
                  <span className="text-violet-400 font-medium">{presetConfig[environment.preset].name}</span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
