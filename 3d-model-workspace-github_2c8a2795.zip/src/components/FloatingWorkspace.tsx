'use client';

import { useState, useEffect } from 'react';
import { X, Layers, Sparkles, Wand2, ChevronDown, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useCanvasStore, Layer } from '@/store/canvasStore';
import DrawingToolbar from '@/components/DrawingToolbar';
import MultiLayerCanvas from '@/components/MultiLayerCanvas';
import GeneratePanel from '@/components/GeneratePanel';

interface FloatingWorkspaceProps {
  projectId?: string;
}

export default function FloatingWorkspace({ projectId }: FloatingWorkspaceProps) {
  const { isOpen, closeWorkspace, canvasData, setActiveLayer, toggleLayerVisibility, toggleLayerLock } = useCanvasStore();
  const { activeLayerId, layers } = canvasData;
  const [showSaveConfirm, setShowSaveConfirm] = useState(false);
  const [leftPanelExpanded, setLeftPanelExpanded] = useState(true);
  const [rightPanelExpanded, setRightPanelExpanded] = useState(true);

  // Import from store
  const {
    undo,
    redo,
    zoom,
    zoomIn,
    zoomOut,
    resetZoom,
    setZoom,
    addLayer,
    deleteLayer,
    updateLayerBackgroundImage,
    saveHistory,
    moveLayer,
  } = useCanvasStore();

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl+Z / Cmd+Z - Undo
      if ((e.metaKey || e.ctrlKey) && e.key === 'z' && !e.shiftKey) {
        e.preventDefault();
        undo();
      }
      // Ctrl+Y / Cmd+Shift+Z - Redo
      if (((e.metaKey || e.ctrlKey) && e.key === 'y') || ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key === 'z')) {
        e.preventDefault();
        redo();
      }
      // Escape - Close workspace
      if (e.key === 'Escape') {
        handleClose();
      }
    };

    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }
  }, [isOpen, undo, redo]);

  // Handle close with save confirmation
  const handleClose = () => {
    // Check if there are any strokes in any layer
    const hasContent = canvasData.layers.some((layer) => layer.strokes.length > 0);

    if (hasContent) {
      setShowSaveConfirm(true);
    } else {
      closeWorkspace();
    }
  };

  // Handle save and close
  const handleSaveAndClose = () => {
    // TODO: Implement save logic
    console.log('Saving canvas data...');
    closeWorkspace();
    setShowSaveConfirm(false);
  };

  // Handle close without saving
  const handleCloseWithoutSaving = () => {
    closeWorkspace();
    setShowSaveConfirm(false);
  };

  // Handle close confirmation
  const handleCancelClose = () => {
    setShowSaveConfirm(false);
  };

  // Toggle left panel
  const toggleLeftPanel = () => {
    setLeftPanelExpanded(!leftPanelExpanded);
  };

  // Toggle right panel
  const toggleRightPanel = () => {
    setRightPanelExpanded(!rightPanelExpanded);
  };

  // Handle wheel zoom
  const handleWheelZoom = (e: React.WheelEvent<HTMLDivElement>) => {
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      const delta = e.deltaY > 0 ? -0.1 : 0.1;
      setZoom(zoom + delta);
    }
  };

  // Handle add new layer
  const handleAddLayer = () => {
    const layerCount = canvasData.layers.filter((l) => l.type === 'paint').length;
    addLayer(`Layer ${layerCount + 1}`, 'paint');
    saveHistory();
  };

  // Handle delete layer
  const handleDeleteLayer = (layerId: string) => {
    // Don't delete background layer
    const layer = canvasData.layers.find((l) => l.id === layerId);
    if (layer?.type === 'background') {
      console.warn('Cannot delete background layer');
      return;
    }
    deleteLayer(layerId);
    saveHistory();
  };

  // Handle background image upload
  const handleBackgroundUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';

    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        const imageData = event.target?.result as string;
        const backgroundLayer = canvasData.layers.find((l) => l.type === 'background');
        if (backgroundLayer) {
          updateLayerBackgroundImage(backgroundLayer.id, imageData);
          saveHistory();
        }
      };
      reader.readAsDataURL(file);
    };

    input.click();
  };

  // Handle drag start
  const handleDragStart = (e: React.DragEvent, layerId: string) => {
    e.dataTransfer.setData('text/plain', layerId);
    e.dataTransfer.effectAllowed = 'move';
  };

  // Handle drag over
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  // Handle drop
  const handleDrop = (e: React.DragEvent, targetLayerId: string) => {
    e.preventDefault();
    const sourceLayerId = e.dataTransfer.getData('text/plain');

    if (sourceLayerId === targetLayerId) return;

    const sourceLayer = canvasData.layers.find((l) => l.id === sourceLayerId);
    const targetLayer = canvasData.layers.find((l) => l.id === targetLayerId);

    if (!sourceLayer || !targetLayer) return;
    if (sourceLayer.type === 'background' || targetLayer.type === 'background') return;

    // Determine direction
    const sortedLayers = [...canvasData.layers].sort((a, b) => b.zIndex - a.zIndex);
    const sourceIndex = sortedLayers.findIndex((l) => l.id === sourceLayerId);
    const targetIndex = sortedLayers.findIndex((l) => l.id === targetLayerId);

    if (targetIndex < sourceIndex) {
      moveLayer(sourceLayerId, 'up');
    } else if (targetIndex > sourceIndex) {
      moveLayer(sourceLayerId, 'down');
    }

    saveHistory();
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop with semi-transparent overlay */}
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40" onClick={handleClose} />

      {/* Main Workspace Container */}
      <div className="fixed inset-0 z-50 bg-gray-950 flex flex-col">
        {/* Header */}
        <div className="h-12 border-b border-gray-800/50 flex items-center justify-between px-4 bg-gray-950/95">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-violet-400" />
            <h2 className="text-base font-medium text-white tracking-tight">Generating AI Model</h2>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
              className="h-8 w-8 hover:bg-gray-800/50 text-gray-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Drawing Toolbar */}
        <DrawingToolbar />

        {/* Main Content Area - Three Column Layout */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Panel - Layers */}
          <div
            className={`flex flex-col border-r border-gray-800/30 bg-gray-900/30 transition-all duration-200 ${
              leftPanelExpanded ? 'w-56' : 'w-10'
            }`}
          >
            {/* Panel Header */}
            <div
              className="h-10 flex items-center justify-between px-2 border-b border-gray-800/30 cursor-pointer hover:bg-gray-800/20"
              onClick={toggleLeftPanel}
            >
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-violet-400" />
                {leftPanelExpanded && <span className="text-xs font-medium text-gray-400">Layers</span>}
              </div>
              {leftPanelExpanded ? (
                <ChevronDown className="w-3 h-3 text-gray-600" />
              ) : (
                <ChevronRight className="w-3 h-3 text-gray-600" />
              )}
            </div>

            {/* Panel Content */}
            {leftPanelExpanded && (
              <div className="flex-1 flex flex-col overflow-hidden">
                {/* Layer Actions */}
                <div className="p-2 border-b border-gray-800/30 flex gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleAddLayer}
                    className="flex-1 h-8 text-xs border-gray-700/50 text-gray-300 hover:text-white hover:border-violet-500/30"
                  >
                    + Add Layer
                  </Button>
                </div>

                {/* Layer List */}
                <div className="flex-1 overflow-y-auto p-2 space-y-1">
                  {canvasData.layers
                    .sort((a, b) => b.zIndex - a.zIndex) // Sort from top to bottom
                    .map((layer) => (
                      <LayerCard
                        key={layer.id}
                        layer={layer}
                        isActive={layer.id === activeLayerId}
                        onClick={() => setActiveLayer(layer.id)}
                        onToggleVisibility={() => toggleLayerVisibility(layer.id)}
                        onToggleLock={() => toggleLayerLock(layer.id)}
                        onDelete={() => handleDeleteLayer(layer.id)}
                        onUploadBackground={layer.type === 'background' ? handleBackgroundUpload : undefined}
                        onDragStart={(e) => handleDragStart(e, layer.id)}
                        onDragOver={handleDragOver}
                        onDrop={(e) => handleDrop(e, layer.id)}
                      />
                    ))}
                </div>
              </div>
            )}
          </div>

          {/* Center Panel - Canvas Area */}
          <div
            className="flex-1 bg-gray-950/50 relative overflow-hidden"
            onWheel={handleWheelZoom}
          >
            {/* Canvas Container */}
            <div className="absolute inset-0 flex items-center justify-center p-8 overflow-hidden">
              <div
                className="relative transition-transform duration-200 ease-out"
                style={{
                  transform: `scale(${zoom})`,
                }}
              >
                <Card
                  className="bg-white border-0 shadow-2xl overflow-hidden relative rounded-sm"
                  style={{
                    width: `${canvasData.width}px`,
                    height: `${canvasData.height}px`,
                  }}
                >
                  {/* Multi-Layer Canvas */}
                  <MultiLayerCanvas />
                </Card>
              </div>
            </div>

            {/* Zoom Controls */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-1 bg-gray-900/90 backdrop-blur-sm rounded-lg p-1 border border-gray-800/30">
              <Button
                variant="ghost"
                size="icon"
                onClick={zoomOut}
                className="h-8 w-8 text-gray-400 hover:text-white hover:bg-gray-800/50"
                title="Zoom Out (-)"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="11" cy="11" r="8" />
                  <path d="m21 21-4.3-4.3" />
                  <path d="m8 11h6" />
                </svg>
              </Button>
              <span className="text-xs text-gray-400 font-medium min-w-[50px] text-center">{Math.round(zoom * 100)}%</span>
              <Button
                variant="ghost"
                size="icon"
                onClick={zoomIn}
                className="h-8 w-8 text-gray-400 hover:text-white hover:bg-gray-800/50"
                title="Zoom In (+)"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="11" cy="11" r="8" />
                  <path d="m21 21-4.3-4.3" />
                  <path d="m8 11h6" />
                  <path d="m11 8v6" />
                </svg>
              </Button>
              <div className="w-px h-5 bg-gray-700/50 mx-1" />
              <Button
                variant="ghost"
                size="icon"
                onClick={resetZoom}
                className="h-8 w-8 text-gray-400 hover:text-white hover:bg-gray-800/50"
                title="Reset Zoom (0)"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 12" />
                  <path d="M3 3v9h9" />
                </svg>
              </Button>
            </div>

            {/* Canvas Info */}
            <div className="absolute top-3 left-3 px-2 py-1 bg-gray-900/90 backdrop-blur-sm rounded text-xs text-gray-400 border border-gray-800/30">
              {canvasData.width} × {canvasData.height}
            </div>
          </div>

          {/* Right Panel - AI Tools */}
          <div
            className={`flex flex-col border-l border-gray-800/30 bg-gray-900/30 transition-all duration-200 ${
              rightPanelExpanded ? 'w-56' : 'w-10'
            }`}
          >
            {/* Panel Header */}
            <div
              className="h-10 flex items-center justify-between px-2 border-b border-gray-800/30 cursor-pointer hover:bg-gray-800/20"
              onClick={toggleRightPanel}
            >
              <div className="flex items-center gap-2">
                <Wand2 className="w-4 h-4 text-violet-400" />
                {rightPanelExpanded && <span className="text-xs font-medium text-gray-400">AI Tools</span>}
              </div>
              {rightPanelExpanded ? (
                <ChevronDown className="w-3 h-3 text-gray-600" />
              ) : (
                <ChevronRight className="w-3 h-3 text-gray-600" />
              )}
            </div>

            {/* Panel Content */}
            {rightPanelExpanded && (
              <GeneratePanel projectId={projectId} />
            )}
          </div>
        </div>
      </div>

      {/* Save Confirmation Dialog */}
      {showSaveConfirm && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
          <Card className="relative z-10 w-96 p-6 bg-gray-900 border-gray-800/50 shadow-2xl">
            <h3 className="text-base font-semibold text-white mb-2">Save Progress?</h3>
            <p className="text-sm text-gray-400 mb-6 leading-relaxed">
              You have unsaved changes in your canvas. Do you want to save before closing?
            </p>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={handleCancelClose}
                className="flex-1 border-gray-700/50 text-gray-300 hover:text-white h-9"
              >
                Cancel
              </Button>
              <Button
                variant="ghost"
                onClick={handleCloseWithoutSaving}
                className="flex-1 hover:bg-gray-800/50 text-gray-400 h-9"
              >
                Don't Save
              </Button>
              <Button
                onClick={handleSaveAndClose}
                className="flex-1 bg-gradient-to-r from-violet-600 to-indigo-600 hover:shadow-lg hover:shadow-violet-500/25 h-9"
              >
                Save & Close
              </Button>
            </div>
          </Card>
        </div>
      )}
    </>
  );
}

// Layer Card Component
function LayerCard({
  layer,
  isActive,
  onClick,
  onToggleVisibility,
  onToggleLock,
  onDelete,
  onUploadBackground,
  onDragStart,
  onDragOver,
  onDrop,
}: {
  layer: Layer;
  isActive: boolean;
  onClick: () => void;
  onToggleVisibility: () => void;
  onToggleLock: () => void;
  onDelete?: () => void;
  onUploadBackground?: () => void;
  onDragStart?: (e: React.DragEvent) => void;
  onDragOver?: (e: React.DragEvent) => void;
  onDrop?: (e: React.DragEvent) => void;
}) {
  return (
    <div
      onClick={onClick}
      className={`p-2 rounded-md cursor-pointer border transition-all ${
        isActive
          ? 'bg-gradient-to-r from-violet-600/15 to-indigo-600/15 border-violet-500/30'
          : 'bg-gray-800/30 border-gray-800/30 hover:border-gray-700/50'
      }`}
    >
      <div
        className="flex items-center gap-2"
        draggable={layer.type === 'paint' || layer.type === 'image' || layer.type === '3d'}
        onDragStart={onDragStart}
        onDragOver={onDragOver}
        onDrop={onDrop}
      >
        {/* Drag Handle (for paint, image, and 3D layers) */}
        {(layer.type === 'paint' || layer.type === 'image' || layer.type === '3d') && (
          <div className="cursor-grab active:cursor-grabbing p-1 hover:bg-gray-700/30 rounded">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-gray-600"
            >
              <circle cx="9" cy="12" r="1" />
              <circle cx="9" cy="5" r="1" />
              <circle cx="9" cy="19" r="1" />
              <circle cx="15" cy="12" r="1" />
              <circle cx="15" cy="5" r="1" />
              <circle cx="15" cy="19" r="1" />
            </svg>
          </div>
        )}

        {/* Visibility Toggle */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleVisibility();
          }}
          className="p-1 hover:bg-gray-700/30 rounded transition-colors"
        >
          {layer.visible ? (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-gray-400"
            >
              <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
              <circle cx="12" cy="12" r="3" />
            </svg>
          ) : (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-gray-600"
            >
              <path d="M9.88 9.88a3 3 0 1 0 4.24 4.24" />
              <path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68" />
              <path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61" />
              <line x1="2" x2="22" y1="2" y2="22" />
            </svg>
          )}
        </button>

        {/* Lock Toggle */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleLock();
          }}
          className="p-1 hover:bg-gray-700/30 rounded transition-colors"
        >
          {layer.locked ? (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-gray-400"
            >
              <rect width="18" height="11" x="3" y="11" rx="2" ry="2" />
              <path d="M7 11V7a5 5 0 0 1 10 0v4" />
            </svg>
          ) : (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-gray-600"
            >
              <rect width="18" height="11" x="3" y="11" rx="2" ry="2" />
              <path d="M7 11V7a5 5 0 0 1 9.9-1" />
            </svg>
          )}
        </button>

        {/* Layer Type Icon */}
        {layer.type === '3d' && (
          <div className="w-4 h-4 flex items-center justify-center text-violet-400">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="m21.64 3.64-1.28-1.28a1.21 1.21 0 0 0-1.72 0L2.36 18.64a1.21 1.21 0 0 0 0 1.72l1.28 1.28a1.2 1.2 0 0 0 1.72 0L21.64 5.36a1.2 1.2 0 0 0 0-1.72Z" />
              <path d="m14 7 3 3" />
              <path d="M5 6v4" />
              <path d="M19 14v4" />
              <path d="M10 2v2" />
              <path d="M7 8H3" />
              <path d="M21 16h-4" />
              <path d="M11 3H9" />
            </svg>
          </div>
        )}

        {/* Layer Name */}
        <span className={`text-xs font-medium flex-1 truncate ${isActive ? 'text-white' : 'text-gray-400'}`}>
          {layer.name}
        </span>

        {/* Stroke Count */}
        {layer.strokes.length > 0 && (
          <span className="text-[10px] text-gray-500 bg-gray-800/50 px-1.5 py-0.5 rounded-full">{layer.strokes.length}</span>
        )}

        {/* Background Upload Button (only for background layer) */}
        {layer.type === 'background' && onUploadBackground && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onUploadBackground();
            }}
            className="p-1 hover:bg-gray-700/30 rounded transition-colors"
            title="Upload Background Image"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-gray-400"
            >
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="17 8 12 3 7 8" />
              <line x1="12" x2="12" y1="3" y2="15" />
            </svg>
          </button>
        )}

        {/* Delete Button (for paint, image, and 3D layers) */}
        {(layer.type === 'paint' || layer.type === 'image' || layer.type === '3d') && onDelete && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDelete();
            }}
            className="p-1 hover:bg-red-500/20 rounded transition-colors"
            title="Delete Layer"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-gray-400 hover:text-red-400"
            >
              <path d="M3 6h18" />
              <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
              <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
            </svg>
          </button>
        )}
      </div>
    </div>
  );
}
