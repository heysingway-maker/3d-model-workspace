'use client';

import { useState, useEffect } from 'react';
import { Wand2, Image as ImageIcon, Box, Sparkles, ChevronDown, ChevronRight, X, Download, ArrowLeft, Layers, ArrowRight, Check, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useCanvasStore } from '@/store/canvasStore';
import { Make3DPreview } from '@/components/Make3DPreview';

// 压缩图片函数 - 将大图片压缩到合适大小
async function compressImage(base64Image: string, maxWidth = 512, quality = 0.8): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      // 计算缩放比例
      let width = img.width;
      let height = img.height;
      
      if (width > maxWidth || height > maxWidth) {
        if (width > height) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        } else {
          width = Math.round((width * maxWidth) / height);
          height = maxWidth;
        }
      }
      
      console.log(`Compressing image from ${img.width}x${img.height} to ${width}x${height}`);
      
      // 创建 canvas 压缩
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        reject(new Error('Failed to get canvas context'));
        return;
      }
      
      ctx.drawImage(img, 0, 0, width, height);
      
      // 转换为 JPEG 格式（比 PNG 小很多）
      const compressedBase64 = canvas.toDataURL('image/jpeg', quality);
      console.log(`Image compressed: ${base64Image.length} -> ${compressedBase64.length} chars`);
      
      resolve(compressedBase64);
    };
    
    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = base64Image;
  });
}

// 流程步骤
type FlowStep = 'sketch' | 'render' | 'make3d';

interface GeneratePanelProps {
  projectId?: string;
}

export default function GeneratePanel({ projectId }: GeneratePanelProps) {
  const {
    aiMode,
    aiPrompt,
    drawingInfluence,
    isGenerating,
    generatedImage,
    generatedModelUrl,
    canvasData,
    setAIMode,
    setAIPrompt,
    setDrawingInfluence,
    setGenerating,
    setGeneratedImage,
    setGeneratedModelUrl,
    resetAIGeneration,
    exportToImage,
    exportActiveLayerToImage,
    importToStudio,
    addLayerFromImage,
    addLayerFrom3DModel,
  } = useCanvasStore();

  const [showPreview, setShowPreview] = useState(false);
  const [show3DPreview, setShow3DPreview] = useState(false);
  const [progress, setProgress] = useState(0);
  const [useActiveLayer, setUseActiveLayer] = useState(true);
  
  // 新流程状态
  const [currentStep, setCurrentStep] = useState<FlowStep>('sketch');
  const [renderedImage, setRenderedImage] = useState<string | null>(null); // 存储 Render 后的图片
  const [isRenderedImageUsed, setIsRenderedImageUsed] = useState(false);

  // Get active layer info
  const activeLayer = canvasData.layers.find((l) => l.id === canvasData.activeLayerId);

  // 当用户切换到 Make 3D 模式时，检查是否有 Render 后的图片
  useEffect(() => {
    if (aiMode === 'make3d' && renderedImage) {
      setIsRenderedImageUsed(true);
    }
  }, [aiMode, renderedImage]);

  // Handle Generate Render
  const handleGenerateRender = async () => {
    if (!aiPrompt.trim()) {
      alert('Please enter a prompt to describe what you want to create');
      return;
    }

    setGenerating(true);
    setProgress(10);

    // Export canvas as image
    const canvasImage = exportToImage('png');
    if (!canvasImage) {
      alert('Failed to export canvas');
      setGenerating(false);
      return;
    }

    try {
      setProgress(20);
      
      // 调用 Render API（设置超时 60 秒）
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 60000);
      
      const response = await fetch('/api/render', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: aiPrompt,
          image: canvasImage, // base64 格式的画板图像
          size: '2K',
        }),
        signal: controller.signal,
      });
      
      clearTimeout(timeoutId);
      setProgress(60);

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || data.details || 'Failed to generate render');
      }

      setProgress(80);

      // 获取生成的图像并转换为 base64
      const imageResponse = await fetch(data.imageUrl);
      if (!imageResponse.ok) {
        throw new Error('Failed to download generated image');
      }
      
      const imageBlob = await imageResponse.blob();
      const reader = new FileReader();

      reader.onloadend = () => {
        const base64data = reader.result as string;
        // 设置生成的图像
        setGeneratedImage(data.imageUrl);
        setRenderedImage(base64data); // 存储 Render 后的图片，用于 Make 3D
        setCurrentStep('render'); // 更新流程步骤
        // 将生成的图像作为新图层添加到画板
        addLayerFromImage(`AI Render ${Date.now()}`, base64data);
      };

      reader.onerror = () => {
        throw new Error('Failed to read generated image');
      };

      reader.readAsDataURL(imageBlob);

      // 更新生成进度
      setProgress(100);
      setGenerating(false);

      console.log('Render generated successfully:', data.imageUrl);

    } catch (error) {
      console.error('Generate render error:', error);
      const errorMessage = error instanceof Error 
        ? (error.name === 'AbortError' ? 'Request timed out (60s)' : error.message)
        : 'Failed to generate render';
      alert(errorMessage);
      setGenerating(false);
      setProgress(0);
    }
  };

  // Handle Make 3D - 优先使用 Render 后的图片
  const handleMake3D = async () => {
    setGenerating(true);
    setProgress(5);

    // 确定使用哪个图片
    let imageToUse: string | null = null;
    
    if (renderedImage) {
      // 优先使用 Render 后的图片
      console.log('Using rendered image for 3D generation');
      imageToUse = renderedImage;
    } else if (useActiveLayer && activeLayer) {
      // 使用当前选中图层
      console.log('Exporting active layer:', activeLayer.name);
      imageToUse = exportActiveLayerToImage('png');
    } else {
      // 使用整个画布
      console.log('Exporting full canvas');
      imageToUse = exportToImage('png');
    }
    
    if (!imageToUse) {
      alert('Please draw something on the canvas or render an image first');
      setGenerating(false);
      return;
    }

    // 如果没有 Render 过的图片，提示用户
    if (!renderedImage) {
      const proceed = confirm(
        '💡 Tip: For better 3D results, we recommend rendering your sketch first.\n\n' +
        'The Render step will generate a detailed image from your sketch, ' +
        'which produces much better 3D models.\n\n' +
        'Click "Cancel" to go back and render first, or "OK" to proceed with the current image.'
      );
      if (!proceed) {
        setGenerating(false);
        setAIMode('render'); // 切换到 Render 模式
        return;
      }
    }

    console.log('Image exported successfully, original size:', imageToUse.length);
    setProgress(10);

    try {
      // 压缩图片以避免栈溢出错误
      console.log('Compressing image...');
      const compressedImage = await compressImage(imageToUse, 512, 0.8);
      console.log('Image compressed, new size:', compressedImage.length);
      setProgress(20);

      // Step 1: Call make3d API to start conversion
      console.log('Starting image-to-3D conversion...');
      const response = await fetch('/api/make3d', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          image: compressedImage,
          prompt: aiPrompt || 'A high-quality cosmetic product',
          style: 'realistic',
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to start 3D conversion');
      }

      const taskId = data.taskId;
      const provider = data.provider || 'meshy';
      console.log('Task started:', taskId, 'provider:', provider);

      // Step 2: Poll task status
      let attempts = 0;
      const maxAttempts = 150;

      let consecutiveErrors = 0;
      const maxConsecutiveErrors = 5;

      const pollInterval = setInterval(async () => {
        attempts++;

        try {
          console.log(`Polling task status (attempt ${attempts})...`);

          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 300000);

          const statusResponse = await fetch(`/api/make3d/${taskId}?provider=${provider}`, {
            signal: controller.signal,
          });
          clearTimeout(timeoutId);

          const statusData = await statusResponse.json();

          if (!statusResponse.ok) {
            clearInterval(pollInterval);
            throw new Error(statusData.error || 'Failed to check task status');
          }

          consecutiveErrors = 0;

          console.log('Task status:', statusData.status, 'Progress:', statusData.progress);

          if (statusData.progress) {
            setProgress(Math.min(statusData.progress, 95));
          }

          if (statusData.status === 'succeeded' && statusData.modelUrl) {
            clearInterval(pollInterval);
            setProgress(100);
            setGenerating(false);
            setGeneratedModelUrl(statusData.modelUrl);
            setCurrentStep('make3d'); // 更新流程步骤
            console.log('✅ 3D model ready!');
          } else if (statusData.status === 'storing') {
            setProgress(95);
            console.log('Storing model...');
          } else if (statusData.status === 'failed') {
            clearInterval(pollInterval);
            setGenerating(false);
            alert('3D model generation failed: ' + (statusData.message || 'Unknown error'));
          } else if (attempts >= maxAttempts) {
            clearInterval(pollInterval);
            setGenerating(false);
            alert('3D model generation timed out. Please try again.');
          }

        } catch (error) {
          consecutiveErrors++;
          console.error(`Error polling task status (${consecutiveErrors}/${maxConsecutiveErrors}):`, error);
          
          if (consecutiveErrors >= maxConsecutiveErrors) {
            clearInterval(pollInterval);
            setGenerating(false);
            const errorMessage = error instanceof Error 
              ? (error.name === 'AbortError' ? 'Request timed out' : error.message)
              : 'Error checking task status';
            alert(`${errorMessage}. Please check your network and try again.`);
          }
        }
      }, 5000);

    } catch (error) {
      console.error('Error starting 3D conversion:', error);
      setGenerating(false);
      setProgress(0);
      
      const errorMessage = error instanceof Error ? error.message : 'Failed to start 3D conversion';
      
      if (errorMessage.includes('API key') || errorMessage.includes('API Key') || errorMessage.includes('Authentication') || errorMessage.includes('Invalid') || errorMessage.includes('未配置')) {
        alert(`3D generation service unavailable.\n\nTo enable Make 3D:\n1. Visit https://meshy.ai to get a Meshy API key\n2. Add the key to your .env.local file:\n   MESHY_API_KEY=msy-xxx`);
      } else {
        alert(errorMessage);
      }
    }
  };

  // Handle Reset
  const handleReset = () => {
    resetAIGeneration();
    setProgress(0);
    setRenderedImage(null);
    setCurrentStep('sketch');
    setIsRenderedImageUsed(false);
  };

  // Handle Download Image
  const handleDownloadImage = () => {
    if (!generatedImage) return;

    const link = document.createElement('a');
    link.download = `ai-render-${Date.now()}.png`;
    link.href = generatedImage;
    link.click();
  };

  // Handle Import to Studio
  const handleImportToStudio = () => {
    if (!generatedModelUrl) {
      alert('No 3D model available to import');
      return;
    }
    
    const layerName = `3D Model ${new Date().toLocaleTimeString()}`;
    addLayerFrom3DModel(layerName, generatedModelUrl);
    
    console.log('3D model added as new layer:', layerName);
    
    setShow3DPreview(false);
    setGeneratedModelUrl(null);
  };

  // 从 Render 结果继续到 Make 3D
  const handleContinueTo3D = () => {
    setAIMode('make3d');
  };

  return (
    <Card className="flex flex-col h-full bg-gray-900/50 border-gray-800/30 rounded-lg overflow-hidden [&::-webkit-scrollbar]:w-[6px] [&::-webkit-scrollbar-track]:bg-transparent [&::-webkit-scrollbar-thumb]:bg-gray-700/50 [&::-webkit-scrollbar-thumb:hover]:bg-gray-600 [&::-webkit-scrollbar-thumb]:rounded-full">
      {/* 流程进度指示器 */}
      <div className="p-3 border-b border-gray-800/30 bg-gray-900/30">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-gray-400">Workflow</span>
          {renderedImage && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleReset}
              className="h-6 text-xs text-gray-500 hover:text-red-400"
            >
              Reset
            </Button>
          )}
        </div>
        <div className="flex items-center gap-1">
          {/* Step 1: Sketch */}
          <div className={`flex-1 h-1.5 rounded-full ${
            currentStep === 'sketch' ? 'bg-violet-500' : 
            currentStep === 'render' || currentStep === 'make3d' ? 'bg-green-500' : 'bg-gray-700'
          }`} />
          
          {/* Step 2: Render */}
          <div className={`flex-1 h-1.5 rounded-full transition-all ${
            currentStep === 'render' ? 'bg-violet-500' : 
            currentStep === 'make3d' ? 'bg-green-500' : 'bg-gray-700'
          }`} />
          
          {/* Step 3: Make 3D */}
          <div className={`flex-1 h-1.5 rounded-full transition-all ${
            currentStep === 'make3d' ? 'bg-green-500' : 'bg-gray-700'
          }`} />
        </div>
        <div className="flex justify-between mt-1 text-[10px] text-gray-500">
          <span className={currentStep === 'sketch' ? 'text-violet-400' : ''}>Sketch</span>
          <span className={currentStep === 'render' ? 'text-violet-400' : ''}>Render</span>
          <span className={currentStep === 'make3d' ? 'text-violet-400' : ''}>3D</span>
        </div>
      </div>

      {/* Mode Selector */}
      <div className="p-2 border-b border-gray-800/30">
        <div className="flex gap-1">
          <Button
            variant={aiMode === 'render' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setAIMode('render')}
            className={`flex-1 flex items-center gap-1.5 h-8 text-xs ${
              aiMode === 'render'
                ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-500/20'
                : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            Render
          </Button>
          <Button
            variant={aiMode === 'make3d' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setAIMode('make3d')}
            className={`flex-1 flex items-center gap-1.5 h-8 text-xs ${
              aiMode === 'make3d'
                ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-500/20'
                : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
            }`}
          >
            <Box className="w-3.5 h-3.5" />
            Make 3D
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3 [&::-webkit-scrollbar]:w-[6px] [&::-webkit-scrollbar-track]:bg-transparent [&::-webkit-scrollbar-thumb]:bg-gray-700/50 [&::-webkit-scrollbar-thumb:hover]:bg-gray-600 [&::-webkit-scrollbar-thumb]:rounded-full">
        {/* Render Mode */}
        {aiMode === 'render' && (
          <>
            {/* 提示信息 */}
            {renderedImage && (
              <div className="p-2 rounded-lg bg-green-500/10 border border-green-500/30 flex items-center gap-2">
                <Check className="w-4 h-4 text-green-400" />
                <span className="text-xs text-green-400">Image rendered! Continue to Make 3D for best results.</span>
              </div>
            )}

            {/* Prompt Input */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-violet-400 uppercase tracking-wider">Prompt</label>
              <textarea
                value={aiPrompt}
                onChange={(e) => setAIPrompt(e.target.value)}
                placeholder="Describe what you want to create (e.g., a sleek lipstick tube with gold accents)"
                className="w-full h-20 px-3 py-2 bg-gray-800/50 border border-gray-700/30 rounded-lg text-sm text-gray-300 placeholder-gray-600 focus:outline-none focus:border-violet-500/30 resize-none"
              />
            </div>

            {/* Drawing Influence */}
            <div className="space-y-2">
              <div className="flex justify-between">
                <label className="text-xs font-semibold text-violet-400 uppercase tracking-wider">Drawing Influence</label>
                <span className="text-xs text-gray-400">{Math.round(drawingInfluence * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={drawingInfluence}
                onChange={(e) => setDrawingInfluence(Number(e.target.value))}
                className="w-full h-2 bg-gray-800/50 rounded-full appearance-none cursor-pointer accent-violet-500"
              />
              <div className="flex justify-between text-[10px] text-gray-500">
                <span>AI Creative</span>
                <span>Follow Drawing</span>
              </div>
            </div>

            {/* Generate Button */}
            <Button
              onClick={handleGenerateRender}
              disabled={isGenerating || !aiPrompt.trim()}
              className="w-full h-10 bg-gradient-to-r from-violet-600 to-indigo-600 hover:shadow-lg hover:shadow-violet-500/25 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Rendering...
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4" />
                  Generate Render
                </>
              )}
            </Button>

            {/* Loading State */}
            {isGenerating && (
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-gray-400">
                  <span>Generating...</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <div className="h-2 bg-gray-800/50 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-violet-600 to-indigo-600 rounded-full transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Generated Image Preview */}
            {generatedImage && !isGenerating && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-violet-400 uppercase tracking-wider">Result</label>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      setGeneratedImage(null);
                      setRenderedImage(null);
                    }}
                    className="h-6 w-6 text-gray-500 hover:text-red-400"
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
                <div className="relative group">
                  <img
                    src={generatedImage}
                    alt="Generated render"
                    className="w-full rounded-lg border border-gray-700/30 cursor-pointer hover:border-violet-500/30 transition-all"
                    onClick={() => setShowPreview(true)}
                  />
                  <div className="absolute top-2 right-2 flex gap-1">
                    <Button
                      onClick={handleDownloadImage}
                      className="h-7 w-7 bg-gray-900/80 backdrop-blur-sm hover:bg-gray-800"
                      size="icon"
                    >
                      <Download className="w-3.5 h-3.5 text-gray-300" />
                    </Button>
                  </div>
                </div>
                
                {/* Continue to Make 3D Button */}
                <Button
                  onClick={handleContinueTo3D}
                  className="w-full h-10 bg-gradient-to-r from-green-600 to-emerald-600 hover:shadow-lg hover:shadow-green-500/25 flex items-center gap-2"
                >
                  <ArrowRight className="w-4 h-4" />
                  Continue to Make 3D
                </Button>
              </div>
            )}
          </>
        )}

        {/* Make 3D Mode */}
        {aiMode === 'make3d' && (
          <>
            {/* Render 提示 */}
            {renderedImage ? (
              <div className="p-2 rounded-lg bg-green-500/10 border border-green-500/30">
                <div className="flex items-center gap-2 mb-1">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-xs font-medium text-green-400">Using rendered image</span>
                </div>
                <p className="text-[10px] text-gray-400">This will produce a higher quality 3D model.</p>
              </div>
            ) : (
              <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/30">
                <div className="flex items-center gap-2 mb-1">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-medium text-amber-400">Tip: Render first for better results</span>
                </div>
                <p className="text-[10px] text-gray-400 mb-2">Rendering your sketch first will produce a more detailed image, resulting in a higher quality 3D model.</p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setAIMode('render')}
                  className="h-7 text-xs border-amber-500/30 text-amber-400 hover:bg-amber-500/10"
                >
                  Go to Render
                </Button>
              </div>
            )}

            {/* Source Selection - 只在没有 Render 图片时显示 */}
            {!renderedImage && (
              <div className="space-y-2">
                <label className="text-xs font-semibold text-violet-400 uppercase tracking-wider">Source</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setUseActiveLayer(true)}
                    className={`p-2 rounded-lg border transition-all ${
                      useActiveLayer
                        ? 'border-violet-500/50 bg-violet-500/10'
                        : 'border-gray-700/30 hover:border-gray-600/50'
                    }`}
                  >
                    <div className="flex flex-col items-center gap-1">
                      <Layers className="w-4 h-4 text-gray-400" />
                      <div className="text-xs text-gray-400 text-center">
                        {activeLayer ? `Layer: ${activeLayer.name}` : 'Active Layer'}
                      </div>
                    </div>
                  </button>
                  <button
                    onClick={() => setUseActiveLayer(false)}
                    className={`p-2 rounded-lg border transition-all ${
                      !useActiveLayer
                        ? 'border-violet-500/50 bg-violet-500/10'
                        : 'border-gray-700/30 hover:border-gray-600/50'
                    }`}
                  >
                    <div className="flex flex-col items-center gap-1">
                      <ImageIcon className="w-4 h-4 text-gray-400" />
                      <div className="text-xs text-gray-400 text-center">Full Canvas</div>
                    </div>
                  </button>
                </div>
              </div>
            )}

            {/* Preview */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-violet-400 uppercase tracking-wider">Preview</label>
              <div className="aspect-square bg-gray-800/50 rounded-lg border border-gray-700/30 flex items-center justify-center overflow-hidden">
                {renderedImage ? (
                  <img src={renderedImage} alt="Rendered preview" className="w-full h-full object-contain" />
                ) : generatedImage ? (
                  <img src={generatedImage} alt="Preview" className="w-full h-full object-contain" />
                ) : (
                  <div className="flex flex-col items-center gap-2 text-gray-600">
                    <Sparkles className="w-12 h-12" />
                    <span className="text-xs">No image yet</span>
                  </div>
                )}
              </div>
            </div>

            {/* Make 3D Button */}
            <Button
              onClick={handleMake3D}
              disabled={isGenerating}
              className="w-full h-10 bg-gradient-to-r from-violet-600 to-indigo-600 hover:shadow-lg hover:shadow-violet-500/25 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Making 3D...
                </>
              ) : (
                <>
                  <Box className="w-4 h-4" />
                  Make 3D
                </>
              )}
            </Button>

            {/* Loading State */}
            {isGenerating && (
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-gray-400">
                  <span>
                    {progress < 90 ? 'Generating 3D Model...' : 
                     progress < 95 ? 'Processing...' : 
                     'Storing Model...'}
                  </span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <div className="h-2 bg-gray-800/50 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-violet-600 to-indigo-600 rounded-full transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <p className="text-[10px] text-gray-500 text-center">
                  {progress < 90 ? 'AI is creating your 3D model (30-60s)' :
                   progress < 95 ? 'Almost done...' :
                   'Saving model for preview...'}
                </p>
              </div>
            )}

            {/* Generated Model */}
            {generatedModelUrl && !isGenerating && (
              <div className="space-y-2 animate-in fade-in slide-in-from-bottom-4 duration-300">
                <label className="text-xs font-semibold text-green-400 uppercase tracking-wider">3D Model Generated</label>
                <div className="p-3 bg-gradient-to-r from-green-600/10 to-emerald-600/10 rounded-lg border border-green-500/30">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                    <span className="text-sm font-medium text-gray-300">Your model is ready!</span>
                  </div>
                  <p className="text-[10px] text-gray-500 mb-3">Click below to preview and import to Studio</p>
                  <Button
                    onClick={() => {
                      console.log('Opening 3D preview...');
                      setShow3DPreview(true);
                    }}
                    className="w-full h-auto min-h-10 bg-gradient-to-r from-violet-600 to-indigo-600 hover:shadow-lg hover:shadow-violet-500/25 transition-all duration-300 hover:scale-[1.02] py-2.5"
                  >
                    <Sparkles className="w-4 h-4 mr-2 flex-shrink-0" />
                    <span className="text-xs leading-tight">Preview & Import</span>
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Make 3D Preview Modal */}
      {show3DPreview && generatedModelUrl && (
        <Make3DPreview
          modelUrl={generatedModelUrl}
          onClose={() => setShow3DPreview(false)}
          onImport={() => {
            setShow3DPreview(false);
          }}
          isImporting={isGenerating}
          projectId={projectId}
        />
      )}

      {/* Image Preview Modal */}
      {showPreview && generatedImage && aiMode === 'render' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
          <div className="relative max-w-4xl max-h-[80vh] p-4">
            <Button
              onClick={() => setShowPreview(false)}
              variant="ghost"
              size="icon"
              className="absolute top-2 right-2 h-8 w-8 bg-black/50 text-white hover:bg-black/70"
            >
              <X className="w-4 h-4" />
            </Button>
            <img
              src={generatedImage}
              alt="Full preview"
              className="max-w-full max-h-[80vh] object-contain rounded-lg"
            />
          </div>
        </div>
      )}
    </Card>
  );
}
