'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Upload, Pencil, Eraser, RotateCcw, Download, X, Image as ImageIcon, Save,
  Square, Circle, Triangle, Minus, Type, Move, Sparkles, Loader2
} from 'lucide-react';

type ToolType = 'pen' | 'eraser' | 'rectangle' | 'circle' | 'triangle' | 'line' | 'text' | 'select' | 'ai';

// Available fonts
const AVAILABLE_FONTS = [
  { value: 'Arial', label: 'Arial' },
  { value: 'Helvetica', label: 'Helvetica' },
  { value: 'Times New Roman', label: 'Times New Roman' },
  { value: 'Georgia', label: 'Georgia' },
  { value: 'Verdana', label: 'Verdana' },
  { value: 'Courier New', label: 'Courier New' },
  { value: 'Impact', label: 'Impact' },
  { value: 'Comic Sans MS', label: 'Comic Sans MS' },
  { value: 'Trebuchet MS', label: 'Trebuchet MS' },
  { value: 'Palatino', label: 'Palatino' },
];

interface DrawableObject {
  id: string;
  type: 'rectangle' | 'circle' | 'triangle' | 'line' | 'text';
  x: number;
  y: number;
  width?: number;
  height?: number;
  radius?: number;
  endX?: number;
  endY?: number;
  color: string;
  lineWidth: number;
  // Text specific
  text?: string;
  fontSize?: number;
  fontFamily?: string;
}

interface HistoryState {
  imageData: ImageData;
  objects: DrawableObject[];
}

interface LabelEditorProps {
  onLabelCreated: (imageData: string) => void;
  onClose: () => void;
  initialImageData?: string; // For editing existing label
}

export function LabelEditor({ onLabelCreated, onClose, initialImageData }: LabelEditorProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [brushColor, setBrushColor] = useState('#ffffff');
  const [brushSize, setBrushSize] = useState(5);
  const [tool, setTool] = useState<ToolType>('pen');
  const [isDraggingFile, setIsDraggingFile] = useState(false);
  
  // History management with useRef for reliable state access
  const historyRef = useRef<HistoryState[]>([]);
  const historyIndexRef = useRef<number>(-1);
  const [, forceUpdate] = useState(0);
  
  // Shape drawing state
  const [startPoint, setStartPoint] = useState<{ x: number; y: number } | null>(null);
  const [tempImageData, setTempImageData] = useState<ImageData | null>(null);
  
  // All drawable objects (shapes + text) for selection and dragging
  const [objects, setObjects] = useState<DrawableObject[]>([]);
  const [selectedObjectId, setSelectedObjectId] = useState<string | null>(null);
  const [isDraggingObject, setIsDraggingObject] = useState(false);
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  
  // Text input state
  const [textInput, setTextInput] = useState('');
  const [textPosition, setTextPosition] = useState<{ x: number; y: number } | null>(null);
  const [showTextInput, setShowTextInput] = useState(false);
  const [fontSize, setFontSize] = useState(24);
  const [fontFamily, setFontFamily] = useState('Arial');

  // AI Generation state
  const [aiPrompt, setAiPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [showAiPanel, setShowAiPanel] = useState(false);

  // Get current history index for UI
  const getHistoryIndex = () => historyIndexRef.current;
  const getHistoryLength = () => historyRef.current.length;

  // Initialize canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    // Set canvas size
    canvas.width = 512;
    canvas.height = 512;

    // Fill with transparent background
    ctx.fillStyle = 'transparent';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Load initial image if editing existing label
    if (initialImageData) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        // Scale to fit canvas while maintaining aspect ratio
        const scale = Math.min(
          canvas.width / img.width,
          canvas.height / img.height
        );
        const width = img.width * scale;
        const height = img.height * scale;
        const x = (canvas.width - width) / 2;
        const y = (canvas.height - height) / 2;

        ctx.drawImage(img, x, y, width, height);
        saveToHistory();
        console.log('Loaded initial image for editing');
      };
      img.onerror = (e) => {
        console.error('Failed to load initial image:', e);
      };
      img.src = initialImageData;
    } else {
      // Save initial state
      saveToHistory();
    }
  }, [initialImageData]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl+Z or Cmd+Z for undo
      if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
        e.preventDefault();
        undo();
      }
      // Ctrl+Y or Ctrl+Shift+Z for redo
      if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || (e.shiftKey && e.key === 'z'))) {
        e.preventDefault();
        redo();
      }
      // Delete selected object
      if ((e.key === 'Delete' || e.key === 'Backspace') && !showTextInput && !showAiPanel) {
        if (selectedObjectId) {
          e.preventDefault();
          deleteSelectedObject();
        }
      }
      // Escape to deselect
      if (e.key === 'Escape') {
        setSelectedObjectId(null);
        setShowTextInput(false);
        setShowAiPanel(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedObjectId, showTextInput, showAiPanel]);

  // Reset composite operation when tool changes
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx) return;
    ctx.globalCompositeOperation = 'source-over';
    
    // Deselect object when changing tools
    if (tool !== 'select') {
      setSelectedObjectId(null);
    }
  }, [tool]);

  // Flag to prevent redraw when loading AI image
  const isLoadingAiImage = useRef(false);

  // Redraw whenever objects change
  useEffect(() => {
    // Skip redraw when loading AI image (canvas is handled separately)
    if (isLoadingAiImage.current) {
      isLoadingAiImage.current = false;
      return;
    }
    redrawCanvas();
  }, [objects, selectedObjectId]);

  const saveToHistory = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const currentState: HistoryState = {
      imageData,
      objects: [...objects],
    };

    // If we're not at the end of history, truncate
    if (historyIndexRef.current < historyRef.current.length - 1) {
      historyRef.current = historyRef.current.slice(0, historyIndexRef.current + 1);
    }

    // Add new state
    historyRef.current.push(currentState);
    
    // Keep only last 20 states
    if (historyRef.current.length > 20) {
      historyRef.current = historyRef.current.slice(-20);
    }
    
    historyIndexRef.current = historyRef.current.length - 1;
    forceUpdate(n => n + 1);
  }, [objects]);

  const undo = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx || historyIndexRef.current <= 0) return;

    historyIndexRef.current--;
    const previousState = historyRef.current[historyIndexRef.current];
    
    if (previousState) {
      ctx.putImageData(previousState.imageData, 0, 0);
      setObjects([...previousState.objects]);
      setSelectedObjectId(null);
      forceUpdate(n => n + 1);
    }
  }, []);

  const redo = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx || historyIndexRef.current >= historyRef.current.length - 1) return;

    historyIndexRef.current++;
    const nextState = historyRef.current[historyIndexRef.current];
    
    if (nextState) {
      ctx.putImageData(nextState.imageData, 0, 0);
      setObjects([...nextState.objects]);
      setSelectedObjectId(null);
      forceUpdate(n => n + 1);
    }
  }, []);

  const getMousePos = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  };

  const redrawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Redraw all objects
    objects.forEach(obj => {
      ctx.strokeStyle = obj.color;
      ctx.fillStyle = obj.color;
      ctx.lineWidth = obj.lineWidth;

      switch (obj.type) {
        case 'rectangle':
          ctx.beginPath();
          ctx.rect(obj.x, obj.y, obj.width || 0, obj.height || 0);
          ctx.stroke();
          break;
        case 'circle':
          ctx.beginPath();
          ctx.arc(obj.x, obj.y, obj.radius || 0, 0, Math.PI * 2);
          ctx.stroke();
          break;
        case 'triangle':
          ctx.beginPath();
          ctx.moveTo(obj.x, (obj.y + (obj.height || 0)));
          ctx.lineTo(obj.x + (obj.width || 0) / 2, obj.y);
          ctx.lineTo((obj.x + (obj.width || 0)), (obj.y + (obj.height || 0)));
          ctx.closePath();
          ctx.stroke();
          break;
        case 'line':
          ctx.beginPath();
          ctx.moveTo(obj.x, obj.y);
          ctx.lineTo(obj.endX || obj.x, obj.endY || obj.y);
          ctx.stroke();
          break;
        case 'text':
          if (obj.text && obj.fontSize) {
            const font = obj.fontFamily || 'Arial';
            ctx.font = `${obj.fontSize}px "${font}", sans-serif`;
            ctx.textBaseline = 'top';
            // Handle multiline text
            const lines = obj.text.split('\n');
            lines.forEach((line, index) => {
              ctx.fillText(line, obj.x, obj.y + index * obj.fontSize! * 1.2);
            });
          }
          break;
      }

      // Draw selection highlight
      if (obj.id === selectedObjectId) {
        ctx.strokeStyle = '#8b5cf6';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 5]);
        
        const bounds = getObjectBounds(obj);
        ctx.strokeRect(bounds.x - 5, bounds.y - 5, bounds.width + 10, bounds.height + 10);
        
        ctx.setLineDash([]);
      }
    });
  }, [objects, selectedObjectId]);

  const getObjectBounds = (obj: DrawableObject) => {
    switch (obj.type) {
      case 'rectangle':
        return { x: obj.x, y: obj.y, width: obj.width || 0, height: obj.height || 0 };
      case 'circle':
        const r = obj.radius || 0;
        return { x: obj.x - r, y: obj.y - r, width: r * 2, height: r * 2 };
      case 'triangle':
        return { x: obj.x, y: obj.y, width: obj.width || 0, height: obj.height || 0 };
      case 'line':
        const minX = Math.min(obj.x, obj.endX || obj.x);
        const minY = Math.min(obj.y, obj.endY || obj.y);
        const maxX = Math.max(obj.x, obj.endX || obj.x);
        const maxY = Math.max(obj.y, obj.endY || obj.y);
        return { x: minX, y: minY, width: (maxX - minX) || 10, height: (maxY - minY) || 10 };
      case 'text':
        if (obj.text && obj.fontSize) {
          const canvas = canvasRef.current;
          const ctx = canvas?.getContext('2d');
          let maxWidth = 0;
          const lines = obj.text.split('\n');
          const font = obj.fontFamily || 'Arial';
          if (ctx) {
            ctx.font = `${obj.fontSize}px "${font}", sans-serif`;
            lines.forEach(line => {
              const metrics = ctx.measureText(line);
              maxWidth = Math.max(maxWidth, metrics.width);
            });
          } else {
            maxWidth = obj.text.length * obj.fontSize * 0.6;
          }
          const height = lines.length * obj.fontSize * 1.2;
          return { x: obj.x, y: obj.y, width: maxWidth, height };
        }
        return { x: obj.x, y: obj.y, width: 50, height: 20 };
      default:
        return { x: 0, y: 0, width: 0, height: 0 };
    }
  };

  const findObjectAtPoint = (x: number, y: number): DrawableObject | null => {
    // Search in reverse order (top objects first)
    for (let i = objects.length - 1; i >= 0; i--) {
      const obj = objects[i];
      const bounds = getObjectBounds(obj);
      
      // Add some padding for easier selection
      if (
        x >= bounds.x - 5 &&
        x <= bounds.x + bounds.width + 5 &&
        y >= bounds.y - 5 &&
        y <= bounds.y + bounds.height + 5
      ) {
        return obj;
      }
    }
    return null;
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const pos = getMousePos(e);

    // Handle text tool separately
    if (tool === 'text') {
      setTextPosition(pos);
      setShowTextInput(true);
      return;
    }

    // Handle select tool
    if (tool === 'select') {
      const obj = findObjectAtPoint(pos.x, pos.y);
      if (obj) {
        setSelectedObjectId(obj.id);
        setIsDraggingObject(true);
        setDragOffset({ x: pos.x - obj.x, y: pos.y - obj.y });
      } else {
        setSelectedObjectId(null);
      }
      return;
    }

    setIsDrawing(true);
    setStartPoint(pos);

    // Save current state for shape preview
    if (['rectangle', 'circle', 'triangle', 'line'].includes(tool)) {
      setTempImageData(ctx.getImageData(0, 0, canvas.width, canvas.height));
    }

    if (tool === 'pen' || tool === 'eraser') {
      ctx.beginPath();
      ctx.moveTo(pos.x, pos.y);
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const pos = getMousePos(e);

    // Handle object dragging
    if (tool === 'select' && isDraggingObject && selectedObjectId) {
      const obj = objects.find(o => o.id === selectedObjectId);
      if (obj) {
        const newX = pos.x - dragOffset.x;
        const newY = pos.y - dragOffset.y;
        
        setObjects(prev => prev.map(o => {
          if (o.id === selectedObjectId) {
            // For circle, only update center position
            if (o.type === 'circle') {
              return { ...o, x: newX, y: newY };
            }
            // For line, move both start and end points
            if (o.type === 'line') {
              const dx = newX - o.x;
              const dy = newY - o.y;
              return { ...o, x: newX, y: newY, endX: (o.endX || o.x) + dx, endY: (o.endY || o.y) + dy };
            }
            return { ...o, x: newX, y: newY };
          }
          return o;
        }));
      }
      return;
    }

    if (!isDrawing) return;

    // Handle freehand drawing tools
    if (tool === 'pen' || tool === 'eraser') {
      ctx.globalCompositeOperation = 'source-over';
      
      if (tool === 'eraser') {
        ctx.globalCompositeOperation = 'destination-out';
        ctx.strokeStyle = 'rgba(0,0,0,1)';
      } else {
        ctx.strokeStyle = brushColor;
      }

      ctx.lineWidth = brushSize;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
      return;
    }

    // Handle shape tools - preview
    if (['rectangle', 'circle', 'triangle', 'line'].includes(tool) && startPoint && tempImageData) {
      ctx.putImageData(tempImageData, 0, 0);
      
      ctx.strokeStyle = brushColor;
      ctx.lineWidth = brushSize;

      drawShapePreview(ctx, tool, startPoint, pos);
    }
  };

  const handleMouseUp = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDraggingObject) {
      setIsDraggingObject(false);
      saveToHistory();
      return;
    }

    if (!isDrawing) return;

    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const pos = getMousePos(e);

    // Finalize shape
    if (['rectangle', 'circle', 'triangle', 'line'].includes(tool) && startPoint) {
      const objectId = `obj-${Date.now()}`;
      let newObject: DrawableObject | null = null;

      switch (tool) {
        case 'rectangle':
          newObject = {
            id: objectId,
            type: 'rectangle',
            x: Math.min(startPoint.x, pos.x),
            y: Math.min(startPoint.y, pos.y),
            width: Math.abs(pos.x - startPoint.x),
            height: Math.abs(pos.y - startPoint.y),
            color: brushColor,
            lineWidth: brushSize,
          };
          break;
        case 'circle':
          const radius = Math.sqrt(
            Math.pow(pos.x - startPoint.x, 2) + Math.pow(pos.y - startPoint.y, 2)
          );
          newObject = {
            id: objectId,
            type: 'circle',
            x: startPoint.x,
            y: startPoint.y,
            radius,
            color: brushColor,
            lineWidth: brushSize,
          };
          break;
        case 'triangle':
          newObject = {
            id: objectId,
            type: 'triangle',
            x: Math.min(startPoint.x, pos.x),
            y: Math.min(startPoint.y, pos.y),
            width: Math.abs(pos.x - startPoint.x),
            height: Math.abs(pos.y - startPoint.y),
            color: brushColor,
            lineWidth: brushSize,
          };
          break;
        case 'line':
          newObject = {
            id: objectId,
            type: 'line',
            x: startPoint.x,
            y: startPoint.y,
            endX: pos.x,
            endY: pos.y,
            color: brushColor,
            lineWidth: brushSize,
          };
          break;
      }

      if (newObject) {
        setObjects(prev => [...prev, newObject!]);
      }
    }

    setIsDrawing(false);
    setStartPoint(null);
    setTempImageData(null);
    saveToHistory();
  };

  const drawShapePreview = (
    ctx: CanvasRenderingContext2D,
    shapeTool: ToolType,
    start: { x: number; y: number },
    end: { x: number; y: number }
  ) => {
    ctx.beginPath();
    
    switch (shapeTool) {
      case 'rectangle':
        ctx.rect(start.x, start.y, end.x - start.x, end.y - start.y);
        ctx.stroke();
        break;
      case 'circle':
        const radius = Math.sqrt(
          Math.pow(end.x - start.x, 2) + Math.pow(end.y - start.y, 2)
        );
        ctx.arc(start.x, start.y, radius, 0, Math.PI * 2);
        ctx.stroke();
        break;
      case 'triangle':
        ctx.moveTo(start.x, end.y);
        ctx.lineTo((start.x + end.x) / 2, start.y);
        ctx.lineTo(end.x, end.y);
        ctx.closePath();
        ctx.stroke();
        break;
      case 'line':
        ctx.moveTo(start.x, start.y);
        ctx.lineTo(end.x, end.y);
        ctx.stroke();
        break;
    }
  };

  const deleteSelectedObject = useCallback(() => {
    if (!selectedObjectId) return;
    setObjects(prev => prev.filter(o => o.id !== selectedObjectId));
    setSelectedObjectId(null);
    // Schedule save to history after state update
    setTimeout(() => {
      saveToHistory();
    }, 0);
  }, [selectedObjectId, saveToHistory]);

  const handleAddText = () => {
    if (!textInput.trim() || !textPosition) return;

    const objectId = `obj-${Date.now()}`;
    const newObject: DrawableObject = {
      id: objectId,
      type: 'text',
      x: textPosition.x,
      y: textPosition.y,
      text: textInput,
      fontSize,
      fontFamily,
      color: brushColor,
      lineWidth: brushSize,
    };

    setObjects(prev => [...prev, newObject]);
    setTextInput('');
    setTextPosition(null);
    setShowTextInput(false);
    saveToHistory();
  };

  // AI Image Generation
  const handleAiGenerate = async () => {
    if (!aiPrompt.trim()) {
      setAiError('Please enter a description');
      return;
    }

    setIsGenerating(true);
    setAiError(null);

    try {
      const response = await fetch('/api/ai/generate-image', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: aiPrompt,
          size: '2K',
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate image');
      }

      // Load the generated image onto canvas (using base64 data URL to avoid CORS)
      const img = new Image();
      img.onload = () => {
        const canvas = canvasRef.current;
        const ctx = canvas?.getContext('2d');
        if (!canvas || !ctx) return;

        // Set flag to prevent redrawCanvas from clearing our image
        isLoadingAiImage.current = true;

        // Clear canvas and draw new image
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Scale to fit canvas while maintaining aspect ratio
        const scale = Math.min(
          canvas.width / img.width,
          canvas.height / img.height
        );
        const width = img.width * scale;
        const height = img.height * scale;
        const x = (canvas.width - width) / 2;
        const y = (canvas.height - height) / 2;

        ctx.drawImage(img, x, y, width, height);
        
        // Clear objects since we replaced the canvas content
        setObjects([]);
        setSelectedObjectId(null);
        
        // Save to history after state updates
        setTimeout(() => {
          saveToHistory();
        }, 0);
        
        setShowAiPanel(false);
        setAiPrompt('');
        setIsGenerating(false);
      };
      
      img.onerror = (e) => {
        console.error('Image load error:', e);
        setAiError('Failed to load generated image');
        setIsGenerating(false);
      };
      
      img.src = data.imageUrl;
    } catch (error) {
      console.error('AI generation error:', error);
      setAiError(error instanceof Error ? error.message : 'Failed to generate image');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingFile(false);

    const file = e.dataTransfer.files[0];
    if (!file || !file.type.startsWith('image/')) return;
    processImageFile(file);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingFile(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingFile(false);
  };

  const processImageFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = canvasRef.current;
        const ctx = canvas?.getContext('2d');
        if (!canvas || !ctx) return;

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        const scale = Math.min(
          canvas.width / img.width,
          canvas.height / img.height
        );
        const width = img.width * scale;
        const height = img.height * scale;
        const x = (canvas.width - width) / 2;
        const y = (canvas.height - height) / 2;

        ctx.drawImage(img, x, y, width, height);
        saveToHistory();
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleClear = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setObjects([]);
    setSelectedObjectId(null);
    saveToHistory();
  };

  const handleSave = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const imageData = canvas.toDataURL('image/png');
    console.log('Saving label, imageData length:', imageData.length);
    onLabelCreated(imageData);
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const link = document.createElement('a');
    link.download = `label-${Date.now()}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  const tools: { id: ToolType; icon: React.ReactNode; label: string }[] = [
    { id: 'select', icon: <Move className="w-4 h-4" />, label: 'Select/Move' },
    { id: 'pen', icon: <Pencil className="w-4 h-4" />, label: 'Pen' },
    { id: 'eraser', icon: <Eraser className="w-4 h-4" />, label: 'Eraser' },
    { id: 'rectangle', icon: <Square className="w-4 h-4" />, label: 'Rectangle' },
    { id: 'circle', icon: <Circle className="w-4 h-4" />, label: 'Circle' },
    { id: 'triangle', icon: <Triangle className="w-4 h-4" />, label: 'Triangle' },
    { id: 'line', icon: <Minus className="w-4 h-4" />, label: 'Line' },
    { id: 'text', icon: <Type className="w-4 h-4" />, label: 'Text' },
    { id: 'ai', icon: <Sparkles className="w-4 h-4" />, label: 'AI Generate' },
  ];

  return (
    <div className="fixed inset-4 z-50 bg-black/40 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-600 to-indigo-600 flex items-center justify-center">
            <Pencil className="w-4 h-4 text-white" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-white">
              {initialImageData ? 'Edit Label' : 'Label Editor'}
            </h2>
            <p className="text-xs text-gray-400">
              {initialImageData ? 'Modify the existing label' : 'Draw, shapes, text or AI generate'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="default"
            size="sm"
            onClick={handleSave}
            className="h-9 px-4 bg-gradient-to-r from-violet-600 to-indigo-600 hover:shadow-lg hover:shadow-violet-500/25 text-white font-medium"
          >
            <Save className="w-4 h-4 mr-1" />
            {initialImageData ? 'Update Label' : 'Save Label'}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="h-8 w-8 hover:bg-white/5 text-gray-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Tools */}
      <div className="flex items-center gap-2 p-3 border-b border-white/10 flex-wrap">
        {/* Tool Buttons */}
        <div className="flex gap-1 p-1 bg-white/5 rounded-lg">
          {tools.map((t) => (
            <Button
              key={t.id}
              variant={tool === t.id ? 'default' : 'ghost'}
              size="sm"
              onClick={() => {
                setTool(t.id);
                if (t.id === 'ai') {
                  setShowAiPanel(true);
                }
              }}
              className={`h-8 px-2 ${tool === t.id ? 'bg-violet-600 text-white' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
              title={t.label}
            >
              {t.icon}
            </Button>
          ))}
        </div>

        <div className="w-px h-6 bg-white/10" />

        {/* Color Picker */}
        <div className="flex items-center gap-2">
          <label className="text-xs text-gray-400">Color</label>
          <input
            type="color"
            value={brushColor}
            onChange={(e) => setBrushColor(e.target.value)}
            className="w-8 h-8 rounded cursor-pointer bg-transparent border border-gray-700"
          />
        </div>

        {/* Brush Size */}
        <div className="flex items-center gap-2">
          <label className="text-xs text-gray-400">Size</label>
          <input
            type="range"
            min="1"
            max="50"
            value={brushSize}
            onChange={(e) => setBrushSize(parseInt(e.target.value))}
            className="w-20 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-violet-600"
          />
          <span className="text-xs text-gray-500 w-6">{brushSize}</span>
        </div>

        {/* Font Size & Family (only for text tool) */}
        {tool === 'text' && (
          <>
            <div className="w-px h-6 bg-gray-700/50" />
            <div className="flex items-center gap-2">
              <label className="text-xs text-gray-400">Size</label>
              <input
                type="range"
                min="12"
                max="72"
                value={fontSize}
                onChange={(e) => setFontSize(parseInt(e.target.value))}
                className="w-16 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-violet-600"
              />
              <span className="text-xs text-gray-500 w-8">{fontSize}px</span>
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs text-gray-400">Font</label>
              <select
                value={fontFamily}
                onChange={(e) => setFontFamily(e.target.value)}
                className="h-8 px-2 bg-gray-800 border border-gray-700 rounded text-white text-xs focus:outline-none focus:border-violet-500"
                style={{ fontFamily: fontFamily }}
              >
                {AVAILABLE_FONTS.map(font => (
                  <option key={font.value} value={font.value} style={{ fontFamily: font.value }}>
                    {font.label}
                  </option>
                ))}
              </select>
            </div>
          </>
        )}

        <div className="flex-1" />

        {/* Undo/Redo */}
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={undo}
            disabled={getHistoryIndex() <= 0}
            className="h-8 px-2 text-gray-400 hover:text-white hover:bg-white/5 disabled:opacity-30"
            title="Undo (Ctrl+Z)"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={redo}
            disabled={getHistoryIndex() >= getHistoryLength() - 1}
            className="h-8 px-2 text-gray-400 hover:text-white hover:bg-white/5 disabled:opacity-30"
            title="Redo (Ctrl+Y)"
          >
            <RotateCcw className="w-4 h-4 scale-x-[-1]" />
          </Button>
        </div>

        {/* Delete selected object */}
        {selectedObjectId && (
          <Button
            variant="ghost"
            size="sm"
            onClick={deleteSelectedObject}
            className="h-8 px-2 text-red-400 hover:text-red-300 hover:bg-red-900/20"
            title="Delete selected (Delete)"
          >
            <X className="w-4 h-4" />
          </Button>
        )}
      </div>

      {/* Canvas Area */}
      <div className="flex-1 relative overflow-hidden bg-black/10 flex items-center justify-center">
        <div
          className="relative"
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
        >
          <canvas
            ref={canvasRef}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            className="border border-white/10 rounded-lg bg-[repeating-conic-gradient(#333_0%_25%,#222_0%_50%)] bg-[length:20px_20px]"
            style={{ cursor: tool === 'select' ? 'move' : tool === 'text' ? 'text' : 'crosshair' }}
          />

          {/* Empty State Hint */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="text-center opacity-30">
              <ImageIcon className="w-16 h-16 mx-auto mb-3 text-gray-500" />
              <p className="text-sm text-gray-500">Draw here, upload or AI generate</p>
            </div>
          </div>

          {/* Drag Overlay */}
          {isDraggingFile && (
            <div className="absolute inset-0 bg-violet-600/20 backdrop-blur-sm border-2 border-dashed border-violet-500 rounded-lg flex items-center justify-center pointer-events-none">
              <div className="text-center">
                <Upload className="w-12 h-12 mx-auto mb-2 text-violet-400" />
                <p className="text-base font-medium text-violet-300">Drop image here</p>
              </div>
            </div>
          )}

          {/* Text Input Modal */}
          {showTextInput && textPosition && (
            <div 
              className="absolute bg-black/90 border border-violet-500/50 rounded-lg p-4 shadow-xl min-w-80"
              style={{ 
                left: Math.min(textPosition.x, 350), 
                top: Math.min(textPosition.y, 350),
                zIndex: 100 
              }}
            >
              <div className="mb-3">
                <textarea
                  value={textInput}
                  onChange={(e) => setTextInput(e.target.value)}
                  placeholder="Enter text..."
                  className="w-full h-20 p-2 bg-black/50 border border-white/10 rounded text-white text-sm resize-none focus:outline-none focus:border-violet-500"
                  style={{ fontFamily: fontFamily, fontSize: fontSize }}
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && e.ctrlKey) {
                      handleAddText();
                    }
                    if (e.key === 'Escape') {
                      setShowTextInput(false);
                      setTextInput('');
                    }
                  }}
                />
              </div>
              
              {/* Font controls in modal */}
              <div className="flex items-center gap-3 mb-3 p-2 bg-black/30 rounded">
                <div className="flex items-center gap-2">
                  <label className="text-xs text-gray-400">Size</label>
                  <input
                    type="range"
                    min="12"
                    max="72"
                    value={fontSize}
                    onChange={(e) => setFontSize(parseInt(e.target.value))}
                    className="w-16 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-violet-600"
                  />
                  <span className="text-xs text-gray-500 w-8">{fontSize}px</span>
                </div>
                <div className="flex items-center gap-2">
                  <label className="text-xs text-gray-400">Font</label>
                  <select
                    value={fontFamily}
                    onChange={(e) => setFontFamily(e.target.value)}
                    className="h-7 px-2 bg-black border border-white/10 rounded text-white text-xs focus:outline-none focus:border-violet-500"
                    style={{ fontFamily: fontFamily }}
                  >
                    {AVAILABLE_FONTS.map(font => (
                      <option key={font.value} value={font.value} style={{ fontFamily: font.value }}>
                        {font.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              
              <div className="flex justify-end gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setShowTextInput(false);
                    setTextInput('');
                  }}
                  className="h-8 text-xs text-gray-400 hover:text-white"
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  onClick={handleAddText}
                  className="h-8 text-xs bg-violet-600 hover:bg-violet-700"
                >
                  Add Text
                </Button>
              </div>
              <p className="text-xs text-gray-500 mt-2 text-center">Ctrl+Enter to confirm</p>
            </div>
          )}

          {/* AI Generation Panel */}
          {showAiPanel && (
            <div 
              className="absolute bg-black/90 border border-violet-500/50 rounded-lg p-4 shadow-xl w-96"
              style={{ 
                left: '50%',
                top: '50%',
                transform: 'translate(-50%, -50%)',
                zIndex: 100 
              }}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-violet-400" />
                  <h3 className="text-sm font-medium text-white">AI Image Generation</h3>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setShowAiPanel(false);
                    setAiError(null);
                  }}
                  className="h-6 w-6 text-gray-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              
              <p className="text-xs text-gray-400 mb-3">
                Describe the image you want to generate. The AI will create it for you.
              </p>
              
              <textarea
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder="e.g., A golden star pattern on transparent background, elegant and minimalist style..."
                className="w-full h-24 p-3 bg-black/50 border border-white/10 rounded-lg text-white text-sm resize-none focus:outline-none focus:border-violet-500 placeholder-gray-500"
                disabled={isGenerating}
              />
              
              {aiError && (
                <div className="mt-2 p-2 bg-red-900/20 border border-red-500/30 rounded text-xs text-red-400">
                  {aiError}
                </div>
              )}
              
              <div className="flex justify-end gap-2 mt-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setShowAiPanel(false);
                    setAiError(null);
                    setAiPrompt('');
                  }}
                  disabled={isGenerating}
                  className="h-8 text-xs text-gray-400 hover:text-white"
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  onClick={handleAiGenerate}
                  disabled={isGenerating || !aiPrompt.trim()}
                  className="h-8 px-4 text-xs bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3 h-3 mr-1" />
                      Generate
                    </>
                  )}
                </Button>
              </div>
              
              <p className="text-xs text-gray-500 mt-3 text-center">
                Generated image will replace current canvas content
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Footer with shortcuts hint */}
      <div className="flex items-center justify-between p-3 border-t border-white/10">
        <div className="flex items-center gap-4 text-xs text-gray-500">
          <span><kbd className="px-1.5 py-0.5 bg-black/40 rounded text-gray-400">Ctrl+Z</kbd> Undo</span>
          <span><kbd className="px-1.5 py-0.5 bg-black/40 rounded text-gray-400">Ctrl+Y</kbd> Redo</span>
          {tool === 'select' && <span><kbd className="px-1.5 py-0.5 bg-black/40 rounded text-gray-400">Delete</kbd> Remove</span>}
        </div>
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              const input = document.createElement('input');
              input.type = 'file';
              input.accept = 'image/*';
              input.onchange = (evt) => {
                const file = (evt.target as HTMLInputElement).files?.[0];
                if (file) processImageFile(file);
              };
              document.body.appendChild(input);
              input.click();
              document.body.removeChild(input);
            }}
            className="h-10 px-4 flex items-center gap-2 rounded-md bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10 hover:text-white transition-colors cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            Upload
          </button>

          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowAiPanel(true)}
            className="h-10 px-4 bg-violet-600/20 border border-violet-500/30 text-violet-300 hover:bg-violet-600/30 hover:text-violet-200"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            AI Generate
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={handleDownload}
            className="h-10 px-4 bg-white/5 border-white/10 text-gray-300 hover:bg-white/10 hover:text-white"
          >
            <Download className="w-4 h-4 mr-2" />
            Download
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={handleClear}
            className="h-10 px-4 bg-white/5 border-white/10 text-gray-300 hover:bg-white/10 hover:text-white"
          >
            <X className="w-4 h-4 mr-2" />
            Clear
          </Button>
        </div>
      </div>
    </div>
  );
}
