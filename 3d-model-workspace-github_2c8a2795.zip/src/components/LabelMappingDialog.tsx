'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useSceneStore } from '@/store/sceneStore';
import { useDecalModeStore, CoverageMode } from '@/store/decalModeStore';
import { X, AlertCircle, Check, Grid3X3, Target, Box, Layers, RotateCw } from 'lucide-react';
import { Label } from '@/store/labelStore';

interface LabelMappingDialogProps {
  label: Label;
  onClose: () => void;
  onApply: (label: Label, mode: CoverageMode) => void;
}

export function LabelMappingDialog({ label, onClose, onApply }: LabelMappingDialogProps) {
  const { models, selectedObjectUuid } = useSceneStore();
  const { setCoverageMode, repeatDensity, setRepeatDensity, opacity, setOpacity, decalRotation, setDecalRotation } = useDecalModeStore();
  const [selectedMode, setSelectedMode] = useState<CoverageMode>('full');

  // Get selected model info
  const selectedModel = models.find(m => m.id === selectedObjectUuid);
  const hasSelectedModel = !!selectedModel;

  // Handle apply
  const handleApply = () => {
    if (!hasSelectedModel) return;
    
    setCoverageMode(selectedMode);
    onApply(label, selectedMode);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <Card className="bg-gray-900/95 backdrop-blur-xl border-gray-800/50 rounded-2xl overflow-hidden shadow-2xl w-[420px] max-w-[90vw] max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-4 border-b border-gray-800/30 bg-gradient-to-r from-violet-600/20 to-indigo-600/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-600 to-indigo-600 flex items-center justify-center">
                <span className="text-lg">🏷️</span>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-white">Apply Label to 3D Model</h3>
                <p className="text-xs text-gray-400">{label.name}</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="h-8 w-8 hover:bg-gray-800/50 text-gray-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Label Preview */}
        <div className="p-4 border-b border-gray-800/30">
          <label className="text-xs font-medium text-gray-300 mb-2 block">Label Preview</label>
          <div
            className="w-full h-28 rounded-lg border border-gray-700/50 overflow-hidden bg-gray-950"
            style={{
              backgroundImage: `url(${label.imageData})`,
              backgroundSize: 'contain',
              backgroundPosition: 'center',
              backgroundRepeat: 'no-repeat',
            }}
          />
        </div>

        {/* Model Selection Status */}
        <div className="p-4 border-b border-gray-800/30">
          <label className="text-xs font-medium text-gray-300 mb-2 block">Target Model</label>
          
          {hasSelectedModel ? (
            <div className="flex items-center gap-3 p-3 rounded-lg bg-green-500/10 border border-green-500/30">
              <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                <Box className="w-5 h-5 text-green-400" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-green-400">{selectedModel.name}</p>
                <p className="text-xs text-gray-400">Model selected and ready</p>
              </div>
              <Check className="w-5 h-5 text-green-400" />
            </div>
          ) : (
            <div className="flex items-center gap-3 p-3 rounded-lg bg-amber-500/10 border border-amber-500/30">
              <div className="w-10 h-10 rounded-lg bg-amber-500/20 flex items-center justify-center">
                <AlertCircle className="w-5 h-5 text-amber-400" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-amber-400">No model selected</p>
                <p className="text-xs text-gray-400">Please select a 3D model first</p>
              </div>
            </div>
          )}

          {!hasSelectedModel && models.length > 0 && (
            <p className="text-xs text-gray-500 mt-2">
              💡 Click on a model in the 3D view to select it
            </p>
          )}

          {!hasSelectedModel && models.length === 0 && (
            <p className="text-xs text-gray-500 mt-2">
              💡 Import a 3D model first using the Import button
            </p>
          )}
        </div>

        {/* Mapping Mode Selection */}
        <div className="p-4 border-b border-gray-800/30">
          <label className="text-xs font-medium text-gray-300 mb-3 block">Mapping Mode</label>
          
          <div className="space-y-2">
            {/* Full Coverage Option */}
            <button
              onClick={() => setSelectedMode('full')}
              disabled={!hasSelectedModel}
              className={`w-full flex items-start gap-3 p-3 rounded-lg text-left transition-all ${
                selectedMode === 'full'
                  ? 'bg-gradient-to-r from-violet-600/20 to-indigo-600/20 border border-violet-500/50'
                  : 'bg-gray-800/30 border border-gray-700/50 hover:bg-gray-800/50'
              } ${!hasSelectedModel ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                selectedMode === 'full'
                  ? 'bg-gradient-to-br from-violet-600 to-indigo-600'
                  : 'bg-gray-700/50'
              }`}>
                <Grid3X3 className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <p className={`text-sm font-medium ${
                  selectedMode === 'full' ? 'text-white' : 'text-gray-300'
                }`}>
                  Full Coverage
                </p>
                <p className="text-xs text-gray-400 mt-0.5">
                  Apply label pattern across entire model surface
                </p>
              </div>
              {selectedMode === 'full' && (
                <Check className="w-5 h-5 text-violet-400 mt-1" />
              )}
            </button>

            {/* Partial Mapping Option */}
            <button
              onClick={() => setSelectedMode('single')}
              disabled={!hasSelectedModel}
              className={`w-full flex items-start gap-3 p-3 rounded-lg text-left transition-all ${
                selectedMode === 'single'
                  ? 'bg-gradient-to-r from-violet-600/20 to-indigo-600/20 border border-violet-500/50'
                  : 'bg-gray-800/30 border border-gray-700/50 hover:bg-gray-800/50'
              } ${!hasSelectedModel ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                selectedMode === 'single'
                  ? 'bg-gradient-to-br from-violet-600 to-indigo-600'
                  : 'bg-gray-700/50'
              }`}>
                <Target className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <p className={`text-sm font-medium ${
                  selectedMode === 'single' ? 'text-white' : 'text-gray-300'
                }`}>
                  Partial Mapping
                </p>
                <p className="text-xs text-gray-400 mt-0.5">
                  Click on model to place label at specific position
                </p>
              </div>
              {selectedMode === 'single' && (
                <Check className="w-5 h-5 text-violet-400 mt-1" />
              )}
            </button>
          </div>
        </div>

        {/* Parameters for Full Coverage */}
        {selectedMode === 'full' && hasSelectedModel && (
          <div className="p-4 border-b border-gray-800/30 space-y-4">
            {/* Pattern Density */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-gray-300 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5" />
                  Pattern Density
                </label>
                <span className="text-xs text-violet-400 font-mono bg-violet-500/10 px-2 py-0.5 rounded">
                  {repeatDensity}x
                </span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                step="1"
                value={repeatDensity}
                onChange={(e) => setRepeatDensity(parseInt(e.target.value))}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-violet-600"
              />
              <div className="flex justify-between text-xs text-gray-500">
                <span>Sparse</span>
                <span>Dense</span>
              </div>
            </div>

            {/* Opacity */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-gray-300">Opacity</label>
                <span className="text-xs text-violet-400 font-mono bg-violet-500/10 px-2 py-0.5 rounded">
                  {Math.round(opacity * 100)}% {opacity === 1 ? '(Solid)' : ''}
                </span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1"
                step="0.1"
                value={opacity}
                onChange={(e) => setOpacity(parseFloat(e.target.value))}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-violet-600"
              />
              <div className="flex justify-between text-xs text-gray-500">
                <span>Transparent</span>
                <span>Solid</span>
              </div>
            </div>

            {/* Rotation */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-gray-300">Rotation</label>
                <span className="text-xs text-violet-400 font-mono bg-violet-500/10 px-2 py-0.5 rounded">
                  {decalRotation}°
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="360"
                step="15"
                value={decalRotation}
                onChange={(e) => setDecalRotation(parseInt(e.target.value))}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-violet-600"
              />
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setDecalRotation((decalRotation - 45 + 360) % 360)}
                  className="h-7 text-xs flex-1 bg-gray-800/50 border-gray-700/50 hover:bg-gray-700"
                >
                  <RotateCw className="w-3 h-3 mr-1" />
                  -45°
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setDecalRotation((decalRotation + 45) % 360)}
                  className="h-7 text-xs flex-1 bg-gray-800/50 border-gray-700/50 hover:bg-gray-700"
                >
                  <RotateCw className="w-3 h-3 mr-1" />
                  +45°
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="p-4 flex gap-2">
          <Button
            variant="outline"
            onClick={onClose}
            className="flex-1 h-10 bg-gray-800/50 border-gray-700/50 hover:bg-gray-700 text-gray-300"
          >
            Cancel
          </Button>
          <Button
            onClick={handleApply}
            disabled={!hasSelectedModel}
            className={`flex-1 h-10 bg-gradient-to-r from-violet-600 to-indigo-600 hover:shadow-lg hover:shadow-violet-500/25 ${
              !hasSelectedModel ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          >
            {hasSelectedModel ? 'Apply Label' : 'Select Model First'}
          </Button>
        </div>
      </Card>
    </div>
  );
}
