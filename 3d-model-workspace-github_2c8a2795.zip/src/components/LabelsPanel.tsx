'use client';

import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Button } from '@/components/ui/button';
import { Plus, Pencil, Trash2, Target, Download, Loader2, X, Layers, Check, CheckCircle2 } from 'lucide-react';
import { useLabelStore, Label } from '@/store/labelStore';
import { useDecalModeStore, CoverageMode, SelectedFace } from '@/store/decalModeStore';
import { useSceneStore } from '@/store/sceneStore';
import { LabelEditor } from './LabelEditor';
import { shouldExcludeMesh } from '@/utils/meshFilter';
import * as THREE from 'three';

interface LabelsPanelProps {
  onClose?: () => void;
}

export function LabelsPanel({ onClose }: LabelsPanelProps) {
  const {
    labels,
    activeLabelId,
    openLabelEditor,
    deleteLabel,
    setActiveLabel,
    addLabel,
  } = useLabelStore();

  const { 
    enterDecalMode, 
    setCoverageMode, 
    setSelectionType,
    isDecalMode,
    activeLabelImage,
    exitDecalMode,
    clearSelection,
    selectedFaces,
    coverageMode,
    selectionType,
    cancelSelection,
  } = useDecalModeStore();
  const { selectedObjectUuid } = useSceneStore();

  const [isCreating, setIsCreating] = useState(false);
  const [editingLabel, setEditingLabel] = useState<Label | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [expandedLabelId, setExpandedLabelId] = useState<string | null>(null);
  
  // Selection complete toast state
  const [selectionToast, setSelectionToast] = useState(false);

  // Load saved labels on mount
  useEffect(() => {
    const loadSavedLabels = async () => {
      try {
        const response = await fetch('/api/labels/list');
        if (response.ok) {
          const data = await response.json();
          const store = useLabelStore.getState();
          
          data.labels.forEach((serverLabel: Label) => {
            const exists = store.labels.some(l => l.imageData === serverLabel.imageData);
            if (!exists) {
              addLabel({
                name: serverLabel.name,
                imageData: serverLabel.imageData,
              });
            }
          });
        }
      } catch (error) {
        console.error('Failed to load saved labels:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadSavedLabels();
  }, [addLabel]);

  // Listen for selection complete event to show toast
  useEffect(() => {
    const handleSelectionComplete = (event: CustomEvent) => {
      console.log('Selection complete:', event.detail);
      setSelectionToast(true);
      // Auto hide after 2 seconds
      setTimeout(() => setSelectionToast(false), 2000);
    };
    
    window.addEventListener('decal-selection-complete', handleSelectionComplete as EventListener);
    return () => {
      window.removeEventListener('decal-selection-complete', handleSelectionComplete as EventListener);
    };
  }, []);

  const handleCreateLabel = () => {
    setIsCreating(true);
    openLabelEditor();
  };

  const handleEditLabel = (label: Label) => {
    setEditingLabel(label);
    openLabelEditor(label.id);
  };

  const handleDeleteLabel = async (label: Label) => {
    if (!confirm('Are you sure you want to delete this label?')) {
      return;
    }

    try {
      // Delete from server if saved
      if (label.imageData && label.imageData.startsWith('/Label_Save/')) {
        const filename = label.imageData.replace('/Label_Save/', '');
        if (filename) {
          await fetch('/api/labels/delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename }),
          });
        }
      }
      
      // Clean up any decals associated with this label
      const decalState = useDecalModeStore.getState();
      const decalsToRemove = decalState.placedDecals.filter(d => d.labelId === label.id);
      
      // Remove decal meshes from scene
      decalsToRemove.forEach(decal => {
        window.dispatchEvent(new CustomEvent('remove-decal-mesh', {
          detail: { labelId: label.id }
        }));
      });
      
      // Remove from placed decals
      decalState.removePlacedDecal
        ? decalState.removePlacedDecal
        : decalsToRemove.forEach(() => {});
      
      // Remove from store
      deleteLabel(label.id);
      
      // Exit decal mode if this was the active label
      if (activeLabelId === label.id) {
        exitDecalMode();
      }
    } catch (error) {
      console.error('Failed to delete label:', error);
      alert('Failed to delete label. Please try again.');
    }
  };

  const handleApplyDecal = (label: Label) => {
    setExpandedLabelId(expandedLabelId === label.id ? null : label.id);
  };

  const handleSelectMappingMode = (label: Label, mode: CoverageMode) => {
    setActiveLabel(label.id);
    setCoverageMode(mode);
    
    const sceneState = useSceneStore.getState();
    const selectedModelId = sceneState.selectedObjectUuid;
    const selectedModel = sceneState.models.find(m => m.id === selectedModelId);
    
    // Must have a selected model for any mapping mode
    if (!selectedModelId || !selectedModel?.objectRef) {
      alert('Please select a 3D model first before applying labels.');
      return;
    }
    
    if (mode === 'full') {
      const loader = new THREE.TextureLoader();
      loader.load(label.imageData, (texture) => {
        texture.colorSpace = THREE.SRGBColorSpace;
        texture.wrapS = THREE.RepeatWrapping;
        texture.wrapT = THREE.RepeatWrapping;
        texture.minFilter = THREE.LinearMipmapLinearFilter;
        texture.magFilter = THREE.LinearFilter;
        texture.generateMipmaps = true;
        
        const decalState = useDecalModeStore.getState();
        const repeatCount = decalState.repeatDensity * 0.5;
        texture.repeat.set(repeatCount, repeatCount);
        texture.rotation = THREE.MathUtils.degToRad(decalState.decalRotation);
        texture.center.set(0.5, 0.5);
        texture.needsUpdate = true;
        
        // Collect all meshes to apply decal
        const meshesToApply: THREE.Mesh[] = [];
        selectedModel.objectRef!.traverse((child) => {
          if (child instanceof THREE.Mesh && !shouldExcludeMesh(child)) {
            meshesToApply.push(child);
          }
        });
        
        console.log(`Full Coverage: Found ${meshesToApply.length} meshes to apply`);
        
        const decalMeshNames: string[] = [];
        
        meshesToApply.forEach((mesh) => {
          // Create decal material
          const decalMaterial = new THREE.MeshStandardMaterial({
            map: texture,
            transparent: true,
            opacity: decalState.opacity,
            depthWrite: false,
            depthTest: true,
            polygonOffset: true,
            polygonOffsetFactor: -4,
            roughness: 0.7,
            metalness: 0.0,
            side: THREE.DoubleSide,
          });
          
          // Clone geometry (local coordinates)
          const decalGeometry = mesh.geometry.clone();
          const decalMesh = new THREE.Mesh(decalGeometry, decalMaterial);
          
          // Local identity transform (will inherit parent's world transform)
          decalMesh.position.set(0, 0, 0);
          decalMesh.quaternion.set(0, 0, 0, 1);
          decalMesh.scale.set(1, 1, 1);
          
          const decalMeshName = `decal-full-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
          decalMesh.name = decalMeshName;
          decalMesh.userData.isDecal = true;
          decalMesh.userData.parentMeshUuid = mesh.uuid;
          decalMesh.userData.originalMeshName = mesh.name;
          
          decalMeshNames.push(decalMeshName);
          // Add as child of the mesh so it follows the mesh transform
          mesh.add(decalMesh);
          
          console.log(`Applied decal to mesh: ${mesh.name}`);
        });
        
        useDecalModeStore.getState().pushHistory({
          actionType: 'full_coverage',
          labelId: label.id,
          modelId: selectedModelId!,
          materialSnapshots: [],
          decalMeshNames,
        });
        
        useDecalModeStore.getState().addPlacedDecal({
          labelId: label.id,
          modelId: selectedModelId!,
          coverageMode: 'full',
          repeatDensity: decalState.repeatDensity,
          opacity: decalState.opacity,
          rotation: decalState.decalRotation,
        });
        
        console.log(`Full Coverage: Applied ${decalMeshNames.length} decals`);
      });
    } else {
      // Local decal mode - enter decal mode and wait for user selection
      enterDecalMode(label.imageData, label.id);
    }
  };

  // Apply local decal to selected faces
  const handleApplyLocalDecal = async (label: Label) => {
    console.log('=== handleApplyLocalDecal START ===');
    console.log('label.imageData:', label.imageData);
    
    const decalState = useDecalModeStore.getState();
    console.log('selectedFaces from store:', decalState.selectedFaces);
    console.log('selectedFaces length:', decalState.selectedFaces.length);
    
    if (decalState.selectedFaces.length === 0) {
      console.warn('No selection to apply');
      return;
    }

    if (!(window as any).applyDecalToSelection) {
      console.error('applyDecalToSelection not available');
      return;
    }

    const success = await (window as any).applyDecalToSelection(label.imageData);
    console.log('applyDecalToSelection result:', success);

    if (success) {
      // Exit decal mode
      exitDecalMode();
      clearSelection();
      setExpandedLabelId(null);
      console.log('=== handleApplyLocalDecal SUCCESS ===');
    } else {
      console.error('=== handleApplyLocalDecal FAILED ===');
    }
  };

  const handleDownloadLabel = async (label: Label) => {
    if (!label.imageData) {
      console.error('No image data to download');
      return;
    }
    
    try {
      if (label.imageData.startsWith('/Label_Save/')) {
        const response = await fetch(label.imageData);
        if (!response.ok) throw new Error('Failed to fetch image');
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${label.name || 'label'}.png`;
        link.click();
        window.URL.revokeObjectURL(url);
      } else {
        const link = document.createElement('a');
        link.href = label.imageData;
        link.download = `${label.name || 'label'}.png`;
        link.click();
      }
    } catch (error) {
      console.error('Failed to download label:', error);
    }
  };

  const handleLabelCreated = async (imageData: string) => {
    try {
      const response = await fetch('/api/labels/save-local', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageData }),
      });

      if (!response.ok) throw new Error('Failed to save label');

      const result = await response.json();
      addLabel({ name: result.filename.replace('.png', ''), imageData: result.url });
      setIsCreating(false);
      useLabelStore.getState().closeLabelEditor();
      
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 2000);
    } catch (error) {
      console.error('Failed to save label:', error);
      alert('Failed to save label. Please try again.');
    }
  };

  const handleLabelUpdated = async (imageData: string) => {
    if (!editingLabel) return;
    
    try {
      if (editingLabel.imageData && editingLabel.imageData.startsWith('/Label_Save/')) {
        const oldFilename = editingLabel.imageData.replace('/Label_Save/', '');
        await fetch('/api/labels/delete', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ filename: oldFilename }),
        });
      }

      const response = await fetch('/api/labels/save-local', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageData }),
      });

      if (!response.ok) throw new Error('Failed to save label');

      const result = await response.json();
      useLabelStore.getState().updateLabel(editingLabel.id, {
        imageData: result.url,
        name: result.filename.replace('.png', ''),
      });

      setEditingLabel(null);
      useLabelStore.getState().closeLabelEditor();
      
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 2000);
    } catch (error) {
      console.error('Failed to update label:', error);
      alert('Failed to update label. Please try again.');
    }
  };

  const handleExitDecalMode = () => {
    clearSelection();
    exitDecalMode();
    setExpandedLabelId(null);
  };

  return (
    <div className="w-80 max-h-[calc(100vh-100px)] bg-black/40 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl flex flex-col overflow-hidden relative">
      {/* Selection Complete Toast */}
      {selectionToast && createPortal(
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[9999] animate-fade-in">
          <div className="bg-violet-600 text-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span className="text-sm font-medium">已选择</span>
            <span className="text-xs opacity-75">点击 Apply 完成映射</span>
          </div>
        </div>,
        document.body
      )}
      
      {/* Header - Fixed */}
      <div className="flex-shrink-0 p-4 border-b border-white/10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-gradient-to-br from-violet-600 to-indigo-600 flex items-center justify-center">
              <span className="text-sm">🏷️</span>
            </div>
            <h2 className="text-sm font-semibold text-white">Labels</h2>
            <span className="text-xs text-gray-500">({labels.length})</span>
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="default"
              size="sm"
              onClick={handleCreateLabel}
              className="h-8 bg-gradient-to-r from-violet-600 to-indigo-600 hover:shadow-lg hover:shadow-violet-500/25"
            >
              <Plus className="w-3.5 h-3.5 mr-1" />
              New
            </Button>
            {onClose && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                className="h-8 w-8 p-0 text-gray-400 hover:text-white hover:bg-white/5"
              >
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Scrollable Content Area */}
      <div className="flex-1 min-h-0 overflow-y-auto">
        {/* Labels List */}
        <div className="p-3">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-32 text-center">
              <Loader2 className="w-8 h-8 text-violet-500 animate-spin mb-4" />
              <p className="text-sm text-gray-400">Loading labels...</p>
            </div>
          ) : labels.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 text-center">
              <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-4">
                <span className="text-3xl">🏷️</span>
              </div>
              <p className="text-sm text-gray-400 mb-2">No labels yet</p>
              <p className="text-xs text-gray-500">Create your first label</p>
            </div>
          ) : (
            <div className="space-y-2">
              {labels.map((label) => (
                <div key={label.id} className="space-y-1">
                  {/* Label Card */}
                  <div
                    className={`group relative rounded-lg border overflow-hidden transition-all ${
                      activeLabelId === label.id && isDecalMode
                        ? 'border-violet-500 bg-violet-600/20'
                        : activeLabelId === label.id
                        ? 'border-violet-500/50 bg-violet-600/80'
                        : 'border-white/10 bg-white/5 hover:bg-white/10'
                    }`}
                  >
                    <div
                      className="w-full h-24 bg-black/10"
                      style={{
                        backgroundImage: `url(${label.imageData})`,
                        backgroundSize: 'contain',
                        backgroundPosition: 'center',
                        backgroundRepeat: 'no-repeat',
                      }}
                    />
                    <div className="p-2 bg-black/10">
                      <div className="flex items-center justify-between mb-1.5">
                        <h3 className="text-xs font-medium text-white truncate flex-1">{label.name}</h3>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditLabel(label)}
                          className="h-6 text-xs flex-1 bg-white/5 border-white/10 hover:bg-white/10 px-2"
                        >
                          <Pencil className="w-3 h-3 mr-1" />
                          Edit
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleApplyDecal(label)}
                          className={`h-6 text-xs flex-1 px-2 ${
                            expandedLabelId === label.id || (isDecalMode && activeLabelId === label.id)
                              ? 'bg-violet-600 border-violet-500 text-white'
                              : 'bg-violet-600/20 border-violet-500/30 hover:bg-violet-600/30 text-violet-300'
                          }`}
                        >
                          <Target className="w-3 h-3 mr-1" />
                          Apply
                        </Button>
                      </div>
                    </div>
                    <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDownloadLabel(label)}
                          className="h-6 w-6 bg-black/40 hover:bg-white/10"
                        >
                          <Download className="w-3 h-3 text-gray-400" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteLabel(label)}
                          className="h-6 w-6 bg-black/40 hover:bg-red-600/50"
                        >
                          <Trash2 className="w-3 h-3 text-red-400" />
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Mapping Options - Show when expanded and NOT in decal mode */}
                  {expandedLabelId === label.id && !isDecalMode && (
                    <div className="bg-black/30 border border-violet-500/30 rounded-lg p-2 space-y-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleSelectMappingMode(label, 'full')}
                        disabled={!selectedObjectUuid}
                        className="w-full h-8 text-xs bg-gradient-to-r from-violet-600/20 to-indigo-600/20 border-violet-500/30 hover:from-violet-600/40 hover:to-indigo-600/40 text-white disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <Layers className="w-3.5 h-3.5 mr-1.5" />
                        Full Coverage
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleSelectMappingMode(label, 'single')}
                        disabled={!selectedObjectUuid}
                        className="w-full h-8 text-xs bg-gradient-to-r from-amber-600/20 to-orange-600/20 border-amber-500/30 hover:from-amber-600/40 hover:to-orange-600/40 text-white disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <Target className="w-3.5 h-3.5 mr-1.5" />
                        Local Decal
                      </Button>
                      {!selectedObjectUuid && (
                        <p className="text-xs text-amber-400 text-center">Select a 3D model first</p>
                      )}
                    </div>
                  )}
                  
                  {/* Local Decal Mode UI - Show when in decal mode */}
                  {expandedLabelId === label.id && isDecalMode && activeLabelId === label.id && (
                    <div className="bg-black/30 border border-amber-500/30 rounded-lg p-2 space-y-3">
                      {/* Selection Status */}
                      <div className="text-xs text-gray-400 text-center">
                        {selectedFaces.length > 0 
                          ? `${selectedFaces.length} face(s) selected`
                          : 'Double-click on model to select area'}
                      </div>
                      
                      {/* Apply/Cancel Buttons */}
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={cancelSelection}
                          className="flex-1 h-8 text-xs bg-white/5 border-white/20 hover:bg-white/10"
                        >
                          <X className="w-3 h-3 mr-1" />
                          Cancel
                        </Button>
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() => handleApplyLocalDecal(label)}
                          disabled={selectedFaces.length === 0}
                          className="flex-1 h-8 text-xs bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50"
                        >
                          <Check className="w-3 h-3 mr-1" />
                          Apply
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Label Editor Modal - Rendered via Portal to avoid z-index issues */}
      {(isCreating || editingLabel) && createPortal(
        <LabelEditor
          initialImageData={editingLabel?.imageData}
          onLabelCreated={editingLabel ? handleLabelUpdated : handleLabelCreated}
          onClose={() => {
            setIsCreating(false);
            setEditingLabel(null);
            useLabelStore.getState().closeLabelEditor();
          }}
        />,
        document.body
      )}

      {/* Success Message */}
      {showSuccess && createPortal(
        <div className="fixed bottom-20 right-6 z-50 bg-green-600/90 backdrop-blur-sm text-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 animate-in slide-in-from-bottom-2">
          <span className="text-lg">✅</span>
          <span className="text-sm font-medium">Label saved successfully!</span>
        </div>,
        document.body
      )}

    </div>
  );
}
