'use client';

import { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

interface Layer3DViewerProps {
  modelUrl: string;
  rotation: { x: number; y: number; z: number };
  scale: number;
  isActive: boolean;
  onRotationChange?: (rotation: { x: number; y: number; z: number }) => void;
  width: number;
  height: number;
}

export function Layer3DViewer({
  modelUrl,
  rotation,
  scale,
  isActive,
  onRotationChange,
  width,
  height,
}: Layer3DViewerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const modelRef = useRef<THREE.Group | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    if (!canvasRef.current) return;

    // 初始化 Three.js
    const canvas = canvasRef.current;
    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(window.devicePixelRatio);
    rendererRef.current = renderer;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
    camera.position.z = 5;
    cameraRef.current = camera;

    // 加载模型
    const loader = new GLTFLoader();
    loader.load(
      modelUrl,
      (gltf: any) => {
        const model = gltf.scene;
        modelRef.current = model;
        scene.add(model);

        // 调整模型大小
        const box = new THREE.Box3().setFromObject(model);
        const size = box.getSize(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z);
        const targetSize = 2;
        const scaleFactor = targetSize / maxDim;
        model.scale.setScalar(scaleFactor);

        // 居中模型
        const center = box.getCenter(new THREE.Vector3());
        model.position.sub(center.multiplyScalar(scaleFactor));

        setIsLoaded(true);
      },
      undefined,
      (error: any) => {
        console.error('Failed to load 3D model:', error);
      }
    );

    // 灯光
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(5, 5, 5);
    scene.add(directionalLight);

    // 渲染循环
    const animate = () => {
      requestAnimationFrame(animate);

      if (modelRef.current) {
        // 应用旋转
        modelRef.current.rotation.x = THREE.MathUtils.degToRad(rotation.x);
        modelRef.current.rotation.y = THREE.MathUtils.degToRad(rotation.y);
        modelRef.current.rotation.z = THREE.MathUtils.degToRad(rotation.z);
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      renderer.dispose();
    };
  }, [modelUrl, width, height]);

  useEffect(() => {
    if (!rendererRef.current || !sceneRef.current || !cameraRef.current) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    let isDragging = false;
    let previousMousePosition = { x: 0, y: 0 };

    const handleMouseDown = (e: MouseEvent) => {
      if (!isActive) return;
      isDragging = true;
      previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging || !isActive) return;

      const deltaX = e.clientX - previousMousePosition.x;
      const deltaY = e.clientY - previousMousePosition.y;

      const newRotation = {
        x: rotation.x + deltaY * 0.5,
        y: rotation.y + deltaX * 0.5,
        z: rotation.z,
      };

      onRotationChange?.(newRotation);

      previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    const handleMouseUp = () => {
      isDragging = false;
    };

    canvas.addEventListener('mousedown', handleMouseDown);
    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mouseup', handleMouseUp);
    canvas.addEventListener('mouseleave', handleMouseUp);

    return () => {
      canvas.removeEventListener('mousedown', handleMouseDown);
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('mouseup', handleMouseUp);
      canvas.removeEventListener('mouseleave', handleMouseUp);
    };
  }, [rotation, isActive, onRotationChange]);

  return (
    <canvas
      ref={canvasRef}
      style={{
        width,
        height,
        display: 'block',
        cursor: isActive ? 'grab' : 'default',
      }}
    />
  );
}
