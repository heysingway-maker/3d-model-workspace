'use client';

import { useEffect, useState, useRef } from 'react';
import * as THREE from 'three';
import {
  ChevronRight,
  ChevronDown,
  Eye,
  EyeOff,
  Package,
  Layers,
  X,
  Sparkles,
  Trash2,
  Edit3,
} from 'lucide-react';
import { useSceneStore } from '@/store/sceneStore';

interface SceneNode {
  uuid: string;
  name: string;
  type: string;
  visible: boolean;
  children: SceneNode[];
  depth: number;
  isMesh: boolean;
  modelId?: string; // Reference to parent model
}

interface LayerPanelProps {
  scene: THREE.Scene | null;
  onSceneUpdate?: () => void;
}

export default function LayerPanel({ scene, onSceneUpdate }: LayerPanelProps) {
  const [isCollapsed, setIsCollapsed] = useState(true);
  const [editingModelId, setEditingModelId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');

  const {
    models,
    selectedObjectUuid,
    setSelectedObject,
    expandedNodes,
    toggleNode,
    expandNode,
    updateModel,
    removeModel,
  } = useSceneStore();

  const [sceneTree, setSceneTree] = useState<SceneNode[]>([]);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const prevSelectedRef = useRef<string | null>(null);

  useEffect(() => {
    if (!scene) return;
    sceneRef.current = scene;
  }, [scene]);

  // Build tree for a specific model
  const buildTreeForObject = (object: THREE.Object3D, depth = 0, modelId?: string): SceneNode | null => {
    if (
      object instanceof THREE.GridHelper ||
      object instanceof THREE.Camera ||
      object instanceof THREE.AmbientLight ||
      object instanceof THREE.DirectionalLight ||
      object instanceof THREE.PointLight ||
      object instanceof THREE.SpotLight ||
      object instanceof THREE.HemisphereLight
    ) {
      return null;
    }

    const isMesh = object instanceof THREE.Mesh;
    const children: SceneNode[] = [];

    if (object.children.length > 0) {
      object.children.forEach((child) => {
        const childNode = buildTreeForObject(child, depth + 1, modelId);
        if (childNode) {
          children.push(childNode);
        }
      });
    }

    if (isMesh && object.material) {
      const material = object.material as THREE.Material;
      const materialNode: SceneNode = {
        uuid: material.uuid || object.uuid + '_mat',
        name: material.name || 'Material',
        type: 'Material',
        visible: material.visible !== false,
        children: [],
        depth: depth + 1,
        isMesh: false,
        modelId,
      };
      children.push(materialNode);
    }

    return {
      uuid: object.uuid,
      name: object.name || (isMesh ? 'Mesh' : object.type),
      type: object.type,
      visible: object.visible,
      children,
      depth,
      isMesh,
      modelId,
    };
  };

  // Build complete scene tree from models
  useEffect(() => {
    if (!scene) return;

    console.log('=== Building Multi-Model Scene Tree ===');
    console.log('Models in store:', models.length);

    const tree: SceneNode[] = [];

    // Add Floor if exists
    const floor = scene.children.find(
      (c) => c instanceof THREE.Mesh && c.name === 'Floor'
    );
    if (floor) {
      const floorNode: SceneNode = {
        uuid: floor.uuid,
        name: 'Floor',
        type: 'Mesh',
        visible: floor.visible,
        children: [],
        depth: 0,
        isMesh: true,
      };
      tree.push(floorNode);
    }

    // Add all models
    models.forEach((model) => {
      if (!model.objectRef) return;

      const modelChildren: SceneNode[] = [];
      model.objectRef.children.forEach((child) => {
        const childNode = buildTreeForObject(child, 1, model.id);
        if (childNode) {
          modelChildren.push(childNode);
        }
      });

      const modelNode: SceneNode = {
        uuid: model.id, // Use model ID as UUID for selection
        name: model.name,
        type: 'Model',
        visible: model.visible,
        children: modelChildren,
        depth: 0,
        isMesh: false,
        modelId: model.id,
      };
      tree.push(modelNode);

      // Auto-expand first level
      if (modelChildren.length > 0) {
        expandNode(model.id);
      }
    });

    console.log('Total scene tree nodes:', tree.length);
    console.log('Scene tree structure:');

    const printTree = (nodes: SceneNode[], indent = '') => {
      nodes.forEach((node) => {
        console.log(`${indent}├─ ${node.name} (${node.type}) [children: ${node.children.length}]`);
        if (node.children.length > 0) {
          printTree(node.children, indent + '  ');
        }
      });
    };
    printTree(tree, '');

    setSceneTree(tree);
  }, [models, scene, expandNode]);

  // Auto-expand path to selected object
  useEffect(() => {
    if (!selectedObjectUuid || prevSelectedRef.current === selectedObjectUuid) {
      return;
    }

    console.log('Auto-expanding to selected object:', selectedObjectUuid);

    const expandPathToNode = (targetUuid: string, nodes: SceneNode[]): boolean => {
      for (const node of nodes) {
        if (node.uuid === targetUuid) {
          console.log(`Found selected node: ${node.name}`);
          return true;
        }
        if (expandPathToNode(targetUuid, node.children)) {
          console.log(`Expanding parent: ${node.name}`);
          expandNode(node.uuid);
          return true;
        }
      }
      return false;
    };

    expandPathToNode(selectedObjectUuid, sceneTree);
    prevSelectedRef.current = selectedObjectUuid;
  }, [selectedObjectUuid, expandNode, sceneTree]);

  const handleNodeClick = (uuid: string, node: SceneNode) => {
    console.log('Clicked node:', node.name, uuid);
    setSelectedObject(uuid);
  };

  const handleModelClick = (modelId: string) => {
    const model = models.find((m) => m.id === modelId);
    if (model && model.objectRef) {
      // Select the model group
      setSelectedObject(modelId);
    }
  };

  // Recursively update visibility in tree
  const updateNodeVisibility = (nodes: SceneNode[], targetUuid: string, newVisibility: boolean): boolean => {
    for (const node of nodes) {
      if (node.uuid === targetUuid) {
        node.visible = newVisibility;

        // Also update all children
        const updateChildren = (childNode: SceneNode) => {
          childNode.visible = newVisibility;
          childNode.children.forEach(updateChildren);
        };
        node.children.forEach(updateChildren);

        return true;
      }

      if (updateNodeVisibility(node.children, targetUuid, newVisibility)) {
        return true;
      }
    }
    return false;
  };

  const toggleVisibility = (e: React.MouseEvent, uuid: string, nodeType: string, modelId?: string) => {
    e.stopPropagation();
    e.preventDefault();

    console.log('=== Toggle Visibility ===');
    console.log('Target UUID:', uuid);
    console.log('Target Type:', nodeType);
    console.log('Model ID:', modelId);

    if (!scene) return;

    // Check if this is a model-level visibility toggle
    if (modelId && uuid === modelId) {
      const model = models.find((m) => m.id === modelId);
      if (model && model.objectRef) {
        const newVisibility = !model.visible;

        console.log(`🔄 Toggling model ${model.name} visibility: ${newVisibility}`);

        // 更新 store（这会触发 ModelViewer 中的同步）
        updateModel(modelId, { visible: newVisibility });

        // 更新树 UI 状态
        const updatedTree = [...sceneTree];
        updateNodeVisibility(updatedTree, uuid, newVisibility);
        setSceneTree(updatedTree);

        if (onSceneUpdate) onSceneUpdate();
      }
      return;
    }

    // Handle object-level visibility (Floor, Mesh, Material)
    const findObject = (obj: THREE.Object3D): { object: THREE.Object3D | null; isMaterial: boolean } => {
      if (obj.uuid === uuid) {
        return { object: obj, isMaterial: false };
      }

      if (obj instanceof THREE.Mesh && obj.material) {
        const material = obj.material as THREE.Material;
        if (material.uuid === uuid) {
          return { object: obj, isMaterial: true };
        }
      }

      for (const child of obj.children) {
        const result = findObject(child);
        if (result.object) {
          return result;
        }
      }

      return { object: null, isMaterial: false };
    };

    const result = findObject(scene);
    console.log('Find object result:', result);

    if (result.object) {
      const newVisibility = !result.object.visible;

      if (result.isMaterial && result.object instanceof THREE.Mesh) {
        const material = result.object.material as THREE.Material;
        material.visible = newVisibility;
        console.log(`Material visibility toggled: ${newVisibility}`);
      } else {
        result.object.visible = newVisibility;

        // Also update children visibility in 3D
        result.object.traverse((child) => {
          child.visible = newVisibility;
        });

        console.log(`Object ${result.object.name} (${result.object.type}) visibility toggled: ${newVisibility}`);
      }

      // Update tree UI state
      const updatedTree = [...sceneTree];
      updateNodeVisibility(updatedTree, uuid, newVisibility);
      setSceneTree(updatedTree);

      if (onSceneUpdate) {
        console.log('Calling onSceneUpdate to force re-render');
        onSceneUpdate();
      }
    } else {
      console.log('❌ Object not found:', uuid);
      console.log('Available objects in scene:');
      scene.traverse((child) => {
        console.log(`- ${child.name} (${child.type}) UUID: ${child.uuid}`);
      });
    }
  };

  const handleRenameStart = (e: React.MouseEvent, modelId: string, currentName: string) => {
    e.stopPropagation();
    setEditingModelId(modelId);
    setEditingName(currentName);
  };

  const handleRenameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEditingName(e.target.value);
  };

  const handleRenameConfirm = (modelId: string) => {
    if (editingName.trim()) {
      updateModel(modelId, { name: editingName.trim() });
    }
    setEditingModelId(null);
    setEditingName('');
  };

  const handleRenameCancel = () => {
    setEditingModelId(null);
    setEditingName('');
  };

  const handleDeleteModel = (e: React.MouseEvent, modelId: string) => {
    e.stopPropagation();

    if (!scene) return;

    const model = models.find((m) => m.id === modelId);
    if (model && model.objectRef) {
      scene.remove(model.objectRef);
      removeModel(modelId);
      console.log('Model removed:', model.name);
    }
  };

  return (
    <>
      {isCollapsed && (
        <button
          onClick={() => setIsCollapsed(false)}
          className="fixed top-20 left-4 z-50 w-10 h-10 rounded-lg bg-black/40 backdrop-blur-xl border border-white/10 flex items-center justify-center text-white hover:bg-black/60 transition-colors"
          title="展开图层面板"
        >
          <Layers className="w-5 h-5" />
        </button>
      )}

      {!isCollapsed && (
        <div className="fixed top-20 left-4 z-50 w-80 h-[calc(100vh-8rem)] min-h-[400px] flex flex-col bg-black/40 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl overflow-hidden">
          <div className="flex-shrink-0 flex items-center justify-between px-4 py-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-violet-400" />
              <span className="text-white font-medium text-sm">Layers ({models.length})</span>
            </div>
            <button
              onClick={() => setIsCollapsed(true)}
              className="p-1 rounded hover:bg-white/10 text-white/50 hover:text-white transition-colors"
              title="收缩面板"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-2 custom-scrollbar">
            {sceneTree.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-32 text-white/30 text-sm">
                <Package className="w-8 h-8 mb-2 opacity-50" />
                No models loaded
              </div>
            ) : (
              <div className="space-y-0.5">
                {sceneTree.map((node) => (
                  <SceneNode
                    key={node.uuid}
                    node={node}
                    selectedObjectUuid={selectedObjectUuid}
                    expandedNodes={expandedNodes}
                    onNodeClick={handleNodeClick}
                    onModelClick={handleModelClick}
                    onToggleVisibility={toggleVisibility}
                    onToggleExpand={toggleNode}
                    onRenameStart={handleRenameStart}
                    onRenameChange={handleRenameChange}
                    onRenameConfirm={handleRenameConfirm}
                    onRenameCancel={handleRenameCancel}
                    onDeleteModel={handleDeleteModel}
                    editingModelId={editingModelId}
                    editingName={editingName}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}

interface SceneNodeProps {
  node: SceneNode;
  selectedObjectUuid: string | null;
  expandedNodes: Record<string, boolean>;
  onNodeClick: (uuid: string, node: SceneNode) => void;
  onModelClick: (modelId: string) => void;
  onToggleVisibility: (e: React.MouseEvent, uuid: string, nodeType: string, modelId?: string) => void;
  onToggleExpand: (uuid: string) => void;
  onRenameStart: (e: React.MouseEvent, modelId: string, currentName: string) => void;
  onRenameChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onRenameConfirm: (modelId: string) => void;
  onRenameCancel: () => void;
  onDeleteModel: (e: React.MouseEvent, modelId: string) => void;
  editingModelId: string | null;
  editingName: string;
}

function SceneNode({
  node,
  selectedObjectUuid,
  expandedNodes,
  onNodeClick,
  onModelClick,
  onToggleVisibility,
  onToggleExpand,
  onRenameStart,
  onRenameChange,
  onRenameConfirm,
  onRenameCancel,
  onDeleteModel,
  editingModelId,
  editingName,
}: SceneNodeProps) {
  const isExpanded = expandedNodes[node.uuid];
  const isSelected = selectedObjectUuid === node.uuid;
  const hasChildren = node.children.length > 0;
  const isModel = node.type === 'Model';
  const isEditing = editingModelId === node.uuid;

  return (
    <div className="select-none">
      <div
        onClick={() => (isModel ? onModelClick(node.uuid) : onNodeClick(node.uuid, node))}
        className={`
          group flex items-center gap-2 px-2 py-1.5 rounded-lg cursor-pointer transition-all
          ${isSelected ? 'bg-violet-600/20 border border-violet-600/50' : 'hover:bg-white/5 border border-transparent'}
        `}
        style={{ marginLeft: `${node.depth * 12}px` }}
      >
        {/* Expand/Collapse Chevron */}
        <div
          className={`w-5 h-5 flex items-center justify-center flex-shrink-0 ${
            hasChildren ? 'text-white/50 hover:text-white cursor-pointer' : ''
          }`}
          onClick={(e) => {
            if (hasChildren) {
              e.stopPropagation();
              onToggleExpand(node.uuid);
            }
          }}
        >
          {hasChildren ? (
            isExpanded ? (
              <ChevronDown className="w-3.5 h-3.5" />
            ) : (
              <ChevronRight className="w-3.5 h-3.5" />
            )
          ) : (
            <div className="w-3.5 h-3.5" />
          )}
        </div>

        {/* Type Icon */}
        <div className="w-5 h-5 flex items-center justify-center flex-shrink-0 text-violet-400">
          {isModel ? <Package className="w-3.5 h-3.5" /> : node.type === 'Material' ? <Sparkles className="w-3.5 h-3.5" /> : <Package className="w-3.5 h-3.5" />}
        </div>

        {/* Name (Editable for models) */}
        <div className="flex-1 min-w-0">
          {isModel && isEditing ? (
            <input
              type="text"
              value={editingName}
              onChange={onRenameChange}
              onBlur={() => onRenameConfirm(node.uuid)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') onRenameConfirm(node.uuid);
                if (e.key === 'Escape') onRenameCancel();
              }}
              onClick={(e) => e.stopPropagation()}
              autoFocus
              className="w-full bg-white/10 text-white text-sm px-2 py-0.5 rounded border border-violet-500/50 outline-none"
            />
          ) : (
            <p
              className={`text-sm truncate ${node.visible ? 'text-white' : 'text-white/40'} ${isSelected ? 'font-medium' : ''}`}
              onDoubleClick={(e) => {
                if (isModel) onRenameStart(e, node.uuid, node.name);
              }}
            >
              {node.name}
            </p>
          )}
        </div>

        {/* Action Icons (Only for models) */}
        {isModel && !isEditing && (
          <div className="flex items-center gap-1">
            <button
              onClick={(e) => onRenameStart(e, node.uuid, node.name)}
              className="p-1 text-white/30 hover:text-white hover:bg-white/10 rounded opacity-0 group-hover:opacity-100 transition-opacity"
              title="Rename"
            >
              <Edit3 className="w-3 h-3" />
            </button>
            <button
              onClick={(e) => onDeleteModel(e, node.uuid)}
              className="p-1 text-rose-400/50 hover:text-rose-400 hover:bg-rose-500/10 rounded opacity-0 group-hover:opacity-100 transition-opacity"
              title="Delete"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        )}

        {/* Visibility Toggle */}
        <div
          onClick={(e) => onToggleVisibility(e, node.uuid, node.type, node.modelId)}
          className={`
            w-7 h-7 flex items-center justify-center flex-shrink-0 cursor-pointer rounded-lg
            ${node.visible
              ? 'bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 hover:text-emerald-300'
              : 'bg-rose-500/20 text-rose-400 hover:bg-rose-500/30 hover:text-rose-300'}
            transition-all duration-200 hover:scale-110
          `}
          title={node.visible ? 'Click to hide' : 'Click to show'}
        >
          <div className={`transform transition-transform duration-300 ${node.visible ? 'scale-100' : 'scale-90'}`}>
            {node.visible ? (
              <Eye className="w-4.5 h-4.5" strokeWidth={2.5} />
            ) : (
              <EyeOff className="w-4.5 h-4.5" strokeWidth={2} />
            )}
          </div>
        </div>
      </div>

      {/* Children */}
      {hasChildren && isExpanded && (
        <div className="space-y-0.5">
          {node.children.map((child) => (
            <SceneNode
              key={child.uuid}
              node={child}
              selectedObjectUuid={selectedObjectUuid}
              expandedNodes={expandedNodes}
              onNodeClick={onNodeClick}
              onModelClick={onModelClick}
              onToggleVisibility={onToggleVisibility}
              onToggleExpand={onToggleExpand}
              onRenameStart={onRenameStart}
              onRenameChange={onRenameChange}
              onRenameConfirm={onRenameConfirm}
              onRenameCancel={onRenameCancel}
              onDeleteModel={onDeleteModel}
              editingModelId={editingModelId}
              editingName={editingName}
            />
          ))}
        </div>
      )}
    </div>
  );
}
