'use client';

import { useState, useEffect } from 'react';
import * as THREE from 'three';
import { useSceneStore } from '@/store/sceneStore';
import { Lightbulb, Plus, Trash2, Move3D } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';

export type LightType = 'ambient' | 'directional' | 'point' | 'spot';

export interface LightData {
  id: string;
  type: LightType;
  name: string;
  intensity: number;
  color: string;
  position: [number, number, number];
  visible: boolean;
  // Point/Spot specific
  distance?: number;
  decay?: number;
  // Directional/Spot specific
  target?: [number, number, number];
  // Spot specific
  angle?: number;
  penumbra?: number;
}

interface LightingPanelProps {
  scene: THREE.Scene | null;
  onAddLight?: (lightData: LightData) => void;
  onRemoveLight?: (lightId: string) => void;
}

const lightPresets: Array<{
  type: LightType;
  name: string;
  icon: React.ElementType;
  description: string;
  defaultColor: string;
  defaultIntensity: number;
}> = [
  {
    type: 'ambient',
    name: 'Ambient',
    icon: Lightbulb,
    description: '环境光 - 均匀照亮整个场景',
    defaultColor: '#ffffff',
    defaultIntensity: 0.5,
  },
  {
    type: 'directional',
    name: 'Directional',
    icon: Lightbulb,
    description: '平行光 - 模拟太阳光',
    defaultColor: '#ffffff',
    defaultIntensity: 1.0,
  },
  {
    type: 'point',
    name: 'Point',
    icon: Lightbulb,
    description: '点光源 - 向四周发光',
    defaultColor: '#ffffff',
    defaultIntensity: 1.0,
  },
  {
    type: 'spot',
    name: 'Spot',
    icon: Lightbulb,
    description: '聚光灯 - 锥形光束',
    defaultColor: '#ffffff',
    defaultIntensity: 1.0,
  },
];

export function LightingPanel({ scene, onAddLight, onRemoveLight }: LightingPanelProps) {
  const { lights, selectedLightId, setSelectedLight, addLight, removeLight, updateLight } = useSceneStore();
  const [localData, setLocalData] = useState<LightData | null>(null);

  // 当选中灯光改变时，更新本地数据
  useEffect(() => {
    const selectedLight = lights.find((l) => l.id === selectedLightId);
    if (selectedLight) {
      setLocalData(selectedLight);
    } else {
      setLocalData(null);
    }
  }, [selectedLightId, lights]);

  // 添加灯光
  const handleAddLight = (type: LightType, color: string, intensity: number) => {
    const lightId = `light_${Date.now()}`;
    const lightData: LightData = {
      id: lightId,
      type,
      name: `${type.charAt(0).toUpperCase() + type.slice(1)} Light`,
      intensity,
      color,
      position: [2, 3, 2],
      visible: true,
      distance: type === 'point' || type === 'spot' ? 10 : undefined,
      decay: type === 'point' || type === 'spot' ? 2 : undefined,
      target: type === 'directional' || type === 'spot' ? [0, 0, 0] : undefined,
      angle: type === 'spot' ? Math.PI / 6 : undefined,
      penumbra: type === 'spot' ? 0 : undefined,
    };

    addLight(lightData);

    // 创建 3D 灯光对象
    if (scene) {
      createLightInScene(lightData, scene);
    }
  };

  // 在场景中创建灯光
  const createLightInScene = (data: LightData, threeScene: THREE.Scene) => {
    let light: THREE.Light | null = null;
    let helper: THREE.Object3D | null = null;

    switch (data.type) {
      case 'ambient':
        light = new THREE.AmbientLight(data.color, data.intensity);
        break;
      case 'directional':
        light = new THREE.DirectionalLight(data.color, data.intensity);
        (light as THREE.DirectionalLight).position.set(...data.position);
        break;
      case 'point':
        light = new THREE.PointLight(data.color, data.intensity, data.distance, data.decay);
        (light as THREE.PointLight).position.set(...data.position);
        break;
      case 'spot':
        light = new THREE.SpotLight(data.color, data.intensity, data.distance, data.angle, data.penumbra, data.decay);
        (light as THREE.SpotLight).position.set(...data.position);
        break;
      default:
        return;
    }

    if (!light) {
      console.error('Failed to create light:', data);
      return;
    }

    light.name = data.id;

    // 添加 Helper 来可视化光源位置
    try {
      if (data.type === 'directional') {
        const dirLight = light as THREE.DirectionalLight;
        helper = new THREE.DirectionalLightHelper(dirLight, 0.5);
        if (helper) helper.name = `${data.id}_helper`;
      } else if (data.type === 'point') {
        const pointLight = light as THREE.PointLight;
        helper = new THREE.PointLightHelper(pointLight, 0.3);
        if (helper) helper.name = `${data.id}_helper`;
      } else if (data.type === 'spot') {
        const spotLight = light as THREE.SpotLight;
        // SpotLight 的 target 是一个独立的 Object3D，需要手动添加到场景
        // 但 spotLight 本身已经有一个 target 对象，我们只需要设置它的位置
        if (spotLight.target) {
          spotLight.target.position.set(0, 0, 0);
        }
        helper = new THREE.SpotLightHelper(spotLight);
        if (helper) helper.name = `${data.id}_helper`;
      } else {
        // Ambient light - 使用简单的 sphere helper
        const sphere = new THREE.Mesh(
          new THREE.SphereGeometry(0.2),
          new THREE.MeshBasicMaterial({ color: data.color })
        );
        sphere.name = `${data.id}_helper`;
        sphere.position.set(...data.position);
        helper = sphere;
      }

      // 验证 helper 是否是有效的 Object3D 实例
      if (helper && !(helper instanceof THREE.Object3D)) {
        console.error('Helper is not a valid Object3D:', helper);
        helper = null;
      }
    } catch (error) {
      console.error('Failed to create light helper:', error);
      helper = null;
    }

    // 添加到场景
    threeScene.add(light);

    if (helper && helper instanceof THREE.Object3D) {
      threeScene.add(helper);
    }

    // 保存引用到 store（需要扩展 SceneLight 接口）
    updateLight(data.id, {
      lightRef: light,
      helperRef: helper,
    } as any);
  };

  // 删除灯光
  const handleRemoveLight = (lightId: string) => {
    const light = lights.find((l) => l.id === lightId);
    if (light && scene) {
      // 从场景中移除
      const lightObj = scene.getObjectByName(lightId);
      const helperObj = scene.getObjectByName(`${lightId}_helper`);

      if (lightObj) {
        scene.remove(lightObj);
      }
      if (helperObj) {
        scene.remove(helperObj);
      }
    }

    removeLight(lightId);

    if (selectedLightId === lightId) {
      setSelectedLight(null);
    }
  };

  // 更新灯光参数
  const handleUpdateLight = (updates: Partial<LightData>) => {
    if (!localData) return;

    const updatedData = { ...localData, ...updates };
    setLocalData(updatedData);
    updateLight(localData.id, updates);

    // 更新 3D 场景中的灯光
    if (scene) {
      const lightObj = scene.getObjectByName(localData.id);
      if (lightObj && lightObj instanceof THREE.Light) {
        if (updates.intensity !== undefined) {
          lightObj.intensity = updates.intensity;
        }
        if (updates.color !== undefined) {
          lightObj.color.set(updates.color);
        }
        if (updates.position !== undefined && lightObj.position) {
          lightObj.position.set(...updates.position);
        }
        if (updates.distance !== undefined && (lightObj instanceof THREE.PointLight || lightObj instanceof THREE.SpotLight)) {
          lightObj.distance = updates.distance;
        }
        if (updates.angle !== undefined && lightObj instanceof THREE.SpotLight) {
          lightObj.angle = updates.angle;
        }

        // 更新 helper（仅当 helper 有 update 方法时）
        const helperObj = scene.getObjectByName(`${localData.id}_helper`);
        if (helperObj && 'update' in helperObj && typeof helperObj.update === 'function') {
          (helperObj as any).update();
        }
      }
    }
  };

  // 处理位置变化
  const handlePositionChange = (axis: 'x' | 'y' | 'z', value: number[]) => {
    if (!localData) return;

    const axisIndex = axis === 'x' ? 0 : axis === 'y' ? 1 : 2;
    const newPosition = [...localData.position] as [number, number, number];
    newPosition[axisIndex] = value[0];

    handleUpdateLight({ position: newPosition });
  };

  return (
    <div className="flex flex-col h-full">
      {/* 添加灯光 */}
      <div className="flex-shrink-0 p-3 border-b border-white/10">
        <h3 className="text-xs font-medium text-white/60 mb-3 uppercase tracking-wider">Add Light</h3>
        <div className="grid grid-cols-2 gap-2">
          {lightPresets.map((preset) => {
            const Icon = preset.icon;
            return (
              <Button
                key={preset.type}
                onClick={() => handleAddLight(preset.type, preset.defaultColor, preset.defaultIntensity)}
                className="flex flex-col items-center gap-1 p-3 h-auto bg-white/5 border border-white/10 hover:bg-violet-500/10 hover:border-violet-500/30 transition-all"
              >
                <Icon className="w-4 h-4 text-violet-400" />
                <span className="text-xs text-white/80">{preset.name}</span>
              </Button>
            );
          })}
        </div>
      </div>

      {/* 灯光列表 */}
      <div className="flex-shrink-0 p-3 border-b border-white/10 max-h-[30%] overflow-y-auto custom-scrollbar">
        <h3 className="text-xs font-medium text-white/60 mb-3 uppercase tracking-wider">Lights in Scene</h3>
        <div className="space-y-1">
          {lights.length === 0 ? (
            <p className="text-xs text-white/30 text-center py-4">No lights added yet</p>
          ) : (
            lights.map((light) => {
              const isSelected = light.id === selectedLightId;
              return (
                <div
                  key={light.id}
                  className={`
                    flex items-center justify-between px-3 py-2 rounded-lg cursor-pointer transition-all
                    ${isSelected
                      ? 'bg-violet-500/20 border border-violet-500/50'
                      : 'bg-white/5 border border-white/10 hover:bg-white/10'
                    }
                  `}
                  onClick={() => setSelectedLight(light.id)}
                >
                  <div className="flex items-center gap-2">
                    <Lightbulb className={`w-3 h-3 ${isSelected ? 'text-violet-300' : 'text-white/50'}`} />
                    <span className="text-xs text-white/80">{light.name}</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleRemoveLight(light.id);
                    }}
                    className="w-6 h-6 text-rose-400/50 hover:text-rose-400 hover:bg-rose-500/10"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* 灯光属性 */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-3">
        {localData ? (
          <div className="space-y-5">
            <h3 className="text-xs font-medium text-white/60 uppercase tracking-wider">
              Light Properties - {localData.name}
            </h3>

            {/* Intensity */}
            <LightSlider
              label="Intensity"
              value={localData.intensity}
              min={0}
              max={3}
              step={0.1}
              onChange={(value) => handleUpdateLight({ intensity: value[0] })}
            />

            {/* Color */}
            <div className="space-y-2">
              <label className="text-xs font-medium text-white/80">Color</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={localData.color}
                  onChange={(e) => handleUpdateLight({ color: e.target.value })}
                  className="w-10 h-10 rounded-lg border border-white/20 cursor-pointer bg-transparent"
                />
                <input
                  type="text"
                  value={localData.color}
                  onChange={(e) => handleUpdateLight({ color: e.target.value })}
                  className="flex-1 h-10 px-3 rounded-lg bg-white/5 border border-white/10 text-white text-sm"
                />
              </div>
            </div>

            {/* Position (非 Ambient 光) */}
            {localData.type !== 'ambient' && (
              <div className="space-y-3">
                <label className="text-xs font-medium text-white/80">Position</label>
                <div className="space-y-2">
                  {['x', 'y', 'z'].map((axis) => (
                    <LightSlider
                      key={axis}
                      label={axis.toUpperCase()}
                      value={localData.position[axis === 'x' ? 0 : axis === 'y' ? 1 : 2]}
                      min={-10}
                      max={10}
                      step={0.1}
                      onChange={(value) => handlePositionChange(axis as 'x' | 'y' | 'z', value)}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Distance (Point/Spot) */}
            {(localData.type === 'point' || localData.type === 'spot') && localData.distance !== undefined && (
              <LightSlider
                label="Distance"
                value={localData.distance}
                min={0}
                max={50}
                step={1}
                onChange={(value) => handleUpdateLight({ distance: value[0] })}
              />
            )}

            {/* Angle (Spot) */}
            {localData.type === 'spot' && localData.angle !== undefined && (
              <LightSlider
                label="Angle"
                value={localData.angle}
                min={0}
                max={Math.PI / 2}
                step={0.1}
                onChange={(value) => handleUpdateLight({ angle: value[0] })}
              />
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-white/30 text-center">
            <Lightbulb className="w-12 h-12 mb-4 opacity-50" />
            <p className="text-sm font-medium mb-2">No Light Selected</p>
            <p className="text-xs opacity-60">Select a light from the list to edit its properties</p>
          </div>
        )}
      </div>
    </div>
  );
}

interface LightSliderProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (value: number[]) => void;
}

function LightSlider({ label, value, min, max, step, onChange }: LightSliderProps) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-xs font-medium text-white/80">{label}</label>
        <span className="text-xs text-white/60 font-mono">{value.toFixed(2)}</span>
      </div>
      <Slider value={[value]} onValueChange={onChange} min={min} max={max} step={step} className="cursor-pointer" />
    </div>
  );
}
