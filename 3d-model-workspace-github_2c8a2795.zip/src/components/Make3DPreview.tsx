'use client';

import { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import { Button } from '@/components/ui/button';
import { X, ArrowLeft, Download, RotateCcw, Loader2, Box, ExternalLink, AlertCircle } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { useRouter } from 'next/navigation';

interface Make3DPreviewProps {
  modelUrl: string;
  onClose: () => void;
  onImport: () => void;
  isImporting?: boolean;
  projectId?: string;
}

export function Make3DPreview({ modelUrl, onClose, onImport, isImporting = false, projectId }: Make3DPreviewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  
  const [isImportingToWorkspace, setIsImportingToWorkspace] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  // Three.js refs
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<any>(null);
  const modelBlobRef = useRef<Blob | null>(null);

  // Initialize Three.js scene
  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    // Create scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a0a);
    sceneRef.current = scene;

    // Create camera
    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    );
    camera.position.set(0, 0, 5);
    cameraRef.current = camera;

    // Create renderer
    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: true,
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    rendererRef.current = renderer;

    // Lighting setup
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xffffff, 1.5);
    mainLight.position.set(5, 5, 5);
    scene.add(mainLight);

    const fillLight = new THREE.DirectionalLight(0xffffff, 0.5);
    fillLight.position.set(-5, 0, -5);
    scene.add(fillLight);

    const rimLight = new THREE.PointLight(0xffffff, 0.3);
    rimLight.position.set(0, -5, 0);
    scene.add(rimLight);

    // Load OrbitControls
    const initControls = async () => {
      try {
        const OrbitControls = (await import('three/examples/jsm/controls/OrbitControls.js')).OrbitControls;
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.enableZoom = true;
        controls.enablePan = true;
        controls.minDistance = 1;
        controls.maxDistance = 20;
        controls.autoRotate = false;
        controls.autoRotateSpeed = 2;
        controlsRef.current = controls;

        animate();
      } catch (error) {
        console.error('Failed to load OrbitControls:', error);
        setError('Failed to initialize controls');
      }
    };

    initControls();

    // Animation loop
    const animate = () => {
      if (!rendererRef.current || !sceneRef.current || !cameraRef.current) return;
      if (controlsRef.current) {
        controlsRef.current.update();
      }
      rendererRef.current.render(sceneRef.current, cameraRef.current);
      requestAnimationFrame(animate);
    };

    // Handle resize
    const handleResize = () => {
      if (!cameraRef.current || !rendererRef.current || !containerRef.current) return;
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;
      cameraRef.current.aspect = width / height;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (rendererRef.current) {
        rendererRef.current.dispose();
      }
    };
  }, []);

  // Load 3D model
  useEffect(() => {
    if (!modelUrl || !sceneRef.current) return;

    setIsLoading(true);
    setError(null);
    setLoadingProgress(0);

    console.log('[Preview] Loading model from:', modelUrl.substring(0, 100) + '...');

    const loadModel = async () => {
      try {
        setLoadingProgress(10);
        
        // 直接从对象存储 URL 加载（支持 CORS）
        console.log('[Preview] Fetching model...');
        
        const response = await fetch(modelUrl);
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        setLoadingProgress(30);
        
        // 获取模型数据
        const arrayBuffer = await response.arrayBuffer();
        const totalBytes = arrayBuffer.byteLength;
        console.log(`[Preview] Model fetched: ${(totalBytes / 1024 / 1024).toFixed(2)} MB`);
        
        setLoadingProgress(50);
        
        if (totalBytes === 0) {
          throw new Error('Model file is empty');
        }

        // 创建 blob 存储
        const blob = new Blob([arrayBuffer], { type: 'model/gltf-binary' });
        modelBlobRef.current = blob;
        
        const blobUrl = URL.createObjectURL(blob);
        
        setLoadingProgress(60);
        
        // Detect model format from URL
        const detectFormat = (url: string): 'gltf' | 'fbx' | 'obj' => {
          const lower = url.toLowerCase();
          if (lower.includes('.glb') || lower.includes('.gltf')) return 'gltf';
          if (lower.includes('.fbx')) return 'fbx';
          return 'gltf'; // default fallback
        };
        
        const format = detectFormat(modelUrl);
        console.log(`[Preview] Detected format: ${format}`);
        
        setLoadingProgress(60);
        
        // Load model using appropriate loader based on format
        let model: THREE.Object3D;
        
        if (format === 'fbx') {
          const { FBXLoader } = await import('three/examples/jsm/loaders/FBXLoader.js');
          const loader = new FBXLoader();
          
          try {
            model = await new Promise<THREE.Object3D>((resolve, reject) => {
              loader.load(
                blobUrl,
                (fbx) => resolve(fbx),
                undefined,
                (err) => reject(err)
              );
            });
            console.log('[Preview] ✅ FBX Model parsed successfully');
          } catch (fbxError) {
            console.warn('[Preview] FBX parse failed, trying GLTF as fallback:', fbxError);
            // Fallback: try GLTF loader in case detection was wrong
            const { GLTFLoader: GLTFLoaderFallback } = await import('three/examples/jsm/loaders/GLTFLoader.js');
            const gltfLoader = new GLTFLoaderFallback();
            const gltf = await new Promise<any>((resolve, reject) => {
              gltfLoader.load(blobUrl, resolve, undefined, reject);
            });
            model = gltf.scene;
            console.log('[Preview] ✅ GLTF fallback parsed successfully');
          }
        } else {
          // Default: GLTFLoader for .glb/.gltf
          const { GLTFLoader } = await import('three/examples/jsm/loaders/GLTFLoader.js');
          const loader = new GLTFLoader();

          model = await new Promise<THREE.Object3D>((resolve, reject) => {
            loader.load(
              blobUrl,
              (gltf) => resolve(gltf.scene),
              undefined,
              (error) => reject(error)
            );
          });
          console.log('[Preview] ✅ GLTF Model parsed successfully');
        }
            
        // 清理 blob URL
        URL.revokeObjectURL(blobUrl);

        const scene = sceneRef.current;
        if (!scene) return;

        // 移除旧模型
        const existingModel = scene.getObjectByName('preview-model');
        if (existingModel) {
          scene.remove(existingModel);
        }

        model.name = 'preview-model';

        // 计算包围盒并居中
        const box = new THREE.Box3().setFromObject(model);
        const center = box.getCenter(new THREE.Vector3());
        const size = box.getSize(new THREE.Vector3());
        
        // 居中模型
        model.position.sub(center);
        
        // 缩放到合适大小
        const maxDim = Math.max(size.x, size.y, size.z);
        const targetSize = 3;
        const scale = targetSize / maxDim;
        model.scale.setScalar(scale);

        // 设置相机位置
        if (cameraRef.current) {
          const distance = targetSize * 2.5;
          cameraRef.current.position.set(0, 0, distance);
          cameraRef.current.lookAt(0, 0, 0);
        }

        // 重置控制器
        if (controlsRef.current) {
          controlsRef.current.reset();
        }

        scene.add(model);
        
        setLoadingProgress(100);
        setIsLoading(false);
        
      } catch (error) {
        console.error('[Preview] Error loading model:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        
        if (errorMessage.includes('403') || errorMessage.includes('401')) {
          setError('Access denied. The model URL may have expired.');
        } else if (errorMessage.includes('Failed to fetch')) {
          setError('Network error. Please check your connection.');
        } else {
          setError(`Failed to load model: ${errorMessage}`);
        }
        setIsLoading(false);
      }
    };

    loadModel();
  }, [modelUrl]);

  // Reset camera view
  const handleResetView = () => {
    if (cameraRef.current && controlsRef.current) {
      cameraRef.current.position.set(0, 0, 5);
      cameraRef.current.lookAt(0, 0, 0);
      controlsRef.current.reset();
    }
  };

  // Download GLB
  const handleDownload = async () => {
    if (!modelBlobRef.current) return;
    
    setIsDownloading(true);
    try {
      const url = URL.createObjectURL(modelBlobRef.current);
      const link = document.createElement('a');
      link.href = url;
      link.download = `ai-model-${Date.now()}.glb`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download failed:', error);
      alert('Download failed. Please try again.');
    } finally {
      setIsDownloading(false);
    }
  };

  // Import to current workspace: download → save locally → load into scene
  const handleImport = async () => {
    if (!modelUrl) return;
    
    setIsImportingToWorkspace(true);
    let modelBlob: Blob | null = null;
    
    try {
      // Step 1: Download model blob from Tripo AI (URL may be temporary/expiring)
      console.log('[Import] Downloading model from:', modelUrl.substring(0, 80) + '...');
      const response = await fetch(modelUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0 (compatible; GlowStudio/1.0)' },
      });
      
      if (!response.ok) {
        throw new Error(`Failed to download model: HTTP ${response.status}`);
      }
      
      modelBlob = await response.blob();
      console.log('[Import] Model downloaded, size:', modelBlob.size, 'bytes');
      
      if (modelBlob.size === 0) {
        throw new Error('Downloaded model is empty');
      }

      // Step 2: Save to local storage via save-local API (persists across page refreshes)
      if (projectId) {
        try {
          const formData = new FormData();
          // Detect format from original URL to use correct extension
          const urlPath = new URL(modelUrl).pathname;
          const extMatch = urlPath.match(/\.(glb|gltf|fbx|obj)(\?|$)/i);
          const detectedExt = extMatch ? extMatch[1].toLowerCase() : 'glb';
          const fileName = `AI_Model_${new Date().toISOString().replace(/[:.]/g, '_')}.${detectedExt}`;
          
          formData.append('file', new File([modelBlob], fileName, { type: 'model/gltf-binary' }));
          
          console.log('[Import] Saving to local storage for project:', projectId);
          const saveResponse = await fetch(`/api/projects/${projectId}/save-local`, {
            method: 'POST',
            body: formData,
          });
          
          if (saveResponse.ok) {
            const saveResult = await saveResponse.json();
            console.log('[Import] ✅ Model saved locally:', saveResult.path);
          } else {
            console.warn('[Import] Local save failed (non-fatal):', saveResponse.status);
            // Continue anyway - model will still be loaded via Blob URL
          }
        } catch (saveError) {
          console.warn('[Import] Local save error (non-fatal):', saveError);
          // Continue - model will still be loaded in-memory
        }
      } else {
        console.warn('[Import] No projectId provided, skipping local save');
      }

      // Step 3: Dispatch MODEL_READY event to load model into current workspace scene
      const objectUrl = URL.createObjectURL(modelBlob);
      // Use detected extension for modelName so loadModel can auto-detect format correctly
      const urlPath = new URL(modelUrl).pathname;
      const extMatch = urlPath.match(/\.(glb|gltf|fbx|obj)(\?|$)/i);
      const importExt = extMatch ? extMatch[1].toLowerCase() : 'glb';
      const modelName = `AI_Model_${new Date().toLocaleDateString().replace(/\//g, '_')}.${importExt}`;
      
      console.log('[Import] Dispatching MODEL_READY event...');
      const event = new CustomEvent('MODEL_READY', {
        detail: {
          modelUrl: objectUrl,
          modelName: modelName,
        },
      });
      window.dispatchEvent(event);
      
      // Step 4: Close preview panel (return to workspace)
      console.log('[Import] Closing preview panel...');
      onClose();
      
    } catch (error) {
      console.error('[Import] Failed:', error);
      alert('Failed to import model: ' + (error instanceof Error ? error.message : 'Unknown error'));
    } finally {
      setIsImportingToWorkspace(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-xl flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-600 to-indigo-600 flex items-center justify-center">
            <Box className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-white">3D Model Preview</h2>
            <p className="text-sm text-gray-400">Generated with AI • Interactive 360° View</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="h-10 w-10 hover:bg-white/10 text-gray-400 hover:text-white rounded-full"
        >
          <X className="w-5 h-5" />
        </Button>
      </div>

      {/* 3D Viewer */}
      <div ref={containerRef} className="flex-1 relative">
        <canvas ref={canvasRef} className="w-full h-full" />

        {/* Loading Overlay */}
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm">
            <div className="text-center">
              <div className="w-16 h-16 border-4 border-violet-600/30 border-t-violet-600 rounded-full animate-spin mb-4 mx-auto" />
              <p className="text-white font-medium mb-2">Loading Model...</p>
              <div className="w-48 h-2 bg-gray-800 rounded-full overflow-hidden mx-auto">
                <div 
                  className="h-full bg-gradient-to-r from-violet-600 to-indigo-600 transition-all duration-300"
                  style={{ width: `${loadingProgress}%` }}
                />
              </div>
              <p className="text-sm text-gray-400 mt-2">{loadingProgress}%</p>
            </div>
          </div>
        )}

        {/* Error State */}
        {error && !isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm">
            <div className="text-center max-w-md p-6">
              <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
              <p className="text-red-400 font-medium mb-2">Failed to Load Model</p>
              <p className="text-gray-400 text-sm mb-4">{error}</p>
              <Button variant="outline" onClick={onClose} className="bg-white/10 border-white/20 text-white">
                Close
              </Button>
            </div>
          </div>
        )}

        {/* Controls Hint */}
        {!isLoading && !error && (
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2">
            <div className="flex items-center gap-4 px-4 py-2 bg-black/50 backdrop-blur-sm rounded-full border border-white/10">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleResetView}
                className="h-8 w-8 p-0 text-gray-400 hover:text-white"
              >
                <RotateCcw className="w-4 h-4" />
              </Button>
              <span className="text-xs text-gray-400">Drag to rotate • Scroll to zoom</span>
            </div>
          </div>
        )}
      </div>

      {/* Footer Actions */}
      <div className="px-6 py-4 border-t border-white/10 bg-black/50">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            {!isLoading && !error && (
              <>
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                <span className="text-sm text-gray-400">Model Ready • GLB Format</span>
              </>
            )}
            {(isLoading || error) && (
              <span className="text-sm text-gray-500">
                {isLoading ? 'Loading...' : 'Error'}
              </span>
            )}
          </div>
          
          <div className="flex gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={onClose}
              disabled={isImportingToWorkspace || isDownloading}
              className="h-10 px-6 bg-white/5 border-white/20 text-gray-300 hover:bg-white/10 hover:text-white"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownload}
              disabled={isDownloading || isLoading || !!error}
              className="h-10 px-6 bg-white/5 border-white/20 text-gray-300 hover:bg-white/10 hover:text-white"
            >
              {isDownloading ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Download className="w-4 h-4 mr-2" />
              )}
              Download
            </Button>
            <Button
              size="sm"
              onClick={handleImport}
              disabled={isImportingToWorkspace || isLoading || !!error}
              className="h-10 px-6 bg-gradient-to-r from-violet-600 to-indigo-600 hover:shadow-lg hover:shadow-violet-500/25"
            >
              {isImportingToWorkspace ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <ExternalLink className="w-4 h-4 mr-2" />
              )}
              Open in Workspace
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
