'use client';

import { useState, useEffect, useCallback } from 'react';
import * as THREE from 'three';
import { useSceneStore } from '@/store/sceneStore';
import {
  Wand2, Loader2, Check
} from 'lucide-react';
import { Slider } from '@/components/ui/slider';

export interface MaterialData {
  color: string; // hex color
  roughness: number;
  metalness: number;
  transparent: number;
}

interface MaterialPanelProps {
  onMaterialChange?: (uuid: string, data: Partial<MaterialData>) => void;
}

// 化妆品材质预设
const cosmeticMaterials: Array<{
  id: string;
  name: string;
  description: string;
  presets: MaterialData;
}> = [
  {
    id: 'matte',
    name: 'Matte',
    description: '哑光粉底质感',
    presets: { color: '#f5e6d3', roughness: 0.8, metalness: 0.0, transparent: 0 },
  },
  {
    id: 'shiny',
    name: 'Shiny',
    description: '亮面口红质感',
    presets: { color: '#e74c3c', roughness: 0.2, metalness: 0.3, transparent: 0 },
  },
  {
    id: 'glossy',
    name: 'Glossy',
    description: '光泽眼影质感',
    presets: { color: '#9b59b6', roughness: 0.3, metalness: 0.2, transparent: 0 },
  },
  {
    id: 'metallic',
    name: 'Metallic',
    description: '金属色化妆品',
    presets: { color: '#f39c12', roughness: 0.4, metalness: 0.9, transparent: 0 },
  },
  {
    id: 'glassy',
    name: 'Glassy',
    description: '玻璃质感',
    presets: { color: '#3498db', roughness: 0.1, metalness: 0.1, transparent: 0.6 },
  },
  {
    id: 'soft',
    name: 'Soft',
    description: '柔肤质感',
    presets: { color: '#ffeaa7', roughness: 0.6, metalness: 0.1, transparent: 0 },
  },
  {
    id: 'creamy',
    name: 'Creamy',
    description: '奶油质感',
    presets: { color: '#fff5e6', roughness: 0.5, metalness: 0.0, transparent: 0 },
  },
  {
    id: 'satin',
    name: 'Satin',
    description: '缎面质感',
    presets: { color: '#ffb6c1', roughness: 0.4, metalness: 0.2, transparent: 0 },
  },
  {
    id: 'pearl',
    name: 'Pearl',
    description: '珍珠质感',
    presets: { color: '#faf0e6', roughness: 0.3, metalness: 0.4, transparent: 0.1 },
  },
  {
    id: 'neon',
    name: 'Neon',
    description: '霓虹光泽',
    presets: { color: '#00ff88', roughness: 0.15, metalness: 0.1, transparent: 0 },
  },
  {
    id: 'holographic',
    name: 'Holo',
    description: '全息质感',
    presets: { color: '#e056fd', roughness: 0.2, metalness: 0.5, transparent: 0.2 },
  },
  {
    id: 'glitter',
    name: 'Glitter',
    description: '闪烁质感',
    presets: { color: '#ffd700', roughness: 0.35, metalness: 0.6, transparent: 0 },
  },
  {
    id: 'velvet',
    name: 'Velvet',
    description: '天鹅绒质感',
    presets: { color: '#4a0e4e', roughness: 0.9, metalness: 0.0, transparent: 0 },
  },
  {
    id: 'frosted',
    name: 'Frosted',
    description: '磨砂玻璃',
    presets: { color: '#a8e6cf', roughness: 0.6, metalness: 0.1, transparent: 0.5 },
  },
  {
    id: 'champagne',
    name: 'Champagne',
    description: '香槟金质感',
    presets: { color: '#f7e7ce', roughness: 0.25, metalness: 0.7, transparent: 0 },
  },
  {
    id: 'rose-gold',
    name: 'Rose Gold',
    description: '玫瑰金质感',
    presets: { color: '#b76e79', roughness: 0.3, metalness: 0.8, transparent: 0 },
  },
  {
    id: 'ceramic',
    name: 'Ceramic',
    description: '陶瓷质感',
    presets: { color: '#ffffff', roughness: 0.1, metalness: 0.0, transparent: 0 },
  },
  {
    id: 'rubber',
    name: 'Rubber',
    description: '橡胶质感',
    presets: { color: '#2c3e50', roughness: 0.95, metalness: 0.0, transparent: 0 },
  },
];

// 根据材质参数生成 CSS 纹理图案
function getMaterialTextureStyle(preset: MaterialData): React.CSSProperties {
  const { color, roughness, metalness, transparent } = preset;
  const baseColor = color;

  // 透明度
  const opacity = 1 - transparent;

  // 基础层：底色
  const layers: string[] = [];

  // 高光/光泽方向（模拟光源）
  if (roughness < 0.5) {
    // 低粗糙度 = 光滑表面，有明确高光
    const highlightOpacity = Math.round((0.6 - roughness) * 0.7 * 100) / 100;
    layers.push(
      `linear-gradient(135deg, rgba(255,255,255,${highlightOpacity}) 0%, transparent 50%, transparent 100%)`
    );
  }

  // 金属感：添加金属色偏移渐变
  if (metalness > 0.4) {
    const metalShift = metalness > 0.7 ? 30 : 15;
    // 解析颜色并创建金属色偏移
    const r = parseInt(baseColor.slice(1, 3), 16);
    const g = parseInt(baseColor.slice(3, 5), 16);
    const b = parseInt(baseColor.slice(5, 7), 16);
    const lightColor = `rgba(${Math.min(255, r + metalShift)},${Math.min(255, g + metalShift)},${Math.min(255, b + metalShift)},${0.3 + metalness * 0.4})`;
    const darkColor = `rgba(${Math.max(0, r - metalShift)},${Math.max(0, g - metalShift * 0.5)},${Math.max(0, b - metalShift)},${0.2 + metalness * 0.3})`;
    layers.push(
      `linear-gradient(${110 + metalness * 40}deg, ${lightColor} 0%, transparent 40%, ${darkColor} 100%)`
    );
  }

  // 高粗糙度：噪点/颗粒纹理
  if (roughness > 0.7) {
    // 使用 repeating-linear-gradient 模拟颗粒
    const grainOpacity = Math.round((roughness - 0.7) * 80) / 100;
    layers.push(
      `repeating-linear-gradient(45deg, transparent 0px, transparent 1px, rgba(0,0,0,${grainOpacity}) 1px, rgba(0,0,0,${grainOpacity}) 2px)`
    );
    layers.push(
      `repeating-linear-gradient(-45deg, transparent 0px, transparent 1px, rgba(255,255,255,${grainOpacity * 0.3}) 1px, rgba(255,255,255,${grainOpacity * 0.3}) 2px)`
    );
  }

  // 中等粗糙度：柔和的缎面/丝绸效果
  if (roughness >= 0.35 && roughness <= 0.65 && metalness < 0.3) {
    layers.push(
      `radial-gradient(ellipse at 30% 20%, rgba(255,255,255,${0.15 + (0.6 - roughness) * 0.3}) 0%, transparent 60%)`
    );
  }

  // Glitter 效果（高金属度 + 中等粗糙度）
  if (metalness > 0.5 && roughness > 0.25 && roughness < 0.5) {
    // 闪烁点阵
    const sparkleColor = 'rgba(255,255,240,0.7)';
    layers.push(
      `radial-gradient(circle at 20% 30%, ${sparkleColor} 0%, transparent 1px), ` +
      `radial-gradient(circle at 70% 20%, ${sparkleColor} 0%, transparent 1.5px), ` +
      `radial-gradient(circle at 40% 70%, ${sparkleColor} 0%, transparent 1px), ` +
      `radial-gradient(circle at 80% 60%, ${sparkleColor} 0%, transparent 1px), ` +
      `radial-gradient(circle at 10% 80%, ${sparkleColor} 0%, transparent 1.2px), ` +
      `radial-gradient(circle at 55% 45%, rgba(255,255,255,0.5) 0%, transparent 2px)`
    );
  }

  // 全息/虹彩效果（特定条件）
  if (metalness > 0.4 && transparent > 0.1) {
    layers.push(
      `linear-gradient(125deg, rgba(255,0,200,0.15) 0%, transparent 25%, rgba(0,200,255,0.12) 50%, rgba(100,255,0,0.1) 75%, transparent 100%)`
    );
  }

  // 霓虹发光（低粗糙度 + 低金属度 + 鲜艳色）
  if (roughness < 0.2 && metalness < 0.2) {
    layers.push(
      `radial-gradient(ellipse at 50% 50%, ${baseColor}88 0%, ${baseColor}44 40%, transparent 70%)`
    );
  }

  // 磨砂玻璃效果（高透明 + 高粗糙度）
  if (transparent > 0.4 && roughness > 0.5) {
    layers.push(
      `radial-gradient(ellipse at 50% 50%, rgba(220,240,230,0.3) 0%, transparent 70%)`
    );
  }

  // 组合所有图层
  return {
    backgroundColor: transparent > 0 ? `${baseColor}${Math.round(opacity * 255).toString(16).padStart(2, '0')}` : baseColor,
    backgroundImage: layers.length > 0 ? layers.join(', ') : undefined,
    opacity: transparent > 0 ? undefined : undefined,
  };
}

export function MaterialPanel({ onMaterialChange }: MaterialPanelProps) {
  const { models, selectedObjectUuid, updateModelProperty } = useSceneStore();
  const [localData, setLocalData] = useState<MaterialData>({
    color: '#ffffff',
    roughness: 0.5,
    metalness: 0.1,
    transparent: 0,
  });

  // AI Material Suggestion State
  interface AISuggestion {
    name: string;
    type: string;
    reason: string;
    presetIndex: number;
  }
  const [aiSuggestions, setAiSuggestions] = useState<AISuggestion[]>([]);
  const [isAILoading, setIsAILoading] = useState(false);
  const [appliedSuggestionIndex, setAppliedSuggestionIndex] = useState<number | null>(null);

  // AI Suggest handler
  const handleAISuggest = useCallback(async () => {
    setIsAILoading(true);
    setAppliedSuggestionIndex(null);
    try {
      const selectedModelData = models.find((m) => m.objectRef?.uuid === selectedObjectUuid);
      const res = await fetch('/api/ai/material-suggest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          modelName: selectedModelData?.name || '',
        }),
      });
      const data = await res.json();
      if (data.success && data.suggestions) {
        setAiSuggestions(data.suggestions);
      }
    } catch (error) {
      console.error('AI suggest failed:', error);
    } finally {
      setIsAILoading(false);
    }
  }, [models, selectedObjectUuid]);

  // Apply AI suggested material
  const handleApplyAISuggestion = (suggestion: AISuggestion, index: number) => {
    const preset = cosmeticMaterials[suggestion.presetIndex];
    if (preset && onMaterialChange && selectedObjectUuid) {
      setLocalData(preset.presets);
      onMaterialChange(selectedObjectUuid, preset.presets);
      setAppliedSuggestionIndex(index);
    }
  };

  // 获取当前选中的模型（匹配 objectRef.uuid、子对象 uuid 或 model.id）
  const selectedModel = models.find((model) => {
    if (!model.objectRef) return false;
    if (model.objectRef.uuid === selectedObjectUuid) return true;
    if (model.id === selectedObjectUuid) return true;
    let found = false;
    model.objectRef.traverse((child) => {
      if (child.uuid === selectedObjectUuid) {
        found = true;
      }
    });
    return found;
  });

  // 当选中模型改变时，读取材质数据
  useEffect(() => {
    if (selectedModel && selectedModel.objectRef) {
      let materialData: MaterialData | null = null;

      // 遍历模型的所有 Mesh，读取第一个材质作为默认值
      selectedModel.objectRef.traverse((child) => {
        if (child instanceof THREE.Mesh && child.material) {
          const mat = child.material as THREE.MeshStandardMaterial;
          if (!materialData) {
            materialData = {
              color: '#' + mat.color.getHexString(),
              roughness: mat.roughness,
              metalness: mat.metalness,
              transparent: mat.transparent ? (1 - mat.opacity) : 0,
            };
          }
        }
      });

      if (materialData) {
        setLocalData(materialData);
      }
    }
  }, [selectedModel]);

  // 应用预设材质
  const applyPreset = (preset: MaterialData) => {
    if (!selectedModel) return;

    setLocalData(preset);

    // 更新模型的所有材质
    if (selectedModel.objectRef) {
      selectedModel.objectRef.traverse((child) => {
        if (child instanceof THREE.Mesh && child.material) {
          const mat = child.material as THREE.MeshStandardMaterial;
          mat.color.set(preset.color);
          mat.roughness = preset.roughness;
          mat.metalness = preset.metalness;
          mat.transparent = preset.transparent > 0;
          mat.opacity = 1 - preset.transparent;
          // 确保环境贴图反射强度
          mat.envMapIntensity = 1.0;
        }
      });
    }

    // 保存到 store
    updateModelProperty(selectedModel.id, 'material', preset);

    // 通知父组件
    if (onMaterialChange) {
      onMaterialChange(selectedObjectUuid!, preset);
    }
  };

  // 处理颜色变化
  const handleColorChange = (color: string) => {
    setLocalData((prev) => ({ ...prev, color }));

    if (!selectedModel || !selectedModel.objectRef) return;

    // 更新模型的所有材质
    selectedModel.objectRef.traverse((child) => {
      if (child instanceof THREE.Mesh && child.material) {
        const mat = child.material as THREE.MeshStandardMaterial;
        mat.color.set(color);
        // 确保环境贴图反射强度
        mat.envMapIntensity = 1.0;
      }
    });

    // 保存到 store
    updateModelProperty(selectedModel.id, 'material', localData);
  };

  // 处理滑动条变化
  const handleSliderChange = (
    property: 'roughness' | 'metalness' | 'transparent',
    value: number[]
  ) => {
    const numValue = value[0];
    setLocalData((prev) => ({ ...prev, [property]: numValue }));

    if (!selectedModel || !selectedModel.objectRef) return;

    // 更新模型的所有材质
    selectedModel.objectRef.traverse((child) => {
      if (child instanceof THREE.Mesh && child.material) {
        const mat = child.material as THREE.MeshStandardMaterial;

        if (property === 'roughness') {
          mat.roughness = numValue;
        } else if (property === 'metalness') {
          mat.metalness = numValue;
        } else if (property === 'transparent') {
          mat.transparent = numValue > 0;
          mat.opacity = 1 - numValue;
        }

        // 确保环境贴图反射强度
        mat.envMapIntensity = 1.0;
      }
    });

    // 保存到 store
    updateModelProperty(selectedModel.id, 'material', { ...localData, [property]: numValue });
  };

  // 如果没有选中模型，显示占位符
  if (!selectedModel) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-white/30 text-center px-6">
        <div className="w-12 h-12 mb-4 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center">
          <div className="w-6 h-6 rounded bg-gradient-to-br from-white/20 to-white/5" />
        </div>
        <p className="text-sm font-medium mb-2">No Model Selected</p>
        <p className="text-xs opacity-60">Select an item from the scene to apply materials</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* AI Suggest */}
      <div className="flex-shrink-0 p-3 border-b border-white/10">
        <button
          onClick={handleAISuggest}
          disabled={isAILoading || !selectedModel}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-violet-500/15 border border-violet-500/25 text-violet-300 text-xs font-medium hover:bg-violet-500/25 hover:border-violet-500/40 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
        >
          {isAILoading ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Wand2 className="w-3.5 h-3.5" />
          )}
          AI Suggest
        </button>

        {/* AI Suggestions */}
        {aiSuggestions.length > 0 && (
          <div className="space-y-1.5 mt-2.5">
            {aiSuggestions.map((suggestion, index) => {
              const preset = cosmeticMaterials[suggestion.presetIndex];
              const isApplied = appliedSuggestionIndex === index;
              return (
                <button
                  key={index}
                  onClick={() => handleApplyAISuggestion(suggestion, index)}
                  className={`w-full flex items-center gap-2.5 p-2 rounded-lg text-left transition-all ${
                    isApplied
                      ? 'bg-emerald-500/15 border border-emerald-500/30'
                      : 'bg-black/20 border border-white/10 hover:bg-violet-500/10 hover:border-violet-500/30'
                  }`}
                >
                  {/* Color preview */}
                  <div
                    className="w-7 h-7 rounded-md flex-shrink-0 border border-white/10"
                    style={{ backgroundColor: preset?.presets.color || '#888' }}
                  />
                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className={`text-xs font-medium ${isApplied ? 'text-emerald-300' : 'text-white'}`}>
                        {suggestion.name}
                      </span>
                      {isApplied && <Check className="w-3 h-3 text-emerald-400" />}
                    </div>
                    <p className="text-[10px] text-gray-500 truncate">{suggestion.reason}</p>
                  </div>
                  {/* Type badge */}
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-white/5 text-gray-400 flex-shrink-0 capitalize">
                    {suggestion.type}
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* 材质预设 - 固定高度并允许滚动 */}
      <div className="flex-shrink-0 h-[42%] min-h-[240px] p-3 border-b border-white/10 overflow-y-auto custom-scrollbar">
        <h3 className="text-xs font-medium text-white/60 mb-3 uppercase tracking-wider">Material Presets</h3>
        <div className="grid grid-cols-3 gap-2.5">
          {cosmeticMaterials.map((preset) => (
            <button
              key={preset.id}
              onClick={() => applyPreset(preset.presets)}
              className="flex flex-col items-center gap-1.5 p-2.5 rounded-xl bg-white/5 border border-white/10 hover:bg-violet-500/10 hover:border-violet-500/30 transition-all group"
              title={preset.description}
            >
              {/* 纹理预览方块 */}
              <div
                className="w-full aspect-square rounded-lg border border-white/10 transition-transform group-hover:scale-[1.03] shadow-sm"
                style={getMaterialTextureStyle(preset.presets)}
              />
              <span className="text-[10px] text-white/80 leading-tight font-medium">{preset.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* 材质参数 - 占用更多空间 */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-6">
        <h3 className="text-xs font-medium text-white/60 uppercase tracking-wider">Material Properties</h3>

        {/* Color */}
        <MaterialProperty
          label="Color"
          value={localData.color}
          onChange={handleColorChange}
        />

        {/* Roughness */}
        <MaterialSlider
          label="Roughness"
          value={localData.roughness}
          min={0}
          max={1}
          step={0.01}
          onChange={(value) => handleSliderChange('roughness', value)}
        />

        {/* Metalness */}
        <MaterialSlider
          label="Metalness"
          value={localData.metalness}
          min={0}
          max={1}
          step={0.01}
          onChange={(value) => handleSliderChange('metalness', value)}
        />

        {/* Transparent */}
        <MaterialSlider
          label="Transparent"
          value={localData.transparent}
          min={0}
          max={1}
          step={0.01}
          onChange={(value) => handleSliderChange('transparent', value)}
        />
      </div>
    </div>
  );
}

interface MaterialPropertyProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
}

function MaterialProperty({ label, value, onChange }: MaterialPropertyProps) {
  return (
    <div className="space-y-2">
      <label className="text-xs font-medium text-white/80">{label}</label>
      <div className="flex items-center gap-2">
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-10 h-10 rounded-lg border border-white/20 cursor-pointer bg-transparent"
        />
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 h-10 px-3 rounded-lg bg-white/5 border border-white/10 text-white text-sm focus:border-violet-500/50 focus:outline-none focus:ring-1 focus:ring-violet-500/30"
          placeholder="#ffffff"
        />
      </div>
    </div>
  );
}

interface MaterialSliderProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (value: number[]) => void;
}

function MaterialSlider({ label, value, min, max, step, onChange }: MaterialSliderProps) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-xs font-medium text-white/80">{label}</label>
        <span className="text-xs text-white/60 font-mono">{value.toFixed(2)}</span>
      </div>
      <Slider
        value={[value]}
        onValueChange={onChange}
        min={min}
        max={max}
        step={step}
        className="cursor-pointer"
      />
    </div>
  );
}
