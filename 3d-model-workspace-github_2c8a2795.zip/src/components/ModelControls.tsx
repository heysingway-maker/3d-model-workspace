'use client';

import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';

export interface LightingSettings {
  ambientIntensity: number;
  ambientColor: string;
  mainLightIntensity: number;
  mainLightColor: string;
  mainLightPosition: [number, number, number];
  fillLightIntensity: number;
}

export interface MaterialSettings {
  color: string;
  metalness: number;
  roughness: number;
  useTexture: boolean;
  textureType?: string;
}

interface ModelControlsProps {
  lightingSettings: LightingSettings;
  materialSettings: MaterialSettings;
  onLightingChange: (settings: LightingSettings) => void;
  onMaterialChange: (settings: MaterialSettings) => void;
}

// Material presets
const materialPresets = [
  { name: 'Bronze', color: '#cd7f32', metalness: 0.9, roughness: 0.3, useTexture: true, textureType: 'bronze', preview: '/assets/bronze_preview.jpg' },
  { name: 'Premium', color: '#8b5cf6', metalness: 0.8, roughness: 0.2, useTexture: false },
  { name: 'Matte', color: '#a78bfa', metalness: 0.3, roughness: 0.7, useTexture: false },
  { name: 'Metallic', color: '#c084fc', metalness: 0.95, roughness: 0.1, useTexture: false },
  { name: 'Glass', color: '#e9d5ff', metalness: 0.1, roughness: 0.05, useTexture: false },
  { name: 'Silk', color: '#d8b4fe', metalness: 0.2, roughness: 0.9, useTexture: false },
];

export function ModelControls({
  lightingSettings,
  materialSettings,
  onLightingChange,
  onMaterialChange,
}: ModelControlsProps) {
  const [activeTab, setActiveTab] = useState('lighting');

  const handlePresetClick = (preset: typeof materialPresets[0]) => {
    onMaterialChange({
      color: preset.color,
      metalness: preset.metalness,
      roughness: preset.roughness,
      useTexture: preset.useTexture || false,
      textureType: preset.textureType,
    });
  };

  return (
    <Card className="absolute top-4 right-4 w-80 max-h-[calc(100vh-2rem)] overflow-hidden border-violet-500/20 bg-black/50 backdrop-blur-xl shadow-2xl shadow-violet-500/5">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-white/5">
          <TabsTrigger
            value="lighting"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-violet-500/20 data-[state=active]:to-indigo-500/20 data-[state=active]:text-violet-300"
          >
            Lighting
          </TabsTrigger>
          <TabsTrigger
            value="material"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-violet-500/20 data-[state=active]:to-indigo-500/20 data-[state=active]:text-violet-300"
          >
            Material
          </TabsTrigger>
        </TabsList>

        <TabsContent value="lighting" className="p-4 space-y-4">
          {/* Ambient Light */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-xs text-violet-200/80">Ambient Intensity</Label>
              <span className="text-xs text-purple-300/60">{lightingSettings.ambientIntensity.toFixed(2)}</span>
            </div>
            <Slider
              value={[lightingSettings.ambientIntensity]}
              onValueChange={([value]) =>
                onLightingChange({ ...lightingSettings, ambientIntensity: value })
              }
              min={0}
              max={2}
              step={0.1}
              className="cursor-pointer"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-xs text-violet-200/80">Ambient Color</Label>
            <div className="flex gap-2">
              <Input
                type="color"
                value={lightingSettings.ambientColor}
                onChange={(e) =>
                  onLightingChange({ ...lightingSettings, ambientColor: e.target.value })
                }
                className="h-8 w-16 p-0 border-0 bg-transparent cursor-pointer"
              />
              <Input
                type="text"
                value={lightingSettings.ambientColor}
                onChange={(e) =>
                  onLightingChange({ ...lightingSettings, ambientColor: e.target.value })
                }
                className="h-8 flex-1 bg-white/5 border-white/10 text-xs text-violet-200"
              />
            </div>
          </div>

          <div className="border-t border-white/10 my-3" />

          {/* Main Light */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-xs text-violet-200/80">Main Light Intensity</Label>
              <span className="text-xs text-purple-300/60">{lightingSettings.mainLightIntensity.toFixed(2)}</span>
            </div>
            <Slider
              value={[lightingSettings.mainLightIntensity]}
              onValueChange={([value]) =>
                onLightingChange({ ...lightingSettings, mainLightIntensity: value })
              }
              min={0}
              max={3}
              step={0.1}
              className="cursor-pointer"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-xs text-violet-200/80">Main Light Color</Label>
            <div className="flex gap-2">
              <Input
                type="color"
                value={lightingSettings.mainLightColor}
                onChange={(e) =>
                  onLightingChange({ ...lightingSettings, mainLightColor: e.target.value })
                }
                className="h-8 w-16 p-0 border-0 bg-transparent cursor-pointer"
              />
              <Input
                type="text"
                value={lightingSettings.mainLightColor}
                onChange={(e) =>
                  onLightingChange({ ...lightingSettings, mainLightColor: e.target.value })
                }
                className="h-8 flex-1 bg-white/5 border-white/10 text-xs text-violet-200"
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-xs text-violet-200/80">Main Light X Position</Label>
              <span className="text-xs text-purple-300/60">{lightingSettings.mainLightPosition[0].toFixed(1)}</span>
            </div>
            <Slider
              value={[lightingSettings.mainLightPosition[0]]}
              onValueChange={([value]) =>
                onLightingChange({
                  ...lightingSettings,
                  mainLightPosition: [value, lightingSettings.mainLightPosition[1], lightingSettings.mainLightPosition[2]]
                })
              }
              min={-10}
              max={10}
              step={0.5}
              className="cursor-pointer"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-xs text-violet-200/80">Main Light Y Position</Label>
              <span className="text-xs text-purple-300/60">{lightingSettings.mainLightPosition[1].toFixed(1)}</span>
            </div>
            <Slider
              value={[lightingSettings.mainLightPosition[1]]}
              onValueChange={([value]) =>
                onLightingChange({
                  ...lightingSettings,
                  mainLightPosition: [lightingSettings.mainLightPosition[0], value, lightingSettings.mainLightPosition[2]]
                })
              }
              min={0}
              max={10}
              step={0.5}
              className="cursor-pointer"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-xs text-violet-200/80">Fill Light Intensity</Label>
              <span className="text-xs text-purple-300/60">{lightingSettings.fillLightIntensity.toFixed(2)}</span>
            </div>
            <Slider
              value={[lightingSettings.fillLightIntensity]}
              onValueChange={([value]) =>
                onLightingChange({ ...lightingSettings, fillLightIntensity: value })
              }
              min={0}
              max={2}
              step={0.1}
              className="cursor-pointer"
            />
          </div>
        </TabsContent>

        <TabsContent value="material" className="p-4 space-y-4">
          {/* Current material status */}
          {materialSettings.useTexture && (
            <div className="flex items-center gap-2 p-2 rounded-lg bg-violet-500/10 border border-violet-500/20">
              <div className="w-2 h-2 rounded-full bg-violet-400 animate-pulse" />
              <span className="text-xs text-violet-300">Using PBR Texture</span>
            </div>
          )}

          {/* Material Color */}
          <div className="space-y-2">
            <Label className="text-xs text-violet-200/80">Material Color</Label>
            <div className="flex gap-2">
              <Input
                type="color"
                value={materialSettings.color}
                onChange={(e) =>
                  onMaterialChange({ ...materialSettings, color: e.target.value, useTexture: false })
                }
                disabled={materialSettings.useTexture}
                className="h-8 w-16 p-0 border-0 bg-transparent cursor-pointer disabled:opacity-50"
              />
              <Input
                type="text"
                value={materialSettings.color}
                onChange={(e) =>
                  onMaterialChange({ ...materialSettings, color: e.target.value, useTexture: false })
                }
                disabled={materialSettings.useTexture}
                className="h-8 flex-1 bg-white/5 border-white/10 text-xs text-violet-200 disabled:opacity-50"
              />
            </div>
          </div>

          {/* Metalness */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-xs text-violet-200/80">Metalness</Label>
              <span className="text-xs text-purple-300/60">{materialSettings.metalness.toFixed(2)}</span>
            </div>
            <Slider
              value={[materialSettings.metalness]}
              onValueChange={([value]) =>
                onMaterialChange({ ...materialSettings, metalness: value, useTexture: false })
              }
              min={0}
              max={1}
              step={0.05}
              disabled={materialSettings.useTexture}
              className="cursor-pointer disabled:opacity-50"
            />
          </div>

          {/* Roughness */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-xs text-violet-200/80">Roughness</Label>
              <span className="text-xs text-purple-300/60">{materialSettings.roughness.toFixed(2)}</span>
            </div>
            <Slider
              value={[materialSettings.roughness]}
              onValueChange={([value]) =>
                onMaterialChange({ ...materialSettings, roughness: value, useTexture: false })
              }
              min={0}
              max={1}
              step={0.05}
              disabled={materialSettings.useTexture}
              className="cursor-pointer disabled:opacity-50"
            />
          </div>

          <div className="border-t border-white/10 my-3" />

          {/* Material Presets */}
          <div className="space-y-2">
            <Label className="text-xs text-violet-200/80">Material Presets</Label>
            <div className="grid grid-cols-2 gap-2">
              {materialPresets.map((preset) => (
                <Button
                  key={preset.name}
                  variant="outline"
                  size="sm"
                  onClick={() => handlePresetClick(preset)}
                  className="h-auto py-2 px-3 bg-transparent border border-white/10 text-xs text-muted-foreground/80 hover:bg-gradient-to-r hover:from-violet-500/10 hover:to-indigo-500/10 hover:border-violet-500/20 transition-all"
                >
                  <div className="flex flex-col items-center gap-1 w-full">
                    {preset.preview ? (
                      <img
                        src={preset.preview}
                        alt={preset.name}
                        className="w-8 h-8 rounded-full object-cover border border-white/20"
                      />
                    ) : (
                      <div
                        className="w-8 h-8 rounded-full border border-white/20"
                        style={{ backgroundColor: preset.color }}
                      />
                    )}
                    <span className="text-[10px] text-muted-foreground/60">{preset.name}</span>
                  </div>
                </Button>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </Card>
  );
}
