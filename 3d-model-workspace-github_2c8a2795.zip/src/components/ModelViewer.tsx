'use client';

import { useRef, useState, useEffect, useCallback } from 'react';
import * as THREE from 'three';
import { DecalGeometry } from 'three/addons/geometries/DecalGeometry.js';
import LayerPanel from '@/components/LayerPanel';
import { useSceneStore, SceneModel } from '@/store/sceneStore';
import { useDecalModeStore } from '@/store/decalModeStore';
import { isEqual } from '@/utils/objectPath';
import { shouldExcludeMesh } from '@/utils/meshFilter';

interface SimpleViewerProps {
  initialUrl?: string; // Initial model URL (optional)
  onError?: () => void;
  onLoad?: () => void;
  projectId?: string;
  onImportModel?: () => void; // 导入模型的回调函数
  onSceneReady?: (scene: THREE.Scene | null) => void; // 场景准备好时的回调
}

export function ModelViewer({ initialUrl, onError, onLoad, projectId, onImportModel, onSceneReady }: SimpleViewerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isClient, setIsClient] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [sceneReady, setSceneReady] = useState(false);

  // 默认材质设置（白色）
  const materialColor = '#ffffff';
  const materialMetalness = 0.1;
  const materialRoughness = 0.5;

  // 存储 Three.js 对象的 ref
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<any>(null);
  const transformControlsRef = useRef<any>(null);
  const ambientLightRef = useRef<THREE.AmbientLight | null>(null);
  const mainLightRef = useRef<THREE.DirectionalLight | null>(null);
  const fillLightRef = useRef<THREE.PointLight | null>(null);
  const selectionBoxRef = useRef<THREE.Group | null>(null);
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster());
  const mouseRef = useRef<THREE.Vector2>(new THREE.Vector2());
  
  // Decal preview refs
  const decalPreviewRef = useRef<THREE.Mesh | null>(null);
  
  // Decal preview state - for local mapping (click mode)
  const decalPreviewDataRef = useRef<{
    position: THREE.Vector3;
    normal: THREE.Vector3;
    mesh: THREE.Mesh;
    modelId: string;
  } | null>(null);
  const isDecalPreviewActiveRef = useRef<boolean>(false);
  
  // Decal drag selection refs
  const decalDragStartRef = useRef<{
    position: THREE.Vector3;
    normal: THREE.Vector3;
    mesh: THREE.Mesh;
    modelId: string;
    screenPos: { x: number; y: number };
  } | null>(null);
  const isDecalDraggingRef = useRef<boolean>(false);
  
  // Track currently highlighted mesh for hover effect
  const highlightedMeshRef = useRef<THREE.Mesh | null>(null);
  
  // Selection outline for visual feedback (more reliable than material highlight)
  const selectionOutlineRef = useRef<THREE.LineSegments | null>(null);
  
  // Track double click for selection
  const lastClickTimeRef = useRef<number>(0);
  const DOUBLE_CLICK_THRESHOLD = 300; // ms

  // Helper to create selection outline around a mesh
  const createSelectionOutline = useCallback((mesh: THREE.Mesh) => {
    // Remove existing outline
    if (selectionOutlineRef.current) {
      if (selectionOutlineRef.current.parent) {
        selectionOutlineRef.current.parent.remove(selectionOutlineRef.current);
      }
      selectionOutlineRef.current.geometry.dispose();
      if ((selectionOutlineRef.current.material as THREE.LineBasicMaterial).dispose) {
        (selectionOutlineRef.current.material as THREE.LineBasicMaterial).dispose();
      }
      selectionOutlineRef.current = null;
    }

    // Create edges geometry from the mesh
    const edges = new THREE.EdgesGeometry(mesh.geometry, 15); // threshold angle
    const lineMaterial = new THREE.LineBasicMaterial({ 
      color: 0x7c3aed, // Purple
      linewidth: 2 
    });
    
    const outline = new THREE.LineSegments(edges, lineMaterial);
    
    // Add as child of the mesh so it follows the mesh's transform automatically
    // Use identity transform since we're adding as child
    outline.position.set(0, 0, 0);
    outline.rotation.set(0, 0, 0);
    outline.scale.setScalar(1.01); // Slightly larger than parent
    
    mesh.add(outline);
    selectionOutlineRef.current = outline;
    
    console.log('Selection outline created for:', mesh.name, 'as child of mesh');
  }, []);

  // Helper to remove selection outline
  const removeSelectionOutline = useCallback(() => {
    if (selectionOutlineRef.current) {
      if (selectionOutlineRef.current.parent) {
        selectionOutlineRef.current.parent.remove(selectionOutlineRef.current);
      }
      selectionOutlineRef.current.geometry.dispose();
      if ((selectionOutlineRef.current.material as THREE.LineBasicMaterial).dispose) {
        (selectionOutlineRef.current.material as THREE.LineBasicMaterial).dispose();
      }
      selectionOutlineRef.current = null;
      console.log('Selection outline removed');
    }
  }, []);

  // Helper function to set mesh highlight (handles different material types)

  // Post processing refs
  const composerRef = useRef<any>(null);
  const bloomPassRef = useRef<any>(null);
  const vignettePassRef = useRef<any>(null);

  // Zustand store
  const {
    models,
    selectedObjectUuid,
    setSelectedObject,
    expandNode,
    addModel,
    updateModel,
    updateModelProperty,
    lights,
    selectedLightId,
    setSelectedLight,
    updateLight,
    environment,
    updateEnvironment,
    postProcessing,
    updatePostProcessing,
  } = useSceneStore();

  const [renderCounter, setRenderCounter] = useState(0);
  const [transformMode, setTransformMode] = useState<'translate' | 'rotate' | 'scale'>('translate');
  const forceSceneUpdate = useCallback(() => {
    console.log('forceSceneUpdate called');
    setRenderCounter((prev) => {
      const newValue = prev + 1;
      console.log('Render counter updated to:', newValue);
      return newValue;
    });

    if (rendererRef.current && sceneRef.current && cameraRef.current) {
      console.log('Immediately rendering scene');
      rendererRef.current.render(sceneRef.current, cameraRef.current);
    }
  }, []);

  useEffect(() => {
    setIsClient(true);
  }, []);

  // Subscribe to decal mode store for preview updates
  const decalStoreSize = useDecalModeStore((state) => state.decalSize);
  const decalStoreIsDecalMode = useDecalModeStore((state) => state.isDecalMode);
  const decalStoreSelectionType = useDecalModeStore((state) => state.selectionType);

  // Clear all highlights when exiting decal mode
  useEffect(() => {
    if (!decalStoreIsDecalMode && sceneRef.current) {
      // Clear all emissive highlights from meshes when exiting decal mode
      sceneRef.current.traverse((child) => {
        if (child instanceof THREE.Mesh && child.userData.isDecal === undefined) {
          // Only clear highlights on model meshes, not decals
          const material = child.material as THREE.MeshStandardMaterial;
          if (material?.emissive && material.emissiveIntensity > 0) {
            // Check if this is a highlight we set (purple color)
            if (material.emissive.getHex() === 0x7c3aed) {
              material.emissive.setHex(0x000000);
              material.emissiveIntensity = 0;
            }
          }
        }
      });
      
      // Clear decal preview
      if (decalPreviewRef.current) {
        decalPreviewRef.current.parent?.remove(decalPreviewRef.current);
        decalPreviewRef.current.geometry?.dispose();
        if (decalPreviewRef.current.material instanceof THREE.Material) {
          decalPreviewRef.current.material.dispose();
        }
        decalPreviewRef.current = null;
      }
      decalPreviewDataRef.current = null;
      isDecalPreviewActiveRef.current = false;
      
      // Reset all decal mode related refs
      highlightedMeshRef.current = null;
      isDecalDraggingRef.current = false;
      decalDragStartRef.current = null;
      
      // Force render
      if (rendererRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
      
      console.log('Cleared all decal mode highlights and state');
    }
  }, [decalStoreIsDecalMode]);

  // 键盘快捷键：切换 Transform 模式 + 撤销贴花
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Transform mode shortcuts
      if (e.key.toLowerCase() === 'w') {
        setTransformMode('translate');
      } else if (e.key.toLowerCase() === 'e') {
        setTransformMode('rotate');
      } else if (e.key.toLowerCase() === 'r') {
        setTransformMode('scale');
      }

      // CTRL+Z - Undo decal
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z' && !e.shiftKey) {
        const decalState = useDecalModeStore.getState();
        if (decalState.canUndo()) {
          e.preventDefault();
          const historyEntry = decalState.undo();
          if (historyEntry && sceneRef.current) {
            // Remove decal meshes from scene
            historyEntry.decalMeshNames.forEach((meshName) => {
              const mesh = sceneRef.current?.getObjectByName(meshName);
              if (mesh) {
                sceneRef.current?.remove(mesh);
                if (mesh instanceof THREE.Mesh) {
                  mesh.geometry.dispose();
                  (mesh.material as THREE.Material).dispose();
                }
                console.log('Undo: removed decal mesh:', meshName);
              }
            });

            // Force render
            if (rendererRef.current && cameraRef.current) {
              rendererRef.current.render(sceneRef.current, cameraRef.current);
            }
          }
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // 监听 models 变化，同步 3D 场景（用于 Undo/Redo）
  useEffect(() => {
    if (!isClient || !sceneRef.current) return;

    console.log('🔄 Models changed, syncing 3D scene:', models.length, 'models');
    models.forEach((model) => {
      console.log(`  - Model: ${model.name} (ID: ${model.id}), visible: ${model.visible}`);
      if (model.objectRef) {
        console.log(`    - objectRef.visible before: ${model.objectRef.visible}`);
        // 更新位置
        model.objectRef.position.set(model.position[0], model.position[1], model.position[2]);
        // 更新旋转（转换为弧度）
        model.objectRef.rotation.set(
          THREE.MathUtils.degToRad(model.rotation[0]),
          THREE.MathUtils.degToRad(model.rotation[1]),
          THREE.MathUtils.degToRad(model.rotation[2])
        );
        // 更新缩放
        model.objectRef.scale.set(model.scale[0], model.scale[1], model.scale[2]);
        // 更新可见性
        model.objectRef.visible = model.visible;
        console.log(`    - objectRef.visible after: ${model.objectRef.visible}`);
      }
    });

    forceSceneUpdate();
  }, [models, isClient, forceSceneUpdate]);

  // 监听环境设置变化，应用到场景
  useEffect(() => {
    if (!isClient || !sceneRef.current || !rendererRef.current) return;

    const scene = sceneRef.current;
    const renderer = rendererRef.current;

    // 应用环境强度（通过调整渲染器的环境映射强度）
    // 使用 exposure 来控制整体亮度，同时保留高动态范围
    renderer.toneMappingExposure = environment.environmentIntensity;

    // 根据环境预设调整光照系统
    if (mainLightRef.current) {
      // 主光源强度和颜色根据环境预设调整
      const intensityMultiplier = environment.environmentIntensity;
      mainLightRef.current.intensity = 2.0 * intensityMultiplier;
      if (environment.lightColor) {
        mainLightRef.current.color.set(environment.lightColor);
      }
    }

    if (ambientLightRef.current) {
      // 环境光强度和颜色根据环境预设调整
      const intensityMultiplier = environment.environmentIntensity;
      ambientLightRef.current.intensity = 0.8 * intensityMultiplier;
      if (environment.ambientColor) {
        ambientLightRef.current.color.set(environment.ambientColor);
      }
    }

    if (fillLightRef.current) {
      // 补光强度
      const intensityMultiplier = environment.environmentIntensity;
      fillLightRef.current.intensity = 1.0 * intensityMultiplier;
    }

    // 更新背光强度
    scene.traverse((child) => {
      if (child instanceof THREE.SpotLight && child.position.z < -5) {
        const intensityMultiplier = environment.environmentIntensity;
        child.intensity = 2.0 * intensityMultiplier;
      }
    });

    console.log('🌍 Environment lighting applied:', {
      preset: environment.preset,
      intensity: environment.environmentIntensity,
      lightColor: environment.lightColor,
      ambientColor: environment.ambientColor,
    });

    forceSceneUpdate();
  }, [environment.environmentIntensity, environment.lightColor, environment.ambientColor, isClient, forceSceneUpdate]);

  // 监听背景显示设置变化
  useEffect(() => {
    if (!isClient || !sceneRef.current) return;

    const scene = sceneRef.current;

    // 如果有环境贴图，根据 showEnvironmentBackground 决定背景
    if (scene.environment && environment.preset !== 'none') {
      if (environment.showEnvironmentBackground) {
        scene.background = scene.environment;
        console.log('✅ HDRI background visible');
      } else {
        scene.background = new THREE.Color(environment.backgroundColor);
        console.log('✅ HDRI lighting applied, background hidden');
      }
    } else {
      // 没有环境贴图时，使用纯色背景
      scene.background = new THREE.Color(environment.backgroundColor);
    }

    forceSceneUpdate();
  }, [environment.showEnvironmentBackground, environment.backgroundColor, environment.preset, isClient, forceSceneUpdate]);

  // 加载 HDRI 环境贴图（只在 hdriUrl 变化时加载）
  useEffect(() => {
    if (!isClient || !sceneRef.current || !rendererRef.current) return;

    const scene = sceneRef.current;

    if (environment.hdriUrl && environment.preset !== 'none') {
      console.log('🖼️ Loading HDRI:', environment.hdriUrl);

      import('three/examples/jsm/loaders/RGBELoader.js').then(({ RGBELoader }) => {
        const loader = new RGBELoader();

        loader.load(environment.hdriUrl!, (texture) => {
          // 使用 equirctangular reflection mapping
          texture.mapping = THREE.EquirectangularReflectionMapping;

          // 始终设置环境贴图（光照效果和材质反射）
          scene.environment = texture;

          // 根据 showEnvironmentBackground 决定是否显示HDRI背景
          if (environment.showEnvironmentBackground) {
            scene.background = texture;
            console.log('✅ HDRI background visible');
          } else {
            scene.background = new THREE.Color(environment.backgroundColor);
            console.log('✅ HDRI lighting applied, background hidden');
          }

          // 更新所有材质的环境贴图和反射强度
          scene.traverse((child) => {
            if (child instanceof THREE.Mesh && child.material) {
              // 设置环境贴图
              child.material.envMap = texture;
              // 增强环境贴图反射强度（1.0 = 原始，可以调整）
              child.material.envMapIntensity = 1.0;
              child.material.needsUpdate = true;
            }
          });

          console.log('✅ HDRI loaded and applied with envMap:', texture);
        }, undefined, (error) => {
          console.error('❌ Failed to load HDRI:', error);
        });
      });
    } else {
      // 清除环境贴图
      scene.environment = null;
      scene.background = new THREE.Color(environment.backgroundColor);

      // 清除所有材质的环境贴图
      scene.traverse((child) => {
        if (child instanceof THREE.Mesh && child.material) {
          child.material.envMap = null;
          child.material.needsUpdate = true;
        }
      });

      console.log('🗑️ Environment cleared');
    }
  }, [environment.hdriUrl, environment.preset, environment.showEnvironmentBackground, environment.backgroundColor, isClient, forceSceneUpdate]);

  // 监听后处理设置变化，更新后处理效果
  useEffect(() => {
    if (!composerRef.current) return;

    const composer = composerRef.current;

    // 如果后处理未启用，禁用所有 pass
    if (!postProcessing.enabled) {
      if (bloomPassRef.current) {
        bloomPassRef.current.enabled = false;
      }
      if (vignettePassRef.current) {
        vignettePassRef.current.enabled = false;
      }
    } else {
      // 如果后处理启用，根据设置启用各个 pass
      if (bloomPassRef.current) {
        bloomPassRef.current.enabled = postProcessing.bloom.enabled;
        if (postProcessing.bloom.enabled) {
          // 应用增强因子
          bloomPassRef.current.strength = postProcessing.bloom.intensity * 1.5;
          bloomPassRef.current.radius = postProcessing.bloom.radius * 0.85;
          bloomPassRef.current.threshold = postProcessing.bloom.threshold;
        }
      }
      if (vignettePassRef.current) {
        vignettePassRef.current.enabled = postProcessing.vignette.enabled;
        if (postProcessing.vignette.enabled) {
          vignettePassRef.current.uniforms.darkness.value = postProcessing.vignette.darkness;
          vignettePassRef.current.uniforms.offset.value = postProcessing.vignette.offset;
        }
      }
    }

    console.log('🎨 Post processing applied:', postProcessing);
    forceSceneUpdate();
  }, [postProcessing, isClient, forceSceneUpdate]);

  useEffect(() => {
    if (!isClient || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const scene = new THREE.Scene();
    // 设置初始背景颜色
    scene.background = new THREE.Color(environment.backgroundColor);
    const camera = new THREE.PerspectiveCamera(50, canvas.clientWidth / canvas.clientHeight, 0.1, 1000);
    camera.position.set(3, 2, 3);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(canvas.clientWidth, canvas.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    // 使用 ACES Filmic 色调映射，电影级效果
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    // 稍微提高曝光以增强 Bloom 效果
    renderer.toneMappingExposure = environment.environmentIntensity * 1.2;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.shadowMap.autoUpdate = true;
    renderer.setClearColor(environment.backgroundColor);
    rendererRef.current = renderer;
    sceneRef.current = scene;
    // Update window scene reference
    (window as any).__modelViewerScene = scene;
    console.log('ModelViewer initialized, __modelViewerScene set');

    // 初始化后处理系统
    import('three/examples/jsm/postprocessing/EffectComposer.js').then(({ EffectComposer }) => {
      import('three/examples/jsm/postprocessing/RenderPass.js').then(({ RenderPass }) => {
        import('three/examples/jsm/postprocessing/UnrealBloomPass.js').then(({ UnrealBloomPass }) => {
          import('three/examples/jsm/shaders/LuminosityHighPassShader.js').then(() => {
            import('three/examples/jsm/shaders/CopyShader.js').then(() => {
              import('three/examples/jsm/postprocessing/ShaderPass.js').then(({ ShaderPass }) => {
                // 创建 EffectComposer
                const composer = new EffectComposer(renderer);
                composer.setSize(canvas.clientWidth, canvas.clientHeight);

                // 创建 RenderPass
                const renderPass = new RenderPass(scene, camera);
                composer.addPass(renderPass);

                // 创建 UnrealBloomPass（增强版）
                const bloomPass = new UnrealBloomPass(
                  new THREE.Vector2(canvas.clientWidth, canvas.clientHeight),
                  postProcessing.bloom.intensity * 1.5, // 增加强度
                  postProcessing.bloom.radius * 0.85, // 调整半径
                  postProcessing.bloom.threshold
                );
                bloomPass.enabled = postProcessing.bloom.enabled;
                composer.addPass(bloomPass);
                bloomPassRef.current = bloomPass;

                // 创建 Vignette Shader（增强版）
                const vignetteShader = {
                  uniforms: {
                    tDiffuse: { value: null },
                    darkness: { value: postProcessing.vignette.darkness },
                    offset: { value: postProcessing.vignette.offset },
                  },
                  vertexShader: `
                    varying vec2 vUv;
                    void main() {
                      vUv = uv;
                      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
                    }
                  `,
                  fragmentShader: `
                    uniform sampler2D tDiffuse;
                    uniform float darkness;
                    uniform float offset;
                    varying vec2 vUv;
                    void main() {
                      vec4 color = texture2D(tDiffuse, vUv);
                      vec2 center = vec2(0.5, 0.5);
                      float dist = distance(vUv, center);
                      // 增强的暗角计算，使用指数函数增强效果
                      float vignette = smoothstep(offset, 1.4, dist * 2.0);
                      // 使用更强的暗度公式
                      color.rgb *= pow((1.0 - vignette * darkness * 0.8), 0.9);
                      // 保持 alpha 不变
                      gl_FragColor = color;
                    }
                  `,
                };

                const vignettePass = new ShaderPass(vignetteShader);
                vignettePass.enabled = postProcessing.vignette.enabled;
                composer.addPass(vignettePass);
                vignettePassRef.current = vignettePass;

                composerRef.current = composer;
                console.log('Post processing initialized');
              }).catch(err => {
                console.warn('Failed to load ShaderPass:', err);
              });
            }).catch(err => {
              console.warn('Failed to load CopyShader:', err);
            });
          }).catch(err => {
            console.warn('Failed to load LuminosityHighPassShader:', err);
          });
        }).catch(err => {
          console.warn('Failed to load UnrealBloomPass:', err);
        });
      }).catch(err => {
        console.warn('Failed to load RenderPass:', err);
      });
    }).catch(err => {
      console.warn('Failed to load EffectComposer:', err);
    });

    // 动态导入 OrbitControls
    import('three/examples/jsm/controls/OrbitControls.js').then(({ OrbitControls }) => {
      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;
      controls.dampingFactor = 0.05;
      controls.enablePan = true;
      controls.enableZoom = true;
      controls.enableRotate = true;
      controls.minDistance = 1;
      controls.maxDistance = 20;
      controls.autoRotate = false;
      controlsRef.current = controls;
    }).catch(err => {
      console.warn('Failed to load OrbitControls:', err);
    });

    // 动态导入 TransformControls
    import('three/examples/jsm/controls/TransformControls.js').then(({ TransformControls }) => {
      if (!TransformControls) {
        console.warn('TransformControls not available');
        return;
      }
      
      const transformControls = new TransformControls(camera, renderer.domElement);
      
      // 验证 transformControls 是否是有效的 Object3D 实例
      if (!transformControls || !(transformControls instanceof THREE.Object3D)) {
        console.warn('TransformControls is not a valid Object3D instance:', typeof transformControls, transformControls);
        return;
      }
      
      if (typeof transformControls.addEventListener !== 'function') {
        console.warn('TransformControls missing addEventListener method');
        return;
      }
      
      transformControls.addEventListener('dragging-changed', function (event) {
        // 当拖动时禁用 OrbitControls
        if (controlsRef.current) {
          controlsRef.current.enabled = !event.value;
        }
      });

      // 拖动开始时记录状态（用于 Undo）
      transformControls.addEventListener('mouseDown', function (event) {
        if (transformControls.object) {
          const object = transformControls.object;
          const beforeState = {
            position: [object.position.x, object.position.y, object.position.z] as [number, number, number],
            rotation: [object.rotation.x, object.rotation.y, object.rotation.z] as [number, number, number],
            scale: [object.scale.x, object.scale.y, object.scale.z] as [number, number, number],
          };
          (transformControls as any).beforeState = beforeState;
          (transformControls as any).targetId = selectedObjectUuid || selectedLightId;
          (transformControls as any).targetType = selectedObjectUuid ? 'model' : 'light';
        }
      });

      // 拖动结束时提交变化（用于 Undo/Redo）
      transformControls.addEventListener('mouseUp', function (event) {
        if (transformControls.object) {
          const object = transformControls.object;
          const afterState = {
            position: [object.position.x, object.position.y, object.position.z] as [number, number, number],
            rotation: [object.rotation.x, object.rotation.y, object.rotation.z] as [number, number, number],
            scale: [object.scale.x, object.scale.y, object.scale.z] as [number, number, number],
          };
          const beforeState = (transformControls as any).beforeState;
          const targetId = (transformControls as any).targetId;
          const targetType = (transformControls as any).targetType;

          // 提交到历史记录
          if (beforeState && targetId) {
            if (targetType === 'model' && selectedObjectUuid) {
              // 模型对象的更新
              // 提交位置变化
              if (!isEqual(beforeState.position, afterState.position)) {
                updateModelProperty(selectedObjectUuid, 'position', afterState.position);
              }
              // 提交旋转变化（转换为度数）
              if (!isEqual(beforeState.rotation, afterState.rotation)) {
                updateModelProperty(selectedObjectUuid, 'rotation', [
                  THREE.MathUtils.radToDeg(afterState.rotation[0]),
                  THREE.MathUtils.radToDeg(afterState.rotation[1]),
                  THREE.MathUtils.radToDeg(afterState.rotation[2]),
                ]);
              }
              // 提交缩放变化
              if (!isEqual(beforeState.scale, afterState.scale)) {
                updateModelProperty(selectedObjectUuid, 'scale', afterState.scale);
              }
            } else if (targetType === 'light' && selectedLightId) {
              // 灯光对象的更新
              if (!isEqual(beforeState.position, afterState.position)) {
                updateLight(selectedLightId, { position: afterState.position });
              }
            }
          }
        }
      });

      // 拖动过程中实时更新状态（跳过历史记录）
      transformControls.addEventListener('change', function () {
        if (transformControls.object) {
          const object = transformControls.object;
          const targetId = (transformControls as any).targetId;
          const targetType = (transformControls as any).targetType;

          if (targetType === 'model' && selectedObjectUuid) {
            // 更新位置状态（跳过历史记录）
            updateModelProperty(selectedObjectUuid, 'position', [
              object.position.x,
              object.position.y,
              object.position.z,
            ], true);
          } else if (targetType === 'light' && selectedLightId) {
            // 更新灯光位置（跳过历史记录）
            updateLight(selectedLightId, {
              position: [object.position.x, object.position.y, object.position.z] as [number, number, number],
            });
          }
        }
      });

      transformControlsRef.current = transformControls;
      
      // 安全添加到场景（TransformControls 继承自 Object3D）
      try {
        scene.add(transformControls as unknown as THREE.Object3D);
      } catch (err) {
        console.warn('Failed to add TransformControls to scene:', err);
        return;
      }
    }).catch(err => {
      console.warn('Failed to load TransformControls:', err);
    });

    // 添加环境光
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    ambientLightRef.current = ambientLight;
    scene.add(ambientLight);

    // 添加主光源（DirectionalLight 用于产生阴影）
    const mainLight = new THREE.DirectionalLight(0xffffff, 2.0);
    mainLight.position.set(5, 10, 7);
    mainLight.castShadow = true;
    mainLight.shadow.mapSize.width = 2048;
    mainLight.shadow.mapSize.height = 2048;
    mainLight.shadow.camera.near = 0.5;
    mainLight.shadow.camera.far = 50;
    mainLight.shadow.camera.left = -10;
    mainLight.shadow.camera.right = 10;
    mainLight.shadow.camera.top = 10;
    mainLight.shadow.camera.bottom = -10;
    mainLight.shadow.bias = -0.0001;
    mainLight.shadow.radius = 2;
    mainLightRef.current = mainLight;
    scene.add(mainLight);

    // 添加补光（PointLight）
    const fillLight = new THREE.PointLight(0xffffff, 1.0, 50);
    fillLight.position.set(-5, 3, -5);
    fillLightRef.current = fillLight;
    scene.add(fillLight);

    // 添加背光（Rim Light）
    const rimLight = new THREE.SpotLight(0xffffff, 2.0);
    rimLight.position.set(0, 5, -10);
    rimLight.angle = Math.PI / 6;
    rimLight.penumbra = 0.5;
    scene.add(rimLight);

    // 添加地面
    const floorGeometry = new THREE.PlaneGeometry(20, 20);
    const floorMaterial = new THREE.MeshStandardMaterial({
      color: 0x1a1a2e,
      transparent: true,
      opacity: 0.8,
      roughness: 0.8,
      metalness: 0.2,
    });
    const floor = new THREE.Mesh(floorGeometry, floorMaterial);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -2;
    floor.receiveShadow = true;
    floor.name = 'Floor';
    scene.add(floor);
    console.log('Floor created, UUID:', floor.uuid);

    // 动画循环
    let animationId: number;
    const animate = () => {
      animationId = requestAnimationFrame(animate);
      // Update scene reference for external access
      (window as any).__modelViewerScene = sceneRef.current;
      if (controlsRef.current) {
        controlsRef.current.update();
      }
      // 使用 composer 而不是直接 renderer.render
      if (composerRef.current) {
        composerRef.current.render();
      } else {
        renderer.render(scene, camera);
      }
    };
    animate();

    // 处理窗口大小变化
    const handleResize = () => {
      const width = canvas.clientWidth;
      const height = canvas.clientHeight;

      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);

      // 更新 composer 大小
      if (composerRef.current) {
        composerRef.current.setSize(width, height);
      }
    };

    window.addEventListener('resize', handleResize);

    setSceneReady(true);

    // 通知父组件场景已准备好
    if (onSceneReady) {
      onSceneReady(scene);
    }

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationId);
      if (controlsRef.current) {
        controlsRef.current.dispose();
      }
      renderer.dispose();
      floorGeometry.dispose();
      floorMaterial.dispose();
      ambientLightRef.current = null;
      mainLightRef.current = null;
      fillLightRef.current = null;
    };
  }, [isClient]);

  // 加载单个模型
  // Detect model format from URL or filename
  const detectModelFormat = (url: string): 'gltf' | 'fbx' | 'obj' | 'unknown' => {
    const lowerUrl = url.toLowerCase();
    if (lowerUrl.includes('.glb') || lowerUrl.includes('.gltf')) return 'gltf';
    if (lowerUrl.includes('.fbx')) return 'fbx';
    if (lowerUrl.includes('.obj')) return 'obj';
    return 'unknown';
  };

  const loadModel = async (url: string, name: string, position: [number, number, number] = [0, 0, 0], preserveMaterials: boolean = false): Promise<void> => {
    if (!sceneRef.current || !rendererRef.current) return;

    try {
      const format = detectModelFormat(url);
      console.log(`[loadModel] Loading model: ${name}, format: ${format}, url: ${url.substring(0, 80)}...`);

      let model: THREE.Object3D;

      if (format === 'fbx') {
        // Use FBXLoader for .fbx files
        const { FBXLoader } = await import('three/examples/jsm/loaders/FBXLoader.js');
        const loader = new FBXLoader();

        model = await new Promise<THREE.Object3D>((resolve, reject) => {
          loader.load(
            url,
            (fbx) => resolve(fbx),
            undefined,
            (error) => reject(error)
          );
        });
      } else if (format === 'obj') {
        // Use OBJLoader for .obj files
        const { OBJLoader } = await import('three/examples/jsm/loaders/OBJLoader.js');
        const loader = new OBJLoader();

        model = await new Promise<THREE.Object3D>((resolve, reject) => {
          loader.load(
            url,
            (obj) => resolve(obj),
            undefined,
            (error) => reject(error)
          );
        });
      } else {
        // Default: use GLTFLoader for .glb/.gltf (and unknown formats - try GLTF first)
        const { GLTFLoader } = await import('three/examples/jsm/loaders/GLTFLoader.js');
        const loader = new GLTFLoader();

        const gltf = await new Promise<any>((resolve, reject) => {
          loader.load(
            url,
            (gltf) => resolve(gltf),
            undefined,
            (error) => reject(error)
          );
        });
        model = gltf.scene;
      }

      // === Common post-processing for all formats ===
      const modelId = crypto.randomUUID();

      // 给模型命名
      model.name = name || `Model_${modelId.slice(-4)}`;
      model.position.set(position[0], position[1], position[2]);

      // 自动调整模型大小
      const box = new THREE.Box3().setFromObject(model);
      const size = box.getSize(new THREE.Vector3());
      const center = box.getCenter(new THREE.Vector3());
      const maxDim = Math.max(size.x, size.y, size.z);
      const scale = 2 / maxDim;
      model.scale.set(scale, scale, scale);
      model.position.sub(center.multiplyScalar(scale));
      model.position.set(position[0], position[1], position[2]);

      // 应用材质（根据 preserveMaterials 参数决定）
      model.traverse((child) => {
        if (!child.name || child.name.trim() === '') {
          child.name = child.type + '_' + child.uuid.slice(-4);
        }

        if (child instanceof THREE.Mesh && child.material) {
          // 如果需要保留原始材质，则不修改
          if (!preserveMaterials) {
            const newMaterial = new THREE.MeshPhysicalMaterial({
              color: new THREE.Color(materialColor),
              metalness: materialMetalness,
              roughness: materialRoughness,
              clearcoat: 0.1,
              clearcoatRoughness: 0.1,
              sheen: 0,
              sheenRoughness: 0.5,
              reflectivity: 0.5,
            });
            newMaterial.name = 'Material_' + child.name;

            if (Array.isArray(child.material)) {
              child.material = child.material.map(() => newMaterial.clone());
            } else {
              child.material = newMaterial;
            }
          } else {
            // 保留原始材质，但确保材质名称
            if (Array.isArray(child.material)) {
              child.material.forEach((mat: any, idx: number) => {
                mat.name = mat.name || `Material_${child.name}_${idx}`;
              });
            } else {
              (child.material as any).name = (child.material as any).name || `Material_${child.name}`;
            }
          }

          // 启用阴影
          child.castShadow = true;
          child.receiveShadow = true;
        }
      });

      // 添加到场景
      sceneRef.current?.add(model);

      // 添加到 store
      const sceneModel: SceneModel = {
        id: modelId,
        name: model.name,
        url,
        visible: true,
        position: [position[0], position[1], position[2]] as [number, number, number],
        rotation: [0, 0, 0] as [number, number, number],
        scale: [model.scale.x, model.scale.y, model.scale.z] as [number, number, number],
        material: {
          color: materialColor,
          roughness: materialRoughness,
          metalness: materialMetalness,
          transparent: 0,
        },
        objectRef: model as unknown as THREE.Group,
      };
      addModel(sceneModel);

      console.log(`[loadModel] ✅ Model loaded (${format}):`, sceneModel.name, '| meshes:', model.children?.length || '?');
    } catch (error) {
      console.error('[loadModel] ❌ Failed:', error);
      throw error;
    }
  };

  // Load model from File object
  const loadModelFromFile = async (file: File, name?: string, preserveMaterials: boolean = false): Promise<void> => {
    const url = URL.createObjectURL(file);
    await loadModel(url, name || file.name, [0, 0, 0], preserveMaterials);
    URL.revokeObjectURL(url);
  };

  // Export scene to GLB file
  const exportSceneToGLB = async (): Promise<Blob | null> => {
    if (!sceneRef.current) {
      console.error('No scene to export');
      return null;
    }

    try {
      const { GLTFExporter } = await import('three/examples/jsm/exporters/GLTFExporter.js');
      
      // Get current models from store (to ensure we have the latest state)
      const currentModels = useSceneStore.getState().models;
      
      console.log('📦 Exporting scene...');
      console.log('  - Models in store:', currentModels.length);
      
      return new Promise((resolve, reject) => {
        const exporter = new GLTFExporter();
        
        // Create a clone of the scene with only the models (no helpers, lights, etc.)
        const exportScene = new THREE.Scene();
        
        // Clone only the model groups
        currentModels.forEach(model => {
          if (model.objectRef && model.visible) {
            console.log(`  - Cloning model: ${model.name}, visible: ${model.visible}`);
            const clonedGroup = model.objectRef.clone();
            
            // Count decals in this model
            let modelDecalCount = 0;
            clonedGroup.traverse((child) => {
              if (child instanceof THREE.Mesh && child.userData.isDecal) {
                modelDecalCount++;
                console.log(`    ✓ Found decal: ${child.name}`);
              }
            });
            console.log(`    - Decals in model: ${modelDecalCount}`);
            
            exportScene.add(clonedGroup);
          } else {
            console.log(`  - Skipping model: ${model.name}, objectRef: ${!!model.objectRef}, visible: ${model.visible}`);
          }
        });
        
        // Also add any decal meshes from the main scene (they are added as separate meshes)
        let decalCount = 0;
        sceneRef.current?.traverse((child) => {
          if (child instanceof THREE.Mesh && child.userData.isDecal) {
            const clonedMesh = child.clone() as THREE.Mesh;
            exportScene.add(clonedMesh);
            decalCount++;
            console.log(`  - Found standalone decal: ${child.name}`);
          }
        });
        
        console.log(`  - Total decals found: ${decalCount}`);
        console.log(`  - Total objects in export scene: ${exportScene.children.length}`);
        
        if (exportScene.children.length === 0) {
          console.warn('⚠️ Export scene is empty - no models or decals to export');
          resolve(null);
          return;
        }
        
        exporter.parse(
          exportScene,
          (result) => {
            // When binary: true, result is ArrayBuffer
            const blob = new Blob([result as ArrayBuffer], { type: 'model/gltf-binary' });
            console.log(`✅ Export complete, blob size: ${blob.size} bytes`);
            resolve(blob);
          },
          (error) => {
            console.error('Export error:', error);
            reject(error);
          },
          { binary: true } // Export as GLB
        );
      });
    } catch (error) {
      console.error('Failed to export scene:', error);
      return null;
    }
  };

  // Expose loadModel function to window for external access
  useEffect(() => {
    (window as any).loadModel = (file: File, name?: string, preserveMaterials?: boolean) => {
      return loadModelFromFile(file, name, preserveMaterials);
    };
    return () => {
      delete (window as any).loadModel;
    };
  }, [loadModelFromFile]);

  // Expose exportScene function to window for external access
  useEffect(() => {
    (window as any).exportScene = exportSceneToGLB;
    return () => {
      delete (window as any).exportScene;
    };
  }, [models]);

  // Expose clearDecalHighlight function to window for external access
  useEffect(() => {
    (window as any).clearDecalHighlight = () => {
      if (highlightedMeshRef.current && sceneRef.current) {
        const mat = highlightedMeshRef.current.material as THREE.MeshStandardMaterial;
        if (mat?.emissive) {
          mat.emissive.setHex(0x000000);
          mat.emissiveIntensity = 0;
        }
        highlightedMeshRef.current = null;
        // Force render
        if (rendererRef.current && cameraRef.current && sceneRef.current) {
          rendererRef.current.render(sceneRef.current, cameraRef.current);
        }
        console.log('Cleared decal highlight');
      }
    };
    return () => {
      delete (window as any).clearDecalHighlight;
    };
  }, []);

  // Expose applyDecalToSelection function to window for external access
  useEffect(() => {
    (window as any).applyDecalToSelection = async (labelImageData: string) => {
      console.log('=== applyDecalToSelection called ===');
      const decalState = useDecalModeStore.getState();
      const { selectedFaces, opacity, decalSize, decalRotation } = decalState;
      
      console.log('selectedFaces:', selectedFaces);
      console.log('opacity:', opacity, 'decalSize:', decalSize, 'rotation:', decalRotation);
      console.log('sceneRef.current:', sceneRef.current ? 'exists' : 'null');
      
      if (!sceneRef.current) {
        console.error('Scene not available');
        return false;
      }
      
      if (selectedFaces.length === 0) {
        console.warn('No faces selected');
        return false;
      }

      const targetMeshUuid = selectedFaces[0]?.meshUuid;
      console.log('targetMeshUuid:', targetMeshUuid);
      if (!targetMeshUuid) {
        console.warn('No mesh UUID in selection');
        return false;
      }

      // Find mesh in scene
      let targetMesh: THREE.Mesh | null = null;
      sceneRef.current!.traverse((child) => {
        if (child instanceof THREE.Mesh && child.uuid === targetMeshUuid) {
          targetMesh = child;
        }
      });

      if (!targetMesh) {
        console.error('Target mesh not found:', targetMeshUuid);
        // List all meshes for debugging
        const allMeshes: string[] = [];
        sceneRef.current!.traverse((child) => {
          if (child instanceof THREE.Mesh) allMeshes.push(`${child.name} (${child.uuid})`);
        });
        console.log('All meshes in scene:', allMeshes);
        return false;
      }

      const mesh = targetMesh as THREE.Mesh;
      console.log('Found target mesh:', mesh.name);

      // Load texture
      return new Promise<boolean>((resolve) => {
        const loader = new THREE.TextureLoader();
        loader.load(labelImageData, (texture) => {
          console.log('Texture loaded');
          texture.colorSpace = THREE.SRGBColorSpace;
          texture.wrapS = THREE.ClampToEdgeWrapping;
          texture.wrapT = THREE.ClampToEdgeWrapping;
          texture.minFilter = THREE.LinearFilter;
          texture.magFilter = THREE.LinearFilter;
          texture.generateMipmaps = true;
          texture.needsUpdate = true;

          const faceData = selectedFaces[0];
          const position = new THREE.Vector3(faceData.position.x, faceData.position.y, faceData.position.z);
          const normal = new THREE.Vector3(faceData.normal.x, faceData.normal.y, faceData.normal.z).normalize();

          console.log('=== Creating Local Decal (Curved Surface) ===');
          console.log('Target mesh:', mesh.name, 'uuid:', mesh.uuid);
          console.log('Position (world):', position.toArray());
          console.log('Normal (world):', normal.toArray());

          // Ensure mesh has valid geometry
          if (!mesh.geometry || !mesh.geometry.attributes.position) {
            console.error('Mesh has no valid geometry!');
            resolve(false);
            return;
          }
          console.log('Mesh geometry vertices:', mesh.geometry.attributes.position.count);

          // Use larger size for visibility on 3D models
          const decalSizeValue = Math.max(decalSize, 3.0);

          const decalMaterial = new THREE.MeshStandardMaterial({
            map: texture,
            transparent: true,
            opacity: 1.0,
            depthTest: true,
            depthWrite: false,
            polygonOffset: true,
            polygonOffsetFactor: -1,
            roughness: 0.5,
            metalness: 0.0,
            side: THREE.DoubleSide,
            alphaTest: 0.1,
          });

          // ============================================================
          // KEY: Use DecalGeometry for curved surface projection
          // DecalGeometry projects the texture onto the actual mesh surface
          // by intersecting a box with the mesh's triangles and clipping them.
          // This creates a decal that follows the model's curves!
          // ============================================================
          
          // Compute orientation from normal using quaternion (avoids gimbal lock)
          // DecalGeometry default forward direction is Z+
          const defaultForward = new THREE.Vector3(0, 0, 1);
          const quaternion = new THREE.Quaternion().setFromUnitVectors(defaultForward, normal);
          
          // Apply user rotation around the normal axis
          if (decalRotation !== 0) {
            const rotQuat = new THREE.Quaternion().setFromAxisAngle(
              normal, 
              THREE.MathUtils.degToRad(decalRotation)
            );
            quaternion.multiply(rotQuat);
          }
          
          const orientationEuler = new THREE.Euler().setFromQuaternion(quaternion);

          console.log('Decal size:', decalSizeValue);
          console.log('Orientation euler (rad):', { 
            x: orientationEuler.x.toFixed(3), 
            y: orientationEuler.y.toFixed(3), 
            z: orientationEuler.z.toFixed(3) 
          });

          let decalGeometry: DecalGeometry;
          try {
            decalGeometry = new DecalGeometry(
              mesh,                    // Source mesh for projection
              position,                // World position on surface
              orientationEuler,        // Orientation from surface normal
              new THREE.Vector3(decalSizeValue, decalSizeValue, decalSizeValue * 0.5) // Size box
            );
            
            const vertexCount = decalGeometry.attributes.position?.count || 0;
            console.log('DecalGeometry created, vertex count:', vertexCount);
            
            if (vertexCount === 0) {
              console.warn('DecalGeometry has 0 vertices! Falling back to PlaneGeometry.');
              // Fallback to plane if projection fails
              const fallbackGeo = new THREE.PlaneGeometry(decalSizeValue * 0.5, decalSizeValue * 0.5);
              const fallbackMesh = new THREE.Mesh(fallbackGeo, decalMaterial);
              
              fallbackMesh.position.copy(position).add(normal.clone().multiplyScalar(0.01));
              const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), normal);
              fallbackMesh.quaternion.copy(q);
              
              mesh.updateMatrixWorld(true);
              fallbackMesh.applyMatrix4(new THREE.Matrix4().copy(mesh.matrixWorld).invert());
              
              fallbackMesh.name = `decal-local-fallback-${Date.now()}`;
              fallbackMesh.userData.isDecal = true;
              fallbackMesh.userData.parentMeshUuid = targetMeshUuid;
              fallbackMesh.userData.originalMeshName = mesh.name;
              fallbackMesh.userData.isLocalDecal = true;
              mesh.add(fallbackMesh);
              
              removeSelectionOutline();
              highlightedMeshRef.current = null;
              resolve(true);
              return;
            }
          } catch (err) {
            console.error('DecalGeometry creation error:', err);
            resolve(false);
            return;
          }

          const decalMesh = new THREE.Mesh(decalGeometry, decalMaterial);

          decalMesh.name = `decal-local-${Date.now()}`;
          decalMesh.userData.isDecal = true;
          decalMesh.userData.parentMeshUuid = targetMeshUuid;
          decalMesh.userData.originalMeshName = mesh.name;
          decalMesh.userData.isLocalDecal = true;

          // CRITICAL: DecalGeometry outputs vertices in WORLD coordinates.
          // We add directly to scene (not as child of mesh) so it displays at correct world position.
          // The decal will follow model curves because its geometry was projected onto the mesh surface.
          sceneRef.current!.add(decalMesh);
          
          console.log('=== Curved decal applied successfully (added to scene) ===');
          console.log('Decal world pos:', decalMesh.position.toArray());
          
          // Remove selection outline ONLY after successful creation
          removeSelectionOutline();
          highlightedMeshRef.current = null;

          resolve(true);
        }, undefined, (error) => {
          console.error('Texture load failed:', error);
          resolve(false);
        });
      });
    };
    return () => {
      delete (window as any).applyDecalToSelection;
    };
  }, []);

  // Expose applyDecal function to window for external access
  useEffect(() => {
    (window as any).applyDecal = async (
      imageData: string,
      position: [number, number, number],
      normal: [number, number, number],
      size: number = 0.5,
      rotation: number = 0
    ) => {
      if (!sceneRef.current || models.length === 0) {
        console.error('No model loaded to apply decal');
        return;
      }

      // Get the first model
      const targetGroup = models[0].objectRef;
      if (!targetGroup) {
        console.error('Model reference not found');
        return;
      }

      // Find the first mesh in the group
      let targetMesh: THREE.Mesh | undefined;
      targetGroup.traverse((child) => {
        if (child instanceof THREE.Mesh && !targetMesh) {
          targetMesh = child;
        }
      });

      if (!targetMesh) {
        console.error('No mesh found in model');
        return;
      }

      // Now targetMesh is guaranteed to be a THREE.Mesh
      const mesh = targetMesh;

      try {
        const { DecalGeometry } = await import('three/examples/jsm/geometries/DecalGeometry.js');

        // Load texture
        const loader = new THREE.TextureLoader();
        const texture = await new Promise<THREE.Texture>((resolve, reject) => {
          loader.load(
            imageData,
            (texture) => {
              texture.flipY = false;
              texture.colorSpace = THREE.SRGBColorSpace;
              resolve(texture);
            },
            undefined,
            reject
          );
        });

        // Create decal material
        const decalMaterial = new THREE.MeshPhongMaterial({
          map: texture,
          transparent: true,
          depthTest: true,
          depthWrite: false,
          polygonOffset: true,
          polygonOffsetFactor: -4,
        });

        // Create decal geometry
        const orientation = new THREE.Euler(0, 0, (rotation * Math.PI) / 180);
        const decalSize = new THREE.Vector3(size, size, size);
        const decalPosition = new THREE.Vector3(...position);
        const decalNormal = new THREE.Vector3(...normal);

        const decalGeometry = new DecalGeometry(
          mesh,
          decalPosition,
          orientation,
          decalSize
        );

        // Create decal mesh
        const decalMesh = new THREE.Mesh(decalGeometry, decalMaterial);
        decalMesh.name = 'decal-' + Date.now();
        decalMesh.userData.isDecal = true;

        // Add as child of target mesh so it follows the mesh transform
        mesh.add(decalMesh);

        console.log('✅ Decal applied successfully:', decalMesh.name);
        forceSceneUpdate();

        return decalMesh;
      } catch (error) {
        console.error('Failed to apply decal:', error);
        throw error;
      }
    };

    return () => {
      delete (window as any).applyDecal;
      // 清理 TransformControls，防止 re-run 时冲突
      if (transformControlsRef.current) {
        try {
          transformControlsRef.current.detach();
          if (transformControlsRef.current.parent) {
            transformControlsRef.current.parent.remove(transformControlsRef.current);
          }
          transformControlsRef.current.dispose?.();
        } catch (e) {
          // ignore cleanup errors
        }
        transformControlsRef.current = null;
      }
    };
  }, [models, forceSceneUpdate]);

  // 创建贴花预览
  const createDecalPreview = useCallback((
    position: THREE.Vector3,
    normal: THREE.Vector3,
    targetMesh: THREE.Mesh,
    size: number
  ) => {
    const scene = sceneRef.current;
    const decalMode = useDecalModeStore.getState();
    if (!scene || !decalMode.activeLabelImage) return;

    // Remove existing preview
    if (decalPreviewRef.current) {
      scene.remove(decalPreviewRef.current);
      decalPreviewRef.current.geometry?.dispose();
      if (decalPreviewRef.current.material instanceof THREE.Material) {
        decalPreviewRef.current.material.dispose();
      }
      decalPreviewRef.current = null;
    }

    // Load texture and create preview
    const textureLoader = new THREE.TextureLoader();
    textureLoader.load(decalMode.activeLabelImage, (texture) => {
      texture.colorSpace = THREE.SRGBColorSpace;
      texture.minFilter = THREE.LinearMipmapLinearFilter;
      texture.magFilter = THREE.LinearFilter;

      // Create orientation from normal
      const orientation = new THREE.Euler();
      const up = new THREE.Vector3(0, 1, 0);
      const quaternion = new THREE.Quaternion();
      quaternion.setFromUnitVectors(up, normal.clone().normalize());
      orientation.setFromQuaternion(quaternion);
      orientation.z = THREE.MathUtils.degToRad(decalMode.decalRotation);

      // Apply decal size from store
      const decalSize = decalMode.decalSize;

      try {
        const geometry = new DecalGeometry(targetMesh, position, orientation, new THREE.Vector3(decalSize, decalSize, decalSize));
        
        const material = new THREE.MeshStandardMaterial({
          map: texture,
          transparent: true,
          opacity: 0.8,
          depthWrite: false,
          depthTest: true,
          polygonOffset: true,
          polygonOffsetFactor: -4,
          roughness: 0.7,
          metalness: 0.0,
          side: THREE.DoubleSide,
        });

        const previewMesh = new THREE.Mesh(geometry, material);
        previewMesh.name = 'decal-preview';
        previewMesh.userData.isDecalPreview = true;
        
        // Add to mesh as child so it follows transform
        targetMesh.add(previewMesh);
        decalPreviewRef.current = previewMesh;

        // Force render
        if (rendererRef.current && scene && cameraRef.current) {
          rendererRef.current.render(scene, cameraRef.current);
        }

        console.log('✅ Decal preview created, size:', decalSize.toFixed(2));
      } catch (err) {
        console.error('Failed to create decal preview:', err);
      }
    });
  }, []);

  // 监听撤销贴花事件
  useEffect(() => {
    const handleUndoDecalMeshes = (event: CustomEvent) => {
      const { meshNames } = event.detail;
      const scene = sceneRef.current;
      if (!scene) return;

      meshNames.forEach((meshName: string) => {
        const obj = scene.getObjectByName(meshName);
        if (obj && obj instanceof THREE.Mesh) {
          scene.remove(obj);
          if (obj.geometry) obj.geometry.dispose();
          if (obj.material) {
            if (Array.isArray(obj.material)) {
              obj.material.forEach((m: THREE.Material) => m.dispose());
            } else {
              obj.material.dispose();
            }
          }
          console.log('Undo: Removed decal mesh:', meshName);
        }
      });

      forceSceneUpdate();
    };

    // 清除贴花预览
    const handleClearPreview = () => {
      const scene = sceneRef.current;
      if (!scene) return;

      // Remove preview mesh
      if (decalPreviewRef.current) {
        decalPreviewRef.current.parent?.remove(decalPreviewRef.current);
        decalPreviewRef.current.geometry?.dispose();
        if (decalPreviewRef.current.material instanceof THREE.Material) {
          decalPreviewRef.current.material.dispose();
        }
        decalPreviewRef.current = null;
      }
      
      // Clear preview data
      decalPreviewDataRef.current = null;
      isDecalPreviewActiveRef.current = false;
      
      // Clear selected faces in store
      useDecalModeStore.getState().clearSelectedFaces();
      
      forceSceneUpdate();
      console.log('✅ Decal preview cleared');
    };

    // 应用贴花预览
    const handleApplyPreview = () => {
      const scene = sceneRef.current;
      const decalMode = useDecalModeStore.getState();
      if (!scene || !decalPreviewRef.current || !decalPreviewDataRef.current) {
        console.warn('No decal preview to apply');
        return;
      }

      const previewMesh = decalPreviewRef.current;
      const previewData = decalPreviewDataRef.current;
      
      // Create permanent decal mesh
      const decalMeshName = `decal-applied-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      previewMesh.name = decalMeshName;
      previewMesh.userData.isDecalPreview = false;
      previewMesh.userData.isDecal = true;
      previewMesh.userData.parentMeshUuid = previewData.mesh.uuid;
      
      // Set final opacity
      if (previewMesh.material instanceof THREE.MeshStandardMaterial) {
        previewMesh.material.opacity = decalMode.opacity;
      }
      
      // Add to placed decals
      useDecalModeStore.getState().pushHistory({
        actionType: 'single_decal',
        labelId: decalMode.activeLabelId || '',
        modelId: previewData.modelId,
        materialSnapshots: [],
        decalMeshNames: [decalMeshName],
      });

      useDecalModeStore.getState().addPlacedDecal({
        labelId: decalMode.activeLabelId || '',
        modelId: previewData.modelId,
        coverageMode: 'single',
        repeatDensity: 1,
        opacity: decalMode.opacity,
        rotation: decalMode.decalRotation,
        size: decalMode.decalSize,
      });

      // Clear preview state
      decalPreviewRef.current = null;
      decalPreviewDataRef.current = null;
      isDecalPreviewActiveRef.current = false;
      useDecalModeStore.getState().clearSelectedFaces();

      forceSceneUpdate();
      console.log('✅ Decal applied successfully:', decalMeshName);
    };

    window.addEventListener('undo-decal-meshes', handleUndoDecalMeshes as EventListener);
    window.addEventListener('clear-decal-preview', handleClearPreview);
    window.addEventListener('apply-decal-preview', handleApplyPreview);

    return () => {
      window.removeEventListener('undo-decal-meshes', handleUndoDecalMeshes as EventListener);
      window.removeEventListener('clear-decal-preview', handleClearPreview);
      window.removeEventListener('apply-decal-preview', handleApplyPreview);
    };
  }, [forceSceneUpdate]);

  // 加载初始模型
  useEffect(() => {
    if (initialUrl && sceneReady) {
      loadModel(initialUrl, 'Initial Model', [0, 0, 0])
        .then(() => {
          setIsLoading(false);
          if (onLoad) onLoad();
        })
        .catch(() => {
          setIsLoading(false);
          if (onError) onError();
        });
    }
  }, [initialUrl, sceneReady]);

  // 框选相关状态
  const isSelectingRef = useRef(false);
  const selectionStartRef = useRef<{ x: number; y: number } | null>(null);

  // 处理画布 mousedown - 开始框选或拖动选择贴花区域
  const handleCanvasMouseDown = useCallback((event: React.MouseEvent<HTMLCanvasElement>) => {
    const decalMode = useDecalModeStore.getState();
    if (!decalMode.isDecalMode || !decalMode.activeLabelImage) return;
    
    // 只在框选模式下处理
    if (decalMode.selectionType === 'box') {
      isSelectingRef.current = true;
      selectionStartRef.current = { x: event.clientX, y: event.clientY };
      useDecalModeStore.getState().startSelection({ x: event.clientX, y: event.clientY });
      return;
    }
    
    // Click 模式 - 开始拖动选择贴花区域
    if (decalMode.selectionType === 'click') {
      if (!canvasRef.current || !cameraRef.current || !sceneRef.current) return;

      const canvas = canvasRef.current;
      const rect = canvas.getBoundingClientRect();

      mouseRef.current.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouseRef.current.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current);

      // Get all meshes in scene (exclude helpers, decals, floor, and non-model objects)
      const allMeshes: THREE.Mesh[] = [];
      sceneRef.current.traverse((child) => {
        if (child instanceof THREE.Mesh && child.visible && !shouldExcludeMesh(child)) {
          allMeshes.push(child);
        }
      });

      const intersects = raycasterRef.current.intersectObjects(allMeshes, true);

      if (intersects.length > 0) {
        const intersect = intersects[0];
        const clickedMesh = intersect.object as THREE.Mesh;
        const position = intersect.point.clone();
        const normal = intersect.face?.normal.clone() || new THREE.Vector3(0, 1, 0);
        
        // Transform normal to world space
        clickedMesh.updateMatrixWorld(true);
        normal.transformDirection(clickedMesh.matrixWorld);

        // Find the root model
        let targetObject: THREE.Object3D = clickedMesh;
        let parent = clickedMesh.parent;
        while (parent && parent !== sceneRef.current) {
          if (parent.type === 'Group' && parent.name && !parent.name.includes('helper')) {
            targetObject = parent;
            break;
          }
          parent = parent.parent;
        }

        // Get model ID
        const modelInfo = models.find(m => m.objectRef === targetObject || m.objectRef === (clickedMesh as THREE.Object3D));
        const modelId = modelInfo?.id || targetObject.uuid;

        // Store drag start info
        decalDragStartRef.current = {
          position: position,
          normal: normal,
          mesh: clickedMesh,
          modelId: modelId,
          screenPos: { x: event.clientX, y: event.clientY }
        };
        isDecalDraggingRef.current = true;
      }
    }
  }, [models]);

  // 处理画布 mousemove - 更新框选和悬停预览
  const handleCanvasMouseMove = useCallback((event: React.MouseEvent<HTMLCanvasElement>) => {
    const decalMode = useDecalModeStore.getState();
    
    // Handle box selection
    if (isSelectingRef.current) {
      useDecalModeStore.getState().updateSelection({ x: event.clientX, y: event.clientY });
      return;
    }

    // Handle hover preview in click mode
    if (decalMode.isDecalMode && decalMode.activeLabelImage && decalMode.selectionType === 'click') {
      if (!canvasRef.current || !cameraRef.current || !sceneRef.current) return;

      const canvas = canvasRef.current;
      const rect = canvas.getBoundingClientRect();

      mouseRef.current.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouseRef.current.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current);

      // Get all meshes in scene (exclude helpers, decals, floor, and non-model objects)
      const allMeshes: THREE.Mesh[] = [];
      sceneRef.current.traverse((child) => {
        if (child instanceof THREE.Mesh && child.visible && !shouldExcludeMesh(child)) {
          allMeshes.push(child);
        }
      });

      const intersects = raycasterRef.current.intersectObjects(allMeshes, true);

      // Clear any existing circle/ring preview
      const existingPreview = sceneRef.current.getObjectByName('hover-preview');
      if (existingPreview) {
        sceneRef.current.remove(existingPreview);
        existingPreview.traverse((child) => {
          if (child instanceof THREE.Mesh) {
            child.geometry.dispose();
            (child.material as THREE.Material).dispose();
          }
        });
      }

      // If dragging, highlight the mesh under cursor
      if (isDecalDraggingRef.current && decalDragStartRef.current && intersects.length > 0) {
        const intersect = intersects[0];
        const currentMesh = intersect.object as THREE.Mesh;
        
        // Skip non-model objects (TransformControls, helpers, etc.)
        if (shouldExcludeMesh(currentMesh)) {
          return;
        }
        
        // Calculate drag distance for size display
        const dx = event.clientX - decalDragStartRef.current.screenPos.x;
        const dy = event.clientY - decalDragStartRef.current.screenPos.y;
        const dragDistance = Math.sqrt(dx * dx + dy * dy);
        const decalSize = Math.max(0.1, Math.min(5, dragDistance * 0.02));
        
        // Clear previous highlighted mesh if different
        if (highlightedMeshRef.current && highlightedMeshRef.current !== currentMesh) {
          removeSelectionOutline();
          highlightedMeshRef.current = null;
        }
        
        // Highlight the current mesh being dragged over
        createSelectionOutline(currentMesh);
        highlightedMeshRef.current = currentMesh;
        
        // Update drag start with current mesh and position for decal placement
        const position = intersect.point.clone();
        const normal = intersect.face?.normal.clone() || new THREE.Vector3(0, 1, 0);
        currentMesh.updateMatrixWorld(true);
        normal.transformDirection(currentMesh.matrixWorld);
        
        decalDragStartRef.current.position = position;
        decalDragStartRef.current.normal = normal;
        decalDragStartRef.current.mesh = currentMesh;
        
        console.log('Dragging - size:', decalSize.toFixed(2), 'mesh:', currentMesh.name);
        
        // Force render
        if (rendererRef.current && sceneRef.current && cameraRef.current) {
          rendererRef.current.render(sceneRef.current, cameraRef.current);
        }
      } else if (intersects.length > 0) {
        // Not dragging - show hover highlight on mesh
        // BUT if we already have a selection (waiting for Apply), keep the highlight
        const hasSelection = useDecalModeStore.getState().selectedFaces.length > 0;
        
        const intersect = intersects[0];
        const hoveredMesh = intersect.object as THREE.Mesh;
        
        // Skip non-model objects (TransformControls, helpers, etc.)
        if (shouldExcludeMesh(hoveredMesh)) {
          // Clear any existing highlight only if no selection
          if (!hasSelection && highlightedMeshRef.current) {
            removeSelectionOutline();
            highlightedMeshRef.current = null;
          }
          return;
        }
        
        // If we have a selection, don't change highlight
        if (hasSelection) {
          return;
        }
        
        // Clear previous highlighted mesh if different
        if (highlightedMeshRef.current && highlightedMeshRef.current !== hoveredMesh) {
          removeSelectionOutline();
        }
        
        // Highlight the hovered mesh
        createSelectionOutline(hoveredMesh);
        highlightedMeshRef.current = hoveredMesh;

        // Force render
        if (rendererRef.current && sceneRef.current && cameraRef.current) {
          rendererRef.current.render(sceneRef.current, cameraRef.current);
        }
      } else {
        // No mesh under cursor - clear any existing highlight
        if (highlightedMeshRef.current) {
          removeSelectionOutline();
          highlightedMeshRef.current = null;
          
          // Force render
          if (rendererRef.current && sceneRef.current && cameraRef.current) {
            rendererRef.current.render(sceneRef.current, cameraRef.current);
          }
        }
      }
    }
  }, []);

  // 处理鼠标离开画布 - 清理高亮
  const handleCanvasMouseLeave = useCallback(() => {
    if (!sceneRef.current) return;
    
    // If we have a selection, don't clear highlight
    const hasSelection = useDecalModeStore.getState().selectedFaces.length > 0;
    if (hasSelection) {
      return; // Keep the selection highlight
    }
    
    // Clear highlighted mesh only (not all meshes)
    if (highlightedMeshRef.current) {
      if ((highlightedMeshRef.current.material as THREE.MeshStandardMaterial)?.emissive) {
        (highlightedMeshRef.current.material as THREE.MeshStandardMaterial).emissive.setHex(0x000000);
        (highlightedMeshRef.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0;
      }
      highlightedMeshRef.current = null;
    }
    
    // Clear any existing preview
    const existingPreview = sceneRef.current.getObjectByName('hover-preview');
    if (existingPreview) {
      sceneRef.current.remove(existingPreview);
      existingPreview.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          child.geometry.dispose();
          (child.material as THREE.Material).dispose();
        }
      });
    }
    
    // Reset drag state
    isDecalDraggingRef.current = false;
    decalDragStartRef.current = null;
      
    // Force render
    if (rendererRef.current && sceneRef.current && cameraRef.current) {
      rendererRef.current.render(sceneRef.current, cameraRef.current);
    }
  }, []);

  // 处理画布 mouseup - 完成框选或拖动选择贴花
  const handleCanvasMouseUp = useCallback((event: React.MouseEvent<HTMLCanvasElement>) => {
    const decalMode = useDecalModeStore.getState();
    
    // Handle Click mode - drag selection ended
    // MUST check isDecalMode to ensure we're still in decal mode
    if (decalMode.isDecalMode && isDecalDraggingRef.current && decalDragStartRef.current && decalMode.selectionType === 'click') {
      isDecalDraggingRef.current = false;
      
      // Calculate drag distance for decal size
      const dx = event.clientX - decalDragStartRef.current.screenPos.x;
      const dy = event.clientY - decalDragStartRef.current.screenPos.y;
      const dragDistance = Math.sqrt(dx * dx + dy * dy);
      
      // If drag distance is too small, this is just a click - keep highlight, wait for Apply
      if (dragDistance < 5) {
        console.log('Click detected - keeping highlight for Apply');
        // Keep the highlight, don't clear it
        // selectedFaces should already be set from handleCanvasClick
        decalDragStartRef.current = null;
        return;
      }
      
      // Drag mode - apply decal directly
      const decalSize = Math.max(0.1, Math.min(5, dragDistance * 0.02));
      const startPos = decalDragStartRef.current.position;
      const normal = decalDragStartRef.current.normal;
      const clickedMesh = decalDragStartRef.current.mesh;
      const modelId = decalDragStartRef.current.modelId;
      
      // Safety check: ensure the mesh is a valid model mesh (not TransformControls, etc.)
      if (!clickedMesh || shouldExcludeMesh(clickedMesh)) {
        console.warn('Invalid mesh for decal application, skipping');
        decalDragStartRef.current = null;
        return;
      }
      
      // Clear highlight from mesh
      if (highlightedMeshRef.current) {
        if ((highlightedMeshRef.current.material as THREE.MeshStandardMaterial)?.emissive) {
          (highlightedMeshRef.current.material as THREE.MeshStandardMaterial).emissive.setHex(0x000000);
          (highlightedMeshRef.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0;
        }
        highlightedMeshRef.current = null;
      }
      
      // Create decal using DecalGeometry
      const textureLoader = new THREE.TextureLoader();
      textureLoader.load(decalMode.activeLabelImage!, (texture) => {
        texture.colorSpace = THREE.SRGBColorSpace;
        texture.minFilter = THREE.LinearMipmapLinearFilter;
        texture.magFilter = THREE.LinearFilter;
        texture.generateMipmaps = true;
        
        // Create orientation from normal
        const orientation = new THREE.Euler();
        const up = new THREE.Vector3(0, 1, 0);
        const quaternion = new THREE.Quaternion();
        quaternion.setFromUnitVectors(up, normal.clone().normalize());
        orientation.setFromQuaternion(quaternion);
        
        // Create DecalGeometry
        const decalGeometry = new DecalGeometry(
          clickedMesh,
          startPos,
          orientation,
          new THREE.Vector3(decalSize, decalSize, decalSize)
        );
        
        const decalMaterial = new THREE.MeshStandardMaterial({
          map: texture,
          transparent: true,
          opacity: decalMode.opacity,
          depthWrite: false,
          depthTest: true,
          polygonOffset: true,
          polygonOffsetFactor: -4,
          roughness: 0.7,
          metalness: 0.0,
          side: THREE.DoubleSide,
        });

        const decalMesh = new THREE.Mesh(decalGeometry, decalMaterial);
        const decalMeshName = `decal-drag-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        decalMesh.name = decalMeshName;
        decalMesh.userData.isDecal = true;
        decalMesh.userData.parentMeshUuid = clickedMesh.uuid;

        // Add decal as child of the clicked mesh so it follows the mesh transform
        clickedMesh.add(decalMesh);

        // Push to history for undo
        useDecalModeStore.getState().pushHistory({
          actionType: 'single_decal',
          labelId: decalMode.activeLabelId || '',
          modelId: modelId,
          materialSnapshots: [],
          decalMeshNames: [decalMeshName],
        });

        useDecalModeStore.getState().addPlacedDecal({
          labelId: decalMode.activeLabelId || '',
          modelId: modelId,
          coverageMode: 'single',
          repeatDensity: 1,
          opacity: decalMode.opacity,
          rotation: decalMode.decalRotation,
          size: decalSize,
        });

        console.log('Decal applied via drag, size:', decalSize.toFixed(2));
        
        // Force render
        if (rendererRef.current && sceneRef.current && cameraRef.current) {
          rendererRef.current.render(sceneRef.current, cameraRef.current);
        }
      });
      
      decalDragStartRef.current = null;
      return;
    }
    
    // Handle box selection
    if (!isSelectingRef.current) return;
    isSelectingRef.current = false;

    const decalStore = useDecalModeStore.getState();
    const { selectionStart, selectionEnd, selectionType } = decalStore;
    
    if (!selectionStart || !selectionEnd) {
      useDecalModeStore.getState().clearSelection();
      return;
    }

    // 计算框选区域大小
    const width = Math.abs(selectionEnd.x - selectionStart.x);
    const height = Math.abs(selectionEnd.y - selectionStart.y);
    
    // 如果框选区域太小且是框选模式，视为点击，清除选择
    // 点击模式应该保留 selectedFaces，让用户点击 Apply
    if (width < 10 || height < 10) {
      if (selectionType === 'box') {
        useDecalModeStore.getState().clearSelection();
        return;
      }
      // 点击模式下不清理，让用户可以 Apply
    }

    // 获取框选区域的中心点
    const centerX = (selectionStart.x + selectionEnd.x) / 2;
    const centerY = (selectionStart.y + selectionEnd.y) / 2;

    if (!canvasRef.current || !cameraRef.current || !sceneRef.current) {
      useDecalModeStore.getState().clearSelection();
      return;
    }

    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();

    // 将中心点转换为 normalized device coordinates
    mouseRef.current.x = ((centerX - rect.left) / rect.width) * 2 - 1;
    mouseRef.current.y = -((centerY - rect.top) / rect.height) * 2 + 1;

    raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current);

    // 获取所有模型网格
    const allMeshes: THREE.Mesh[] = [];
    sceneRef.current.traverse((child) => {
      if (child instanceof THREE.Mesh && child.visible && child.name !== 'Floor') {
        allMeshes.push(child);
      }
    });

    const intersects = raycasterRef.current.intersectObjects(allMeshes, true);

    if (intersects.length > 0) {
      const intersect = intersects[0];
      const clickedMesh = intersect.object as THREE.Mesh;
      
      // 获取模型ID和Three.js UUID
      let targetModelId: string | null = null;
      let targetModelUuid: string | null = null;  // Three.js UUID for Transform/Material panels
      for (const model of models) {
        if (model.objectRef && model.objectRef.children.includes(clickedMesh)) {
          targetModelId = model.id;
          targetModelUuid = model.objectRef.uuid;
          break;
        }
        // 检查是否是子对象
        if (model.objectRef) {
          let found = false;
          model.objectRef.traverse((child) => {
            if (child === clickedMesh) found = true;
          });
          if (found) {
            targetModelId = model.id;
            targetModelUuid = model.objectRef.uuid;
            break;
          }
        }
      }

      const modelId = targetModelId || clickedMesh.uuid;
      const modelObjectUuid = targetModelUuid || clickedMesh.uuid;

      // Get intersection point and normal
      const position = intersect.point.clone();
      const normal = intersect.face?.normal.clone() || new THREE.Vector3(0, 1, 0);
      
      // Transform normal to world space
      clickedMesh.updateMatrixWorld(true);
      normal.transformDirection(clickedMesh.matrixWorld);

      // 根据框选大小计算贴花尺寸
      const boxSize = Math.max(width, height) / 100; // 根据屏幕像素估算3D尺寸
      const decalWidth = Math.max(0.3, Math.min(3, boxSize));
      const decalHeight = Math.max(0.3, Math.min(3, boxSize * (height / width)));

      // Store selection data for later use when Apply is clicked
      useDecalModeStore.getState().setSelectedFaces([{
        id: `${clickedMesh.uuid}_${intersect.faceIndex || 0}_${Date.now()}`,
        meshUuid: clickedMesh.uuid,
        meshName: clickedMesh.name,
        faceIndex: intersect.faceIndex || 0,
        parentId: modelId,
        position: { x: position.x, y: position.y, z: position.z },
        normal: { x: normal.x, y: normal.y, z: normal.z },
      }]);

      // Also set selected object so Transform/Material panels work
      // Must use Three.js UUID (objectRef.uuid), not store model ID
      setSelectedObject(modelObjectUuid);
      setSelectedLight(null);

      console.log('Box selection made - purple highlight set, model UUID:', modelObjectUuid);
    }

    // 清除选择状态
    useDecalModeStore.getState().endSelection();
  }, [models]);

  // 处理画布点击 - 用于选中 3D 对象或放置局部贴花
  const handleCanvasClick = useCallback((event: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current || !cameraRef.current || !sceneRef.current) return;

    // Check if in decal mode with click selection
    const decalMode = useDecalModeStore.getState();
    if (decalMode.isDecalMode && decalMode.activeLabelImage && decalMode.selectionType === 'click') {
      // Check for double click
      const now = Date.now();
      const timeSinceLastClick = now - lastClickTimeRef.current;
      
      if (timeSinceLastClick < DOUBLE_CLICK_THRESHOLD) {
        // Double click detected - complete selection with purple highlight
        lastClickTimeRef.current = 0; // Reset
        
        const canvas = canvasRef.current;
        const rect = canvas.getBoundingClientRect();

        mouseRef.current.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
        mouseRef.current.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

        raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current);

        // Get all meshes in scene
        const allMeshes: THREE.Mesh[] = [];
        sceneRef.current.traverse((child) => {
          if (child instanceof THREE.Mesh && child.visible && !shouldExcludeMesh(child)) {
            allMeshes.push(child);
          }
        });

        const intersects = raycasterRef.current.intersectObjects(allMeshes, true);

        if (intersects.length > 0) {
          const intersect = intersects[0];
          const clickedMesh = intersect.object as THREE.Mesh;
          const position = intersect.point.clone();
          const normal = intersect.face?.normal.clone() || new THREE.Vector3(0, 1, 0);
          
          // Transform normal to world space
          clickedMesh.updateMatrixWorld(true);
          normal.transformDirection(clickedMesh.matrixWorld);

          // Find model info
          let modelId = '';
          let modelObjectUuid = '';  // Three.js UUID of model's root object (for Transform/Material panels)
          let targetObject: THREE.Object3D = clickedMesh;
          let parent = clickedMesh.parent;
          while (parent && parent !== sceneRef.current) {
            const modelInfo = models.find(m => m.objectRef === parent);
            if (modelInfo) {
              modelId = modelInfo.id;
              // CRITICAL: Use the root object's UUID, not any child's UUID
              // This must match what TransformPanel/MaterialPanel checks (model.objectRef.uuid)
              if (modelInfo.objectRef) {
                modelObjectUuid = modelInfo.objectRef.uuid;
              }
              targetObject = parent;
              break;
            }
            parent = parent.parent;
          }
          
          // Fallback: if no model found in parent chain, try direct match or use first model's UUID
          if (!modelId || !modelObjectUuid) {
            const modelInfo = models.find(m => m.objectRef?.uuid === clickedMesh.uuid || m.objectRef === (clickedMesh as unknown as THREE.Group));
            if (modelInfo) {
              modelId = modelInfo.id;
              if (modelInfo.objectRef) {
                modelObjectUuid = modelInfo.objectRef.uuid;  // Always use ROOT object UUID
              }
            }
          }
          
          // Final fallback: use first available model's root UUID
          if (!modelObjectUuid && models.length > 0 && models[0].objectRef) {
            console.warn('Using first model UUID as fallback for Transform/Material panels');
            modelObjectUuid = models[0].objectRef.uuid;
            modelId = models[0].id;
          }
          
          // Absolute last resort: use clicked mesh's own UUID (may not work with panels)
          if (!modelObjectUuid) {
            console.warn('No model found at all, using clickedMesh uuid');
            modelObjectUuid = clickedMesh.uuid;
            modelId = clickedMesh.uuid;
          }

          // Set selected faces to enable Apply button
          const faceSelection = [{
            id: `${clickedMesh.uuid}_preview`,
            meshUuid: clickedMesh.uuid,
            meshName: clickedMesh.name,
            faceIndex: intersect.faceIndex || 0,
            parentId: modelId,
            position: { x: position.x, y: position.y, z: position.z },
            normal: { x: normal.x, y: normal.y, z: normal.z },
          }];
          useDecalModeStore.getState().setSelectedFaces(faceSelection);

          // Create purple outline to show selection (reliable visual feedback)
          createSelectionOutline(clickedMesh);
          highlightedMeshRef.current = clickedMesh;

          // IMPORTANT: Also set selected object so Transform/Material panels work!
          // Must use the Three.js UUID (objectRef.uuid), not the store model ID
          console.log('=== Setting selected object for Transform/Material panels ===');
          console.log('modelObjectUuid:', modelObjectUuid);
          console.log('modelId:', modelId);
          console.log('Available models:', models.map(m => ({ id: m.id, uuid: m.objectRef?.uuid, name: m.name })));
          
          if (modelObjectUuid) {
            setSelectedObject(modelObjectUuid);
            console.log('setSelectedObject called with:', modelObjectUuid);
          } else {
            console.error('ERROR: modelObjectUuid is empty! Panels will not work.');
            // Emergency fallback: try to find any model's objectRef UUID
            if (models.length > 0 && models[0].objectRef) {
              const fallbackUuid = models[0].objectRef.uuid;
              console.log('Using emergency fallback UUID:', fallbackUuid);
              setSelectedObject(fallbackUuid);
            }
          }
          setSelectedLight(null);
          
          // Dispatch event to show "已选择" toast
          window.dispatchEvent(new CustomEvent('decal-selection-complete', { 
            detail: { message: '已选择' } 
          }));
        }
        return;
      } else {
        // Single click - just record time for double click detection
        lastClickTimeRef.current = now;
        return; // Don't do anything on single click
      }
    }

    // Check if in box selection mode - ignore clicks
    if (decalMode.isDecalMode && decalMode.selectionType === 'box') {
      return;
    }

    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();

    mouseRef.current.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    mouseRef.current.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current);

    // 首先检查是否点击了灯光 helper
    const allHelpers: THREE.Object3D[] = [];
    sceneRef.current.traverse((child) => {
      // 检查是否是灯光 helper（通过命名规则）
      if (child.name && child.name.endsWith('_helper') && child.visible) {
        allHelpers.push(child);
      }
    });

    if (allHelpers.length > 0) {
      const helperIntersects = raycasterRef.current.intersectObjects(allHelpers, false);

      if (helperIntersects.length > 0) {
        const clickedHelper = helperIntersects[0].object;
        // 从 helper 名称中提取 light ID
        const lightId = clickedHelper.name.replace('_helper', '');
        console.log('Clicked light helper:', lightId);

        setSelectedLight(lightId);
        // 清除模型选择
        setSelectedObject(null);
        return;
      }
    }

    // 如果没有点击 helper，则检查模型
    const allMeshes: THREE.Mesh[] = [];
    sceneRef.current.traverse((child) => {
      if (child instanceof THREE.Mesh && child.visible) {
        // 过滤掉 Floor 和 helpers
        if (child.name === 'Floor' || (child.name && child.name.endsWith('_helper'))) {
          return;
        }

        // 同时检查父对象是否可见
        let parentVisible = true;
        let parent = child.parent;
        while (parent) {
          if (!parent.visible) {
            parentVisible = false;
            break;
          }
          parent = parent.parent;
        }

        if (parentVisible) {
          allMeshes.push(child);
        }
      }
    });

    const intersects = raycasterRef.current.intersectObjects(allMeshes, true);

    console.log('=== Canvas Click ===');
    console.log('Total visible meshes:', allMeshes.length);
    console.log('Raycaster intersect count:', intersects.length);

    if (intersects.length > 0) {
      const clickedObject = intersects[0].object;
      console.log('Clicked object:', {
        uuid: clickedObject.uuid,
        name: clickedObject.name,
        type: clickedObject.type,
        visible: clickedObject.visible,
      });

      // 检查点击的对象是否是模型的一部分
      console.log('Current models:', models.map(m => ({ id: m.id, name: m.name, objectRefUuid: m.objectRef?.uuid })));

      // Find the model that contains this clicked object
      let targetModelId: string | null = null;
      
      // Check if clicked object is directly a model's objectRef
      for (const model of models) {
        if (model.objectRef === clickedObject) {
          targetModelId = model.id;
          break;
        }
      }
      
      // If not found directly, check if it's a child of a model's objectRef
      if (!targetModelId) {
        let parent = clickedObject.parent;
        while (parent && parent !== sceneRef.current) {
          for (const model of models) {
            if (model.objectRef === parent) {
              targetModelId = model.id;
              break;
            }
          }
          if (targetModelId) break;
          parent = parent.parent;
        }
      }
      
      // Also check if the clicked mesh belongs to any model by traversing model children
      if (!targetModelId) {
        for (const model of models) {
          if (model.objectRef) {
            let found = false;
            model.objectRef.traverse((child) => {
              if (child === clickedObject) {
                found = true;
              }
            });
            if (found) {
              targetModelId = model.id;
              break;
            }
          }
        }
      }

      console.log('Target model ID:', targetModelId);
      
      if (targetModelId) {
        setSelectedObject(targetModelId);
        // 清除灯光选择
        setSelectedLight(null);
      } else {
        // Fallback: use the uuid if no model found
        setSelectedObject(clickedObject.uuid);
        setSelectedLight(null);
      }
    } else {
      setSelectedObject(null);
      setSelectedLight(null);
    }
  }, [setSelectedObject, setSelectedLight, models]);

  // 更新选中对象的视觉反馈（金色边框）
  useEffect(() => {
    if (!sceneRef.current) return;

    // 移除旧的选中框
    if (selectionBoxRef.current) {
      sceneRef.current.remove(selectionBoxRef.current);
      selectionBoxRef.current.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          child.geometry.dispose();
          if (Array.isArray(child.material)) {
            child.material.forEach((m: any) => m.dispose());
          } else {
            (child.material as any).dispose();
          }
        }
      });
      selectionBoxRef.current = null;
    }

    // Detach TransformControls（如果之前有附加的对象）
    if (transformControlsRef.current) {
      transformControlsRef.current.detach();
    }

    if (selectedObjectUuid && sceneRef.current) {
      // Find the selected model by ID
      const selectedModel = models.find(m => m.id === selectedObjectUuid);
      const targetObject = selectedModel?.objectRef;

      if (targetObject) {
        console.log('Selected model:', {
          id: selectedModel?.id,
          name: selectedModel?.name,
          uuid: targetObject.uuid,
        });

        // 创建包围盒
        const box = new THREE.Box3().setFromObject(targetObject);
        const size = box.getSize(new THREE.Vector3());

        const selectionGroup = new THREE.Group();
        selectionGroup.name = 'selection-box';
        selectionGroup.userData.isSelectionBox = true;
        selectionBoxRef.current = selectionGroup;

        // 创建粗边框使用 TubeGeometry
        const boxGeometry = new THREE.BoxGeometry(size.x, size.y, size.z);
        const edgesGeometry = new THREE.EdgesGeometry(boxGeometry);

        // 将每条边转换为管状几何体以增加粗度
        const positions = edgesGeometry.attributes.position.array;
        const edgeMaterial = new THREE.MeshBasicMaterial({
          color: 0xFFD700, // 金黄色
          transparent: true,
          opacity: 1.0,
        });

        // EdgesGeometry 返回的是成对的点（每条边的起点和终点）
        for (let i = 0; i < positions.length; i += 6) {
          const start = new THREE.Vector3(positions[i], positions[i + 1], positions[i + 2]);
          const end = new THREE.Vector3(positions[i + 3], positions[i + 4], positions[i + 5]);

          // 创建管状边框
          const path = new THREE.LineCurve3(start, end);
          const tubeGeometry = new THREE.TubeGeometry(path, 1, 0.02, 8, false); // 半径 0.02，粗边框
          const tube = new THREE.Mesh(tubeGeometry, edgeMaterial);
          tube.userData.isSelectionBox = true; // 标记为选择框的一部分
          selectionGroup.add(tube);
        }

        const center = box.getCenter(new THREE.Vector3());
        selectionGroup.position.copy(center);

        sceneRef.current.add(selectionGroup);

        // 附加 TransformControls 到选中的对象
        if (transformControlsRef.current) {
          transformControlsRef.current.attach(targetObject);
        }
      }
    }
  }, [selectedObjectUuid, models]);

  // 更新选中灯光的 TransformControls
  useEffect(() => {
    if (!sceneRef.current || !transformControlsRef.current) return;

    // 如果有选中的灯光，清除模型选择
    if (selectedLightId) {
      // 清除模型选中框
      if (selectionBoxRef.current) {
        sceneRef.current.remove(selectionBoxRef.current);
        selectionBoxRef.current.traverse((child) => {
          if (child instanceof THREE.Mesh) {
            child.geometry.dispose();
            if (Array.isArray(child.material)) {
              child.material.forEach((m: any) => m.dispose());
            } else {
              (child.material as any).dispose();
            }
          }
        });
        selectionBoxRef.current = null;
      }

      // 从 store 中查找灯光对象
      const lightData = lights.find(l => l.id === selectedLightId);
      if (lightData && lightData.lightRef) {
        // 附加 TransformControls 到灯光对象
        transformControlsRef.current.attach(lightData.lightRef);
        console.log('Attached TransformControls to light:', selectedLightId);
      }
    } else if (!selectedObjectUuid) {
      // 既没有选中灯光，也没有选中模型，detach TransformControls
      transformControlsRef.current.detach();
    }
  }, [selectedLightId, lights, selectedObjectUuid]);

  // 更新 TransformControls 模式
  useEffect(() => {
    if (transformControlsRef.current) {
      transformControlsRef.current.setMode(transformMode);
    }
  }, [transformMode]);

  // 监听 Transform 模式变化，通过事件通知
  useEffect(() => {
    const handleTransformModeChange = (e: CustomEvent) => {
      const mode = e.detail as 'translate' | 'rotate' | 'scale';
      setTransformMode(mode);
    };

    window.addEventListener('transform:setMode', handleTransformModeChange as EventListener);
    return () => {
      window.removeEventListener('transform:setMode', handleTransformModeChange as EventListener);
    };
  }, []);

  useEffect(() => {
    console.log('Effect: renderCounter changed to', renderCounter);
    if (rendererRef.current && sceneRef.current && cameraRef.current) {
      rendererRef.current.render(sceneRef.current, cameraRef.current);
    }
  }, [renderCounter]);

  // 监听撤销贴花事件
  useEffect(() => {
    const handleUndoDecalMeshes = (e: CustomEvent<{ meshNames: string[]; modelId: string }>) => {
      const { meshNames, modelId } = e.detail;
      console.log('📡 Received undo-decal-meshes event:', meshNames);
      
      if (!sceneRef.current) {
        console.warn('Scene not ready for decal removal');
        return;
      }

      // 找到指定的模型
      const model = models.find(m => m.id === modelId);
      if (!model?.objectRef) {
        console.warn('Model not found for decal removal:', modelId);
        return;
      }

      // 遍历模型，删除指定的贴花
      let removedCount = 0;
      model.objectRef.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          // 检查是否是贴花
          if (child.userData.isDecal && meshNames.includes(child.name)) {
            // 从父节点移除
            child.parent?.remove(child);
            // 清理资源
            child.geometry?.dispose();
            if (child.material instanceof THREE.Material) {
              child.material.dispose();
            }
            removedCount++;
          }
        }
      });

      console.log(`✅ Removed ${removedCount} decal meshes`);
      
      // 强制重新渲染
      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };

    // 监听删除指定标签的贴花事件
    const handleRemoveDecalByLabel = (e: CustomEvent<{ labelId: string }>) => {
      const { labelId } = e.detail;
      console.log('📡 Received remove-decal-mesh event for label:', labelId);
      
      if (!sceneRef.current) return;

      // 遍历所有模型，删除与该标签关联的贴花
      let removedCount = 0;
      models.forEach(model => {
        if (!model.objectRef) return;
        
        model.objectRef.traverse((child) => {
          if (child instanceof THREE.Mesh && child.userData.isDecal && child.userData.labelId === labelId) {
            child.parent?.remove(child);
            child.geometry?.dispose();
            if (child.material instanceof THREE.Material) {
              child.material.dispose();
            }
            removedCount++;
          }
        });
      });

      console.log(`✅ Removed ${removedCount} decals for label:`, labelId);
      
      // 强制重新渲染
      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };

    window.addEventListener('undo-decal-meshes', handleUndoDecalMeshes as EventListener);
    window.addEventListener('remove-decal-mesh', handleRemoveDecalByLabel as EventListener);

    return () => {
      window.removeEventListener('undo-decal-meshes', handleUndoDecalMeshes as EventListener);
      window.removeEventListener('remove-decal-mesh', handleRemoveDecalByLabel as EventListener);
    };
  }, [models]);

  // 导出加载模型函数供父组件使用
  const loadModelRef = useRef(loadModel);
  loadModelRef.current = loadModel;

  // 暴露导入功能给父组件
  useEffect(() => {
    if (onImportModel) {
      (window as any).loadModel = async (file: File) => {
        const url = URL.createObjectURL(file);

        // 检查是否已有模型在 [0,0,0]
        let position: [number, number, number] = [0, 0, 0];
        const hasModelAtOrigin = models.some((m) =>
          m.position[0] === 0 && m.position[1] === 0 && m.position[2] === 0
        );

        if (hasModelAtOrigin) {
          const maxX = Math.max(...models.map((m) => m.position[0]));
          position = [maxX + 2, 0, 0];
        }

        console.log(`Importing model at position: [${position}]`);
        await loadModelRef.current(url, file.name.replace(/\.[^/.]+$/, ''), position);
        forceSceneUpdate();
      };
    }

    return () => {
      delete (window as any).loadModel;
    };
  }, [onImportModel, models, forceSceneUpdate]);

  if (!isClient) {
    return (
      <div className="flex items-center justify-center h-full bg-gradient-to-b from-background to-background/50">
        <div className="text-sm text-muted-foreground/60">Initializing...</div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full">
      {sceneReady && <LayerPanel scene={sceneRef.current} onSceneUpdate={forceSceneUpdate} />}

      <canvas
        ref={canvasRef}
        className="w-full h-full bg-gradient-to-b from-background to-background/50 cursor-pointer"
        onMouseDown={handleCanvasMouseDown}
        onMouseMove={handleCanvasMouseMove}
        onMouseUp={handleCanvasMouseUp}
        onMouseLeave={handleCanvasMouseLeave}
        onClick={handleCanvasClick}
      />

      {isLoading && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/80 backdrop-blur-sm z-20">
          <div className="w-16 h-16 border-4 border-violet-500/20 border-t-violet-500 rounded-full animate-spin mb-4" />
          <div className="text-white font-medium mb-2">
            {loadingProgress > 0 ? `Loading... ${Math.round(loadingProgress)}%` : 'Loading model...'}
          </div>
          <div className="w-48 h-1 bg-border/20 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-violet-500 to-indigo-500 transition-all duration-300"
              style={{ width: `${loadingProgress}%` }}
            />
          </div>
        </div>
      )}
    </div>
  );
}
