'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { useCanvasStore, Layer } from '@/store/canvasStore';
import { Layer3DViewer } from '@/components/Layer3DViewer';
import { ImagePlus } from 'lucide-react';

interface LayerRendererProps {
  layer: Layer;
  isActive: boolean;
  onRotationChange?: (layerId: string, rotation: { x: number; y: number; z: number }) => void;
  width: number;
  height: number;
}

function LayerRenderer({ layer, isActive, onRotationChange, width, height }: LayerRendererProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const ctxRef = useRef<CanvasRenderingContext2D | null>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);

  const renderLayer = useCallback(() => {
    if (layer.type === '3d') return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    ctxRef.current = ctx;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Render background image
    if ((layer.type === 'background' || layer.type === 'image') && layer.backgroundImage) {
      if (imgRef.current && imgRef.current.complete) {
        ctx.globalAlpha = 1;
        ctx.drawImage(imgRef.current, 0, 0, canvas.width, canvas.height);
      }
    }

    // Render strokes
    layer.strokes.forEach((stroke) => {
      ctx.globalAlpha = stroke.opacity;
      ctx.strokeStyle = stroke.tool === 'eraser' ? '#ffffff' : stroke.color;
      ctx.lineWidth = stroke.size;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      if (stroke.points.length < 2) return;

      ctx.beginPath();
      ctx.moveTo(stroke.points[0].x, stroke.points[0].y);

      for (let i = 1; i < stroke.points.length; i++) {
        ctx.lineTo(stroke.points[i].x, stroke.points[i].y);
      }

      ctx.stroke();
    });

    ctx.globalAlpha = 1;
  }, [layer]);

  // Load image and render
  useEffect(() => {
    if (layer.type === '3d') return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    // Load image if needed
    if ((layer.type === 'background' || layer.type === 'image') && layer.backgroundImage) {
      const img = new Image();
      img.src = layer.backgroundImage;
      
      const handleLoad = () => {
        imgRef.current = img;
        renderLayer();
      };

      if (img.complete) {
        imgRef.current = img;
        renderLayer();
      } else {
        img.onload = handleLoad;
        img.onerror = () => {
          console.error(`Failed to load image for layer ${layer.id}`);
        };
      }
    } else {
      renderLayer();
    }
  }, [layer, renderLayer]);

  // Re-render when layer changes
  useEffect(() => {
    if (layer.type === '3d') return;
    renderLayer();
  }, [layer.strokes, layer.visible, renderLayer]);

  // 3D layer rendering
  if (layer.type === '3d' && layer.modelUrl) {
    return (
      <Layer3DViewer
        modelUrl={layer.modelUrl}
        rotation={layer.modelTransform?.rotation || { x: 0, y: 0, z: 0 }}
        scale={layer.modelTransform?.scale || 1}
        isActive={isActive}
        onRotationChange={(rotation) => onRotationChange?.(layer.id, rotation)}
        width={width}
        height={height}
      />
    );
  }

  // 2D layer rendering
  return (
    <canvas
      ref={canvasRef}
      width={width}
      height={height}
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        pointerEvents: 'none',
      }}
    />
  );
}

export default function MultiLayerCanvas() {
  const { canvasData, toolState, addStroke, saveHistory } = useCanvasStore();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const ctxRef = useRef<CanvasRenderingContext2D | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentPoints, setCurrentPoints] = useState<{ x: number; y: number }[]>([]);
  const [startPoint, setStartPoint] = useState<{ x: number; y: number } | null>(null);

  const activeLayerId = canvasData.activeLayerId;
  const containerRef = useRef<HTMLDivElement>(null);

  // Initialize drawing canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    ctxRef.current = ctx;
  }, []);

  const handleRotationChange = (layerId: string, rotation: { x: number; y: number; z: number }) => {
    // Update rotation in store
    const layer = canvasData.layers.find((l) => l.id === layerId);
    if (layer?.modelTransform) {
      useCanvasStore.getState().updateLayerModelTransform(layerId, { rotation });
    }
  };

  // Handle mouse down
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    // Check if there's an active layer
    if (!activeLayerId) {
      console.warn('No active layer selected');
      return;
    }

    // Check if active layer is locked
    const activeLayer = canvasData.layers.find((l) => l.id === activeLayerId);
    if (activeLayer?.locked) {
      console.warn('Active layer is locked');
      return;
    }

    // Check if active layer is a 3D layer
    if (activeLayer?.type === '3d') {
      console.warn('Cannot draw on 3D layer');
      return;
    }

    setIsDrawing(true);

    if (toolState.tool === 'rectangle' || toolState.tool === 'circle' || toolState.tool === 'line') {
      setStartPoint({ x, y });
      setCurrentPoints([{ x, y }]);
    } else {
      setCurrentPoints([{ x, y }]);
    }
  };

  // Handle mouse move
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;

    const canvas = canvasRef.current;
    const ctx = ctxRef.current;
    if (!canvas || !ctx) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    if (toolState.tool === 'pen' || toolState.tool === 'eraser') {
      // Freehand drawing
      setCurrentPoints((prev) => [...prev, { x, y }]);

      // Render in real-time
      ctx.globalAlpha = toolState.brushOpacity;
      ctx.strokeStyle = toolState.tool === 'eraser' ? '#ffffff' : toolState.brushColor;
      ctx.lineWidth = toolState.brushSize;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      if (currentPoints.length > 0) {
        ctx.beginPath();
        ctx.moveTo(currentPoints[currentPoints.length - 1].x, currentPoints[currentPoints.length - 1].y);
        ctx.lineTo(x, y);
        ctx.stroke();
      }
    } else if (toolState.tool === 'rectangle' || toolState.tool === 'circle' || toolState.tool === 'line') {
      // Shape preview
      setCurrentPoints((prev) => [...prev.slice(0, 1), { x, y }]);

      // Draw shape preview on top
      ctx.globalAlpha = toolState.brushOpacity;
      ctx.strokeStyle = toolState.brushColor;
      ctx.lineWidth = toolState.brushSize;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      if (startPoint) {
        ctx.beginPath();
        if (toolState.tool === 'rectangle') {
          const width = x - startPoint.x;
          const height = y - startPoint.y;
          ctx.rect(startPoint.x, startPoint.y, width, height);
        } else if (toolState.tool === 'circle') {
          const radius = Math.sqrt(Math.pow(x - startPoint.x, 2) + Math.pow(y - startPoint.y, 2));
          ctx.arc(startPoint.x, startPoint.y, radius, 0, Math.PI * 2);
        } else if (toolState.tool === 'line') {
          ctx.moveTo(startPoint.x, startPoint.y);
          ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
    }

    ctx.globalAlpha = 1;
  };

  // Handle mouse up
  const handleMouseUp = () => {
    if (!isDrawing) return;

    setIsDrawing(false);

    if (currentPoints.length > 0 && activeLayerId) {
      // Add stroke to store
      addStroke({
        points: currentPoints,
        color: toolState.brushColor,
        size: toolState.brushSize,
        opacity: toolState.brushOpacity,
        layerId: activeLayerId,
        tool: toolState.tool,
      });

      saveHistory();
    }

    setCurrentPoints([]);
    setStartPoint(null);

    // Clear the preview canvas
    const canvas = canvasRef.current;
    const ctx = ctxRef.current;
    if (canvas && ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  const width = canvasData.width;
  const height = canvasData.height;

  // Drag and drop state
  const [isDragOver, setIsDragOver] = useState(false);

  // Handle drag over
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    // Check if dragging an image
    if (e.dataTransfer.types.includes('Files') || e.dataTransfer.types.includes('text/uri-list')) {
      setIsDragOver(true);
      e.dataTransfer.dropEffect = 'copy';
    }
  };

  // Handle drag leave
  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  };

  // Handle drop
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);

    const { addLayerFromImage, saveHistory } = useCanvasStore.getState();

    // Handle file drop
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (event) => {
          const imageData = event.target?.result as string;
          if (imageData) {
            const layerName = file.name.replace(/\.[^/.]+$/, '');
            addLayerFromImage(layerName, imageData);
            saveHistory();
          }
        };
        reader.readAsDataURL(file);
      }
      return;
    }

    // Handle URL drop (e.g., from browser)
    const uriList = e.dataTransfer.getData('text/uri-list');
    if (uriList) {
      // Fetch image from URL
      fetch(uriList)
        .then((response) => response.blob())
        .then((blob) => {
          const reader = new FileReader();
          reader.onload = (event) => {
            const imageData = event.target?.result as string;
            if (imageData) {
              addLayerFromImage('Dropped Image', imageData);
              saveHistory();
            }
          };
          reader.readAsDataURL(blob);
        })
        .catch((error) => {
          console.error('Failed to load dropped image:', error);
        });
    }
  };

  return (
    <div 
      ref={containerRef} 
      className="relative w-full h-full"
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {/* Drag Over Indicator */}
      {isDragOver && (
        <div className="absolute inset-0 z-[9998] bg-violet-500/10 backdrop-blur-sm border-2 border-dashed border-violet-500 rounded-lg flex items-center justify-center pointer-events-none">
          <div className="flex flex-col items-center gap-2 text-violet-400">
            <ImagePlus className="w-12 h-12" />
            <span className="text-sm font-medium">Drop image here</span>
          </div>
        </div>
      )}

      {/* Layer Rendering */}
      {canvasData.layers
        .sort((a, b) => a.zIndex - b.zIndex)
        .map((layer) => (
          <div
            key={layer.id}
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: '100%',
              zIndex: layer.zIndex,
              opacity: layer.visible ? 1 : 0,
              pointerEvents: layer.type === '3d' && layer.id === activeLayerId ? 'auto' : 'none',
            }}
          >
            <LayerRenderer
              layer={layer}
              isActive={layer.id === activeLayerId}
              onRotationChange={handleRotationChange}
              width={width}
              height={height}
            />
          </div>
        ))}

      {/* Drawing Canvas (Top Layer) */}
      <canvas
        ref={canvasRef}
        width={width}
        height={height}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          zIndex: 9999,
          pointerEvents: activeLayerId && !canvasData.layers.find(l => l.id === activeLayerId)?.locked && canvasData.layers.find(l => l.id === activeLayerId)?.type !== '3d' ? 'auto' : 'none',
        }}
      />
    </div>
  );
}
