'use client';

import { useState } from 'react';
import { useSceneStore } from '@/store/sceneStore';
import { Sparkles, Zap, Circle } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';

type PostProcessTab = 'bloom' | 'vignette';

interface PostProcessingPanelProps {
  scene?: any;
}

export function PostProcessingPanel({ scene }: PostProcessingPanelProps) {
  const { postProcessing, updatePostProcessing } = useSceneStore();
  const [activeTab, setActiveTab] = useState<PostProcessTab>('bloom');

  const handleEnabledChange = (enabled: boolean) => {
    updatePostProcessing({ enabled });
  };

  const handleBloomEnabledChange = (enabled: boolean) => {
    updatePostProcessing({
      bloom: { ...postProcessing.bloom, enabled },
    });
  };

  const handleBloomParamChange = (param: 'intensity' | 'threshold' | 'radius', value: number[]) => {
    updatePostProcessing({
      bloom: { ...postProcessing.bloom, [param]: value[0] },
    });
  };

  const handleVignetteEnabledChange = (enabled: boolean) => {
    updatePostProcessing({
      vignette: { ...postProcessing.vignette, enabled },
    });
  };

  const handleVignetteParamChange = (param: 'darkness' | 'offset', value: number[]) => {
    updatePostProcessing({
      vignette: { ...postProcessing.vignette, [param]: value[0] },
    });
  };

  return (
    <div className="flex flex-col h-full">
      {/* Enable Post Processing */}
      <div className="flex-shrink-0 p-4 border-b border-white/10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-violet-400" />
            <span className="text-sm font-medium text-white">Enable Post Processing</span>
          </div>
          <Switch
            checked={postProcessing.enabled}
            onCheckedChange={handleEnabledChange}
          />
        </div>
        <p className="text-xs text-white/50 mt-1 ml-6">
          Enable post-processing effects for enhanced visual quality
        </p>
      </div>

      {/* Post Processing Content */}
      <div className="flex-1 flex flex-col">
        {!postProcessing.enabled ? (
          <div className="flex-1 flex items-center justify-center text-white/30">
            <div className="text-center">
              <Sparkles className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p className="text-sm font-medium">Post Processing Disabled</p>
              <p className="text-xs opacity-60 mt-1">
                Enable post processing to use effects
              </p>
            </div>
          </div>
        ) : (
          <>
            {/* Tab Headers */}
            <div className="flex border-b border-white/10">
              <button
                onClick={() => setActiveTab('bloom')}
                className={`flex-1 px-4 py-3 text-xs font-medium transition-colors flex items-center justify-center gap-2 ${
                  activeTab === 'bloom'
                    ? 'text-violet-400 border-b-2 border-violet-400'
                    : 'text-white/50 hover:text-white/80'
                }`}
              >
                <Zap className="w-4 h-4" />
                Bloom
              </button>
              <button
                onClick={() => setActiveTab('vignette')}
                className={`flex-1 px-4 py-3 text-xs font-medium transition-colors flex items-center justify-center gap-2 ${
                  activeTab === 'vignette'
                    ? 'text-violet-400 border-b-2 border-violet-400'
                    : 'text-white/50 hover:text-white/80'
                }`}
              >
                <Circle className="w-4 h-4" />
                Vignette
              </button>
            </div>

            {/* Tab Content */}
            <div className="flex-1 overflow-y-auto p-4">
              {/* Bloom Tab */}
              {activeTab === 'bloom' && (
                <div className="space-y-6">
                  {/* Enable Bloom */}
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-white/80">Enable Bloom</Label>
                      <p className="text-xs text-white/50 mt-0.5">
                        Add a glowing effect to bright areas
                      </p>
                    </div>
                    <Switch
                      checked={postProcessing.bloom.enabled}
                      onCheckedChange={handleBloomEnabledChange}
                    />
                  </div>

                  {postProcessing.bloom.enabled && (
                    <>
                      {/* Intensity */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label className="text-white/80">Intensity</Label>
                          <span className="text-xs text-violet-400">
                            {postProcessing.bloom.intensity.toFixed(2)}
                          </span>
                        </div>
                        <Slider
                          value={[postProcessing.bloom.intensity]}
                          onValueChange={(value) => handleBloomParamChange('intensity', value)}
                          min={0}
                          max={3}
                          step={0.01}
                        />
                      </div>

                      {/* Threshold */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label className="text-white/80">Threshold</Label>
                          <span className="text-xs text-violet-400">
                            {postProcessing.bloom.threshold.toFixed(2)}
                          </span>
                        </div>
                        <Slider
                          value={[postProcessing.bloom.threshold]}
                          onValueChange={(value) => handleBloomParamChange('threshold', value)}
                          min={0}
                          max={1}
                          step={0.01}
                        />
                        <p className="text-xs text-white/40">
                          Only areas brighter than this value will glow
                        </p>
                      </div>

                      {/* Radius */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label className="text-white/80">Radius</Label>
                          <span className="text-xs text-violet-400">
                            {postProcessing.bloom.radius.toFixed(2)}
                          </span>
                        </div>
                        <Slider
                          value={[postProcessing.bloom.radius]}
                          onValueChange={(value) => handleBloomParamChange('radius', value)}
                          min={0}
                          max={1}
                          step={0.01}
                        />
                        <p className="text-xs text-white/40">
                          Controls the spread of the bloom effect
                        </p>
                      </div>
                    </>
                  )}
                </div>
              )}

              {/* Vignette Tab */}
              {activeTab === 'vignette' && (
                <div className="space-y-6">
                  {/* Enable Vignette */}
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-white/80">Enable Vignette</Label>
                      <p className="text-xs text-white/50 mt-0.5">
                        Add darkened corners for cinematic effect
                      </p>
                    </div>
                    <Switch
                      checked={postProcessing.vignette.enabled}
                      onCheckedChange={handleVignetteEnabledChange}
                    />
                  </div>

                  {postProcessing.vignette.enabled && (
                    <>
                      {/* Darkness */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label className="text-white/80">Darkness</Label>
                          <span className="text-xs text-violet-400">
                            {postProcessing.vignette.darkness.toFixed(2)}
                          </span>
                        </div>
                        <Slider
                          value={[postProcessing.vignette.darkness]}
                          onValueChange={(value) => handleVignetteParamChange('darkness', value)}
                          min={0}
                          max={2}
                          step={0.01}
                        />
                        <p className="text-xs text-white/40">
                          Controls the darkness of the vignette
                        </p>
                      </div>

                      {/* Offset */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label className="text-white/80">Offset</Label>
                          <span className="text-xs text-violet-400">
                            {postProcessing.vignette.offset.toFixed(2)}
                          </span>
                        </div>
                        <Slider
                          value={[postProcessing.vignette.offset]}
                          onValueChange={(value) => handleVignetteParamChange('offset', value)}
                          min={0}
                          max={2}
                          step={0.01}
                        />
                        <p className="text-xs text-white/40">
                          Controls the size of the vignette area
                        </p>
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
