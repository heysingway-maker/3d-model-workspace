'use client';

import { useState, useEffect } from 'react';
import {
  X,
  Settings,
  Sparkles,
  Lightbulb,
  Sun,
  Type,
  Box,
  Palette,
} from 'lucide-react';
import { TransformPanel } from './TransformPanel';
import { MaterialPanel } from './MaterialPanel';
import { LightingPanel } from './LightingPanel';
import { EnvironmentPanel } from './EnvironmentPanel';
import { PostProcessingPanel } from './PostProcessingPanel';
import { TextLabelsPanel } from './TextLabelsPanel';

export type ToolType = 'transform' | 'material' | 'light' | 'environment' | 'post' | 'text' | null;

import * as THREE from 'three';

interface RightPanelProps {
  activeTool: ToolType;
  onClose: () => void;
  scene?: THREE.Scene | null;
}

// 工具类型到标题和图标的映射
const toolConfig = {
  transform: {
    title: 'Transform',
    icon: Box,
    description: 'Position, Rotation, Scale',
  },
  material: {
    title: 'Material',
    icon: Palette,
    description: '',
  },
  light: {
    title: 'Lighting',
    icon: Lightbulb,
    description: 'Intensity, Color, Position',
  },
  environment: {
    title: 'Environment',
    icon: Sun,
    description: 'Background, Fog, Environment Map',
  },
  post: {
    title: 'Post Processing',
    icon: Sparkles,
    description: 'Bloom, Color Grading, Effects',
  },
  text: {
    title: 'Text & Labels',
    icon: Type,
    description: 'Add and edit text overlays',
  },
};

export function RightPanel({ activeTool, onClose, scene }: RightPanelProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  // 当 activeTool 改变时，自动展开面板
  useEffect(() => {
    if (activeTool) {
      setIsCollapsed(false);
    }
  }, [activeTool]);

  if (!activeTool) return null;

  const config = toolConfig[activeTool];
  const Icon = config.icon;

  return (
    <>
      {isCollapsed ? (
        <button
          onClick={() => setIsCollapsed(false)}
          className="fixed top-20 right-4 z-50 w-10 h-10 rounded-lg bg-black/40 backdrop-blur-xl border border-white/10 flex items-center justify-center text-white hover:bg-black/60 transition-colors"
          title={`展开${config.title}面板`}
        >
          <Icon className="w-5 h-5 text-violet-400" />
        </button>
      ) : (
        <div className="fixed top-20 right-4 z-50 w-80 h-[calc(100vh-8rem)] min-h-[400px] flex flex-col bg-black/40 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl overflow-hidden">
          {/* 标题栏 */}
          <div className="flex-shrink-0 flex items-center justify-between px-4 py-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Icon className="w-4 h-4 text-violet-400" />
              <span className="text-white font-medium text-sm">{config.title}</span>
            </div>
            <button
              onClick={() => {
                setIsCollapsed(true);
                onClose();
              }}
              className="p-1 rounded hover:bg-white/10 text-white/50 hover:text-white transition-colors"
              title="收缩面板"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* 描述栏 */}
          {config.description && (
            <div className="flex-shrink-0 px-4 py-2 border-b border-white/5 bg-white/5">
              <p className="text-xs text-muted-foreground/60">{config.description}</p>
            </div>
          )}

          {/* 内容区域 */}
          <div className="flex-1 overflow-y-auto custom-scrollbar">
            {activeTool === 'transform' ? (
              <TransformPanel />
            ) : activeTool === 'material' ? (
              <MaterialPanel />
            ) : activeTool === 'light' ? (
              <LightingPanel scene={scene ?? null} />
            ) : activeTool === 'environment' ? (
              <EnvironmentPanel scene={scene ?? null} />
            ) : activeTool === 'post' ? (
              <PostProcessingPanel scene={scene ?? null} />
            ) : activeTool === 'text' ? (
              <TextLabelsPanel scene={scene ?? null} />
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-white/30 text-center p-4">
                <Settings className="w-12 h-12 mb-4 opacity-50" />
                <p className="text-sm font-medium mb-1">{config.title} Panel</p>
                <p className="text-xs opacity-60">功能开发中...</p>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
