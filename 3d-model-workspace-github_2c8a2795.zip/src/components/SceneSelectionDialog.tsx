'use client';

import { useState } from 'react';
import { X, Sparkles, Store, MonitorPlay } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useAIMuseumStore, PRESET_SCENES, MuseumScene } from '@/store/aimuseumStore';

interface SceneSelectionDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SceneSelectionDialog({ isOpen, onClose }: SceneSelectionDialogProps) {
  const { selectScene } = useAIMuseumStore();
  const [selectedCategory, setSelectedCategory] = useState<'exhibition' | 'store'>('exhibition');

  const filteredScenes = PRESET_SCENES.filter(scene => scene.category === selectedCategory);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <Card className="w-full max-w-5xl max-h-[90vh] border border-border/20 bg-gray-900/95 backdrop-blur-md">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-violet-500/30">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-semibold text-white">AI Museum Mode</h2>
              <p className="text-sm text-gray-400">Select a scene for cinematic product showcase</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5 text-gray-400" />
          </Button>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center justify-center gap-2 p-6 pb-0">
          <button
            onClick={() => setSelectedCategory('exhibition')}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all ${
              selectedCategory === 'exhibition'
                ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-500/25'
                : 'bg-gray-800/50 text-gray-400 hover:text-white hover:bg-gray-800'
            }`}
          >
            <MonitorPlay className="w-4 h-4" />
            Exhibition Scene
          </button>
          <button
            onClick={() => setSelectedCategory('store')}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all ${
              selectedCategory === 'store'
                ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-500/25'
                : 'bg-gray-800/50 text-gray-400 hover:text-white hover:bg-gray-800'
            }`}
          >
            <Store className="w-4 h-4" />
            Store Scene
          </button>
        </div>

        {/* Scene Grid */}
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          {selectedCategory === 'exhibition' && (
            <p className="text-sm text-gray-400 mb-4 text-center">
              Exhibition scenes for elegant product presentation
            </p>
          )}
          {selectedCategory === 'store' && (
            <p className="text-sm text-gray-400 mb-4 text-center">
              Store scenes for immersive retail experience
            </p>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredScenes.map((scene) => (
              <SceneCard key={scene.id} scene={scene} onSelect={selectScene} />
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}

interface SceneCardProps {
  scene: MuseumScene;
  onSelect: (scene: MuseumScene) => void;
}

function SceneCard({ scene, onSelect }: SceneCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <button
      onClick={() => onSelect(scene)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative w-full"
    >
      <Card
        className={`overflow-hidden border transition-all ${
          isHovered
            ? 'border-violet-500/50 shadow-lg shadow-violet-500/20 scale-105'
            : 'border-border/10 hover:border-border/20'
        }`}
      >
        {/* Preview Image Placeholder */}
        <div className="relative aspect-square bg-gradient-to-br from-gray-800 to-gray-900 overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-3 rounded-full bg-gradient-to-br from-violet-500/20 to-indigo-500/20 flex items-center justify-center">
                <Sparkles className="w-8 h-8 text-violet-400/60" />
              </div>
              <p className="text-xs text-gray-500">Scene Preview</p>
            </div>
          </div>
          {/* Category Badge */}
          <div className="absolute top-3 left-3">
            <span className="px-2 py-1 rounded-md text-[10px] font-medium bg-black/40 backdrop-blur-sm text-white">
              {scene.category === 'exhibition' ? 'Exhibition' : 'Store'}
            </span>
          </div>
          {/* Hover Overlay */}
          {isHovered && (
            <div className="absolute inset-0 bg-gradient-to-br from-violet-600/20 to-indigo-600/20 flex items-center justify-center">
              <div className="px-4 py-2 rounded-lg bg-white/10 backdrop-blur-sm border border-white/20">
                <span className="text-sm font-medium text-white">Select Scene</span>
              </div>
            </div>
          )}
        </div>

        {/* Scene Info */}
        <div className="p-4 text-left">
          <h3 className="text-sm font-semibold text-white mb-1">{scene.name}</h3>
          <p className="text-xs text-gray-500 line-clamp-2">{scene.description}</p>
        </div>
      </Card>
    </button>
  );
}
