'use client';

import { useEffect, useState } from 'react';
import { useDecalModeStore } from '@/store/decalModeStore';

export function SelectionBox() {
  const { isSelecting, selectionStart, selectionEnd } = useDecalModeStore();
  const [boxStyle, setBoxStyle] = useState<React.CSSProperties>({});

  useEffect(() => {
    if (isSelecting && selectionStart && selectionEnd) {
      const left = Math.min(selectionStart.x, selectionEnd.x);
      const top = Math.min(selectionStart.y, selectionEnd.y);
      const width = Math.abs(selectionEnd.x - selectionStart.x);
      const height = Math.abs(selectionEnd.y - selectionStart.y);

      setBoxStyle({
        left: `${left}px`,
        top: `${top}px`,
        width: `${width}px`,
        height: `${height}px`,
        display: 'block',
      });
    } else {
      setBoxStyle({ display: 'none' });
    }
  }, [isSelecting, selectionStart, selectionEnd]);

  if (!isSelecting) return null;

  return (
    <div
      style={boxStyle}
      className="fixed z-50 border-2 border-violet-500 bg-violet-500/20 pointer-events-none"
    />
  );
}
