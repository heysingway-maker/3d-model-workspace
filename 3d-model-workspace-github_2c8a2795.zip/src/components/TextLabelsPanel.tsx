'use client';

import { useState, useRef, useEffect } from 'react';
import * as THREE from 'three';
import { Type, Trash2, Image as ImageIcon, Plus, X, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { useSceneStore } from '@/store/sceneStore';

interface TextLabel {
  id: string;
  text: string;
  fontSize: number;
  fontFamily: string;
  textColor: string;
  offsetX: number;
  offsetY: number;
  rotation: number;
  scale: number;
}

interface TextLabelsPanelProps {
  scene?: THREE.Scene | null;
  onMaterialChange?: (uuid: string, data: any) => void;
}

// 支持的字体
const fontFamilies = [
  'Arial',
  'Helvetica',
  'Times New Roman',
  'Courier New',
  'Georgia',
  'Verdana',
  'Impact',
];

export function TextLabelsPanel({ scene }: TextLabelsPanelProps) {
  const { selectedObjectUuid, models, setSelectedObject } = useSceneStore();
  const [labels, setLabels] = useState<TextLabel[]>([]);
  const [selectedLabelId, setSelectedLabelId] = useState<string | null>(null);
  const [isMounted, setIsMounted] = useState(false);

  // 保存原始材质（用于恢复和重新应用标签）
  const originalMaterialsRef = useRef<Map<THREE.Mesh, THREE.Material | THREE.Material[]>>(new Map());
  const [isMaterialSaved, setIsMaterialSaved] = useState(false);

  // 保存文字贴图的 Mesh，用于删除时清理
  const labelMeshesRef = useRef<Map<string, THREE.Mesh[]>>(new Map());

  // 标记组件是否已挂载
  useEffect(() => {
    setIsMounted(true);
    return () => {
      setIsMounted(false);
    };
  }, []);

  // 新标签表单
  const [newText, setNewText] = useState('');
  const [newFontSize, setNewFontSize] = useState(48);
  const [newFontFamily, setNewFontFamily] = useState('Arial');
  const [newTextColor, setNewTextColor] = useState('#000000'); // 默认黑色字体

  const canvasRef = useRef<HTMLCanvasElement>(null);

  // 获取选中的模型（支持选择子对象时查找父模型）
  const selectedModel = models.find(m => m.id === selectedObjectUuid) ||
                        models.find(m => m.objectRef?.uuid === selectedObjectUuid) ||
                        (selectedObjectUuid && models.find(m => {
                          // 查找是否选中的是模型的子对象
          let found = false;
          m.objectRef?.traverse((child) => {
            if (child.uuid === selectedObjectUuid) {
              found = true;
            }
          });
          return found;
        }));

  // 选择模型时保存原始材质
  useEffect(() => {
    if (!selectedModel || typeof selectedModel !== 'object' || !selectedModel.objectRef) {
      originalMaterialsRef.current.clear();
      setIsMaterialSaved(false);
      return;
    }

    // 保存所有 Mesh 的原始材质
    selectedModel.objectRef.traverse((child) => {
      if (child instanceof THREE.Mesh && child.material) {
        if (!originalMaterialsRef.current.has(child)) {
          // 克隆原始材质并保存
          originalMaterialsRef.current.set(child, child.material.clone());
          console.log('💾 Saved original material for mesh:', child.uuid);
        }
      }
    });

    setIsMaterialSaved(true);
  }, [selectedModel && typeof selectedModel === 'object' ? selectedModel.id : '']);

  // 组件卸载时清理所有标签 Mesh
  useEffect(() => {
    return () => {
      console.log('🧹 Cleaning up all label meshes...');
      labelMeshesRef.current.forEach((meshes, labelId) => {
        meshes.forEach(mesh => {
          if (mesh.parent) {
            mesh.parent.remove(mesh);
          }
          mesh.geometry.dispose();
          if (Array.isArray(mesh.material)) {
            mesh.material.forEach(m => m.dispose());
          } else {
            mesh.material.dispose();
          }
        });
      });
      labelMeshesRef.current.clear();
      console.log('✅ All label meshes cleaned up');
    };
  }, []);

  // 调试日志
  useEffect(() => {
    console.log('🏷️ TextLabelsPanel state:', {
      selectedObjectUuid,
      modelsCount: models.length,
      selectedModel: selectedModel ? selectedModel.name : 'none',
      modelIds: models.map(m => ({ name: m.name, id: m.id, objectRefUuid: m.objectRef?.uuid })),
    });
  }, [selectedObjectUuid, models, selectedModel]);

  // 创建文字贴图
  const createTextTexture = (label: TextLabel): THREE.CanvasTexture => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d')!;

    // 设置画布大小
    canvas.width = 1024;
    canvas.height = 512;

    // 背景保持透明，不绘制背景色

    // 绘制文字
    ctx.fillStyle = label.textColor;
    ctx.font = `${label.fontSize}px ${label.fontFamily}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    // 保存状态
    ctx.save();
    // 移动到中心
    ctx.translate(canvas.width / 2, canvas.height / 2);
    // 旋转
    ctx.rotate((label.rotation * Math.PI) / 180);
    // 绘制文字
    ctx.fillText(label.text, 0, 0);
    // 恢复状态
    ctx.restore();

    // 创建纹理
    const texture = new THREE.CanvasTexture(canvas);
    texture.needsUpdate = true;
    return texture;
  };

  // 应用文字贴图到模型
  const applyLabelToModel = (label: TextLabel) => {
    if (!selectedModel || !selectedModel.objectRef || !scene) {
      console.error('No model selected');
      return;
    }

    console.log('🎨 Applying label:', label.text, 'to model:', selectedModel.name);

    // 先移除该标签的旧 Mesh（防止重复）
    removeLabelMeshes(label.id);

    const texture = createTextTexture(label);

    // 设置贴图的偏移和缩放
    // repeat 是重复次数，所以需要用 1/scale
    texture.offset.set(label.offsetX / 100, label.offsetY / 100);
    texture.repeat.set(1 / label.scale, 1 / label.scale);
    texture.needsUpdate = true;

    // 创建文字贴图的 Mesh 数组（用于该标签的所有 Mesh）
    const labelMeshes: THREE.Mesh[] = [];
    let meshCount = 0;

    // 遍历模型的所有 Mesh，为每个 Mesh 创建一个文字覆盖层
    selectedModel.objectRef.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        // 跳过文字 Mesh（MeshBasicMaterial 是文字 Mesh 的特征）
        if (child.material instanceof THREE.MeshBasicMaterial) {
          console.log(`  Skipping text mesh:`, child.uuid);
          return;
        }

        try {
          meshCount++;
          console.log(`  Processing mesh ${meshCount}:`, child.uuid);

          // 检查几何体
          if (!child.geometry) {
            console.warn('    ⚠️ No geometry on mesh');
            return;
          }

          // 创建一个与原 Mesh 相同几何体的文字覆盖层
          let labelMesh: THREE.Mesh | null = null;
          try {
            // 克隆几何体
            const clonedGeometry: THREE.BufferGeometry = child.geometry.clone() as THREE.BufferGeometry;

            // 验证克隆后的几何体是否有效
            if (!clonedGeometry) {
              console.warn('    ⚠️ Cloned geometry is null');
              return;
            }

            // 创建材质
            const material = new THREE.MeshBasicMaterial({
              map: texture,
              transparent: true,
              opacity: 1.0,
              side: THREE.FrontSide,
              depthWrite: false, // 避免深度写入，确保文字浮在模型上方
              blending: THREE.NormalBlending,
            });

            // 创建 Mesh
            labelMesh = new THREE.Mesh(clonedGeometry, material);
          } catch (error) {
            console.error('    ❌ Failed to create labelMesh:', error);
            return;
          }

          // 验证 labelMesh 是否有效
          if (!labelMesh) {
            console.warn('    ⚠️ labelMesh is null');
            return;
          }

          // 验证 labelMesh 是否有效
          if (!labelMesh) {
            console.warn('    ⚠️ labelMesh is null');
            return;
          }

          console.log('    ✅ Created labelMesh:', labelMesh.uuid);

          // 复制变换（位置、旋转、缩放）
          labelMesh.position.copy(child.position);
          labelMesh.rotation.copy(child.rotation);
          labelMesh.scale.copy(child.scale);

          // 设置渲染顺序，确保文字在最上层
          labelMesh.renderOrder = 999;

          // 将文字 Mesh 添加到场景中，作为模型的子对象
          try {
            // 验证组件是否仍然挂载
            if (!isMounted) {
              console.warn('    ⚠️ Component unmounted before adding mesh');
              // 清理资源
              labelMesh.geometry.dispose();
              if (Array.isArray(labelMesh.material)) {
                labelMesh.material.forEach((m: any) => m.dispose());
              } else {
                labelMesh.material.dispose();
              }
              return;
            }

            child.add(labelMesh);
            console.log('    ✅ Added labelMesh to parent');
          } catch (error) {
            console.error('    ❌ Failed to add labelMesh to parent:', error);
            // 清理失败的 Mesh
            try {
              labelMesh.geometry.dispose();
              if (Array.isArray(labelMesh.material)) {
                labelMesh.material.forEach((m: any) => m.dispose());
              } else {
                labelMesh.material.dispose();
              }
            } catch (cleanupError) {
              console.error('    ❌ Failed to cleanup labelMesh:', cleanupError);
            }
            return;
          }

          labelMeshes.push(labelMesh);
        } catch (error) {
          console.error('    ❌ Error creating label mesh:', error);
        }
      }
    });

    // 保存该标签的所有 Mesh
    labelMeshesRef.current.set(label.id, labelMeshes);

    console.log('✅ Label applied to model:', label.text, `Created ${labelMeshes.length} meshes`);
  };

  // 添加新标签
  const handleAddLabel = () => {
    if (!newText.trim()) {
      alert('Please enter text');
      return;
    }

    const newLabel: TextLabel = {
      id: crypto.randomUUID(),
      text: newText,
      fontSize: newFontSize,
      fontFamily: newFontFamily,
      textColor: newTextColor,
      offsetX: 0,
      offsetY: 0,
      rotation: 0,
      scale: 1,
    };

    setLabels([...labels, newLabel]);
    setSelectedLabelId(newLabel.id);

    // 应用到模型
    applyLabelToModel(newLabel);

    // 重置表单
    setNewText('');
  };

  // 删除标签
  const handleDeleteLabel = (id: string) => {
    // 移除标签
    setLabels(labels.filter(l => l.id !== id));
    if (selectedLabelId === id) {
      setSelectedLabelId(null);
    }

    // 移除文字贴图的 Mesh
    const labelMeshes = labelMeshesRef.current.get(id);
    if (labelMeshes) {
      labelMeshes.forEach(mesh => {
        // 验证 Mesh 是否有效
        if (!mesh) {
          console.warn('⚠️ Trying to remove null mesh');
          return;
        }

        try {
          // 从父对象中移除
          if (mesh.parent) {
            mesh.parent.remove(mesh);
          }

          // 释放资源
          if (mesh.geometry) {
            mesh.geometry.dispose();
          }

          if (Array.isArray(mesh.material)) {
            mesh.material.forEach(m => m.dispose());
          } else if (mesh.material) {
            mesh.material.dispose();
          }
        } catch (error) {
          console.error('❌ Error removing label mesh:', error);
        }
      });
      labelMeshesRef.current.delete(id);
    }

    console.log('✅ Label deleted and meshes removed');
  };

  // 移除标签的 Mesh（不修改 labels 状态）
  const removeLabelMeshes = (id: string) => {
    const labelMeshes = labelMeshesRef.current.get(id);
    if (labelMeshes) {
      labelMeshes.forEach(mesh => {
        // 验证 Mesh 是否有效
        if (!mesh) {
          console.warn('⚠️ Trying to remove null mesh');
          return;
        }

        try {
          // 从父对象中移除
          if (mesh.parent) {
            mesh.parent.remove(mesh);
          }

          // 释放资源
          if (mesh.geometry) {
            mesh.geometry.dispose();
          }

          if (Array.isArray(mesh.material)) {
            mesh.material.forEach(m => m.dispose());
          } else if (mesh.material) {
            mesh.material.dispose();
          }
        } catch (error) {
          console.error('❌ Error removing label mesh:', error);
        }
      });
      labelMeshesRef.current.delete(id);
    }
  };

  // 更新标签
  const handleUpdateLabel = (id: string, updates: Partial<TextLabel>) => {
    // 更新标签状态
    const updatedLabels = labels.map(l =>
      l.id === id ? { ...l, ...updates } : l
    );
    setLabels(updatedLabels);

    // 重新创建文字 Mesh（applyLabelToModel 会先移除旧的 Mesh）
    const updatedLabel = updatedLabels.find(l => l.id === id);
    if (updatedLabel) {
      applyLabelToModel(updatedLabel);
    }
  };

  // 选择标签
  const handleSelectLabel = (id: string) => {
    setSelectedLabelId(id);
  };

  if (!selectedModel) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-white/30 text-center px-6">
        <Type className="w-12 h-12 mb-4 opacity-50" />
        <p className="text-sm font-medium mb-2">No Model Selected</p>
        <p className="text-xs opacity-60">
          Select a model or any part of a model to add text labels
        </p>
        {selectedObjectUuid && (
          <p className="text-xs text-yellow-400/70 mt-2">
            Selected UUID: {selectedObjectUuid.slice(0, 8)}...
          </p>
        )}
      </div>
    );
  }

  // 检查是否选择的是子对象（不是模型本身）
  const isChildSelected = selectedObjectUuid !== selectedModel.id && selectedObjectUuid !== selectedModel.objectRef?.uuid;

  return (
    <div className="flex flex-col h-full">
      {/* 当前选中的模型信息 */}
      <div className="p-3 border-b border-white/10 bg-white/5">
        <div className="flex items-center gap-2">
          <Type className="w-4 h-4 text-violet-400" />
          <div>
            <p className="text-xs text-white/60">Selected Model:</p>
            <p className="text-sm font-medium text-white">{selectedModel.name}</p>
          </div>
        </div>
        {isChildSelected && (
          <p className="text-xs text-yellow-400/70 mt-1">
            (Applying to parent model)
          </p>
        )}
      </div>

      {/* 添加新标签 */}
      <div className="p-4 border-b border-white/10 space-y-3">
        <h3 className="text-xs font-medium text-white/60 mb-3 uppercase tracking-wider flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Add New Label
        </h3>

        <div>
          <label className="text-xs text-white/80 mb-1 block">Text</label>
          <input
            type="text"
            value={newText}
            onChange={(e) => setNewText(e.target.value)}
            placeholder="Enter text..."
            className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm placeholder-white/30 focus:outline-none focus:border-violet-500/50"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-white/80 mb-1 block">Font Size</label>
            <input
              type="number"
              value={newFontSize}
              onChange={(e) => setNewFontSize(Number(e.target.value))}
              min="12"
              max="128"
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm focus:outline-none focus:border-violet-500/50"
            />
          </div>

          <div>
            <label className="text-xs text-white/80 mb-1 block">Font Family</label>
            <select
              value={newFontFamily}
              onChange={(e) => setNewFontFamily(e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm focus:outline-none focus:border-violet-500/50"
            >
              {fontFamilies.map(font => (
                <option key={font} value={font}>{font}</option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="text-xs text-white/80 mb-1 block">Text Color</label>
          <div className="flex items-center gap-3">
            <input
              type="color"
              value={newTextColor}
              onChange={(e) => setNewTextColor(e.target.value)}
              className="w-12 h-10 rounded-lg cursor-pointer"
            />
            <span className="text-xs text-white/50">{newTextColor}</span>
          </div>
        </div>

        <Button
          onClick={handleAddLabel}
          className="w-full bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-medium"
        >
          <ImageIcon className="w-4 h-4 mr-2" />
          Add Label to Model
        </Button>
      </div>

      {/* 已添加的标签列表 */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        <h3 className="text-xs font-medium text-white/60 mb-3 uppercase tracking-wider flex items-center gap-2">
          <Type className="w-4 h-4" />
          Active Labels ({labels.length})
        </h3>

        {labels.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-32 text-white/30 text-sm">
            <ImageIcon className="w-8 h-8 mb-2 opacity-50" />
            No labels added yet
          </div>
        ) : (
          <div className="space-y-2">
            {labels.map((label) => {
              const isSelected = selectedLabelId === label.id;
              return (
                <div
                  key={label.id}
                  onClick={() => handleSelectLabel(label.id)}
                  className={`
                    p-3 rounded-lg border transition-all cursor-pointer
                    ${isSelected
                      ? 'bg-violet-500/10 border-violet-500/30'
                      : 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20'
                    }
                  `}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {isSelected && <Check className="w-4 h-4 text-violet-400" />}
                      <span className="text-sm font-medium text-white">
                        {label.text}
                      </span>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteLabel(label.id);
                      }}
                      className="p-1 rounded hover:bg-red-500/20 text-white/50 hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* 标签详情 */}
                  <div className="text-xs text-white/50 space-y-1">
                    <div className="flex justify-between">
                      <span>Font: {label.fontFamily}</span>
                      <span>Size: {label.fontSize}px</span>
                    </div>
                  </div>

                  {/* 展开的调整面板 */}
                  {isSelected && (
                    <div className="mt-3 pt-3 border-t border-white/10 space-y-3">
                      <div>
                        <label className="text-xs text-white/80 mb-1 block">
                          Offset X: {label.offsetX}
                        </label>
                        <Slider
                          value={[label.offsetX]}
                          onValueChange={(value) =>
                            handleUpdateLabel(label.id, { offsetX: value[0] })
                          }
                          min={-50}
                          max={50}
                          step={1}
                          className="w-full"
                        />
                      </div>

                      <div>
                        <label className="text-xs text-white/80 mb-1 block">
                          Offset Y: {label.offsetY}
                        </label>
                        <Slider
                          value={[label.offsetY]}
                          onValueChange={(value) =>
                            handleUpdateLabel(label.id, { offsetY: value[0] })
                          }
                          min={-50}
                          max={50}
                          step={1}
                          className="w-full"
                        />
                      </div>

                      <div>
                        <label className="text-xs text-white/80 mb-1 block">
                          Scale: {label.scale.toFixed(2)}
                        </label>
                        <Slider
                          value={[label.scale]}
                          onValueChange={(value) =>
                            handleUpdateLabel(label.id, { scale: value[0] })
                          }
                          min={0.1}
                          max={3}
                          step={0.1}
                          className="w-full"
                        />
                      </div>

                      <div>
                        <label className="text-xs text-white/80 mb-1 block">
                          Rotation: {label.rotation}°
                        </label>
                        <Slider
                          value={[label.rotation]}
                          onValueChange={(value) =>
                            handleUpdateLabel(label.id, { rotation: value[0] })
                          }
                          min={-180}
                          max={180}
                          step={5}
                          className="w-full"
                        />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
