'use client';

import { useState, useEffect } from 'react';
import * as THREE from 'three';
import { useSceneStore } from '@/store/sceneStore';
import { Move, RotateCw, Maximize, RefreshCw } from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';

export interface TransformData {
  position: [number, number, number];
  rotation: [number, number, number]; // degrees
  scale: [number, number, number];
}

interface TransformPanelProps {
  onTransformChange?: (uuid: string, data: Partial<TransformData>) => void;
}

type TransformMode = 'translate' | 'rotate' | 'scale';

interface TransformTab {
  id: TransformMode;
  label: string;
  icon: React.ElementType;
}

const tabs: TransformTab[] = [
  { id: 'translate', label: 'Move', icon: Move },
  { id: 'rotate', label: 'Rotate', icon: RotateCw },
  { id: 'scale', label: 'Scale', icon: Maximize },
];

export function TransformPanel({ onTransformChange }: TransformPanelProps) {
  const { models, selectedObjectUuid, updateModelProperty } = useSceneStore();
  const [localData, setLocalData] = useState<TransformData>({
    position: [0, 0, 0],
    rotation: [0, 0, 0],
    scale: [1, 1, 1],
  });
  const [transformMode, setTransformMode] = useState<TransformMode>('translate');

  // 获取当前选中的模型（通过 selectedObjectUuid 查找对应的模型）
  const selectedModel = models.find((model) => {
    if (!model.objectRef) return false;
    if (model.objectRef.uuid === selectedObjectUuid) return true;
    if (model.id === selectedObjectUuid) return true;
    // 递归检查子对象
    let found = false;
    model.objectRef.traverse((child) => {
      if (child.uuid === selectedObjectUuid) {
        found = true;
      }
    });
    return found;
  });

  // DEBUG: Log selection state for troubleshooting
  console.log('[TransformPanel] Debug:', { 
    selectedObjectUuid, 
    modelsCount: models.length,
    modelUuids: models.map(m => m.objectRef?.uuid),
    found: !!selectedModel,
    selectedModelName: selectedModel?.name 
  });

  // 当选中模型改变时，更新本地数据
  useEffect(() => {
    if (selectedModel && selectedModel.objectRef) {
      setLocalData({
        position: [
          selectedModel.objectRef.position.x,
          selectedModel.objectRef.position.y,
          selectedModel.objectRef.position.z,
        ],
        rotation: [
          THREE.MathUtils.radToDeg(selectedModel.objectRef.rotation.x),
          THREE.MathUtils.radToDeg(selectedModel.objectRef.rotation.y),
          THREE.MathUtils.radToDeg(selectedModel.objectRef.rotation.z),
        ],
        scale: [
          selectedModel.objectRef.scale.x,
          selectedModel.objectRef.scale.y,
          selectedModel.objectRef.scale.z,
        ],
      });
    }
  }, [selectedModel]);

  // 切换 Transform 模式
  const handleModeChange = (mode: TransformMode) => {
    setTransformMode(mode);
    // 通过事件通知 ModelViewer
    window.dispatchEvent(new CustomEvent('transform:setMode', { detail: mode }));
  };

  // 处理滑动条变化
  const handleSliderChange = (
    type: 'position' | 'rotation' | 'scale',
    axis: 'x' | 'y' | 'z',
    value: number[]
  ) => {
    const numValue = value[0];
    const axisIndex = axis === 'x' ? 0 : axis === 'y' ? 1 : 2;

    setLocalData((prev) => {
      const newData = { ...prev };
      newData[type][axisIndex] = numValue;
      return newData;
    });

    // 直接更新 objectRef
    if (selectedModel && selectedModel.objectRef) {
      if (type === 'position') {
        selectedModel.objectRef.position.setComponent(axisIndex, numValue);
      } else if (type === 'rotation') {
        const rotation = selectedModel.objectRef.rotation;
        if (axisIndex === 0) rotation.x = THREE.MathUtils.degToRad(numValue);
        else if (axisIndex === 1) rotation.y = THREE.MathUtils.degToRad(numValue);
        else if (axisIndex === 2) rotation.z = THREE.MathUtils.degToRad(numValue);
      } else if (type === 'scale') {
        selectedModel.objectRef.scale.setComponent(axisIndex, numValue);
      }
    }

    // 更新模型状态（跳过历史记录）
    if (selectedModel) {
      const path = type;
      const valueArray = localData[type].map((v, i) => (i === axisIndex ? numValue : v));
      updateModelProperty(selectedModel.id, path, valueArray, true);
    }
  };

  // 处理滑动条释放（提交历史记录）
  const handleSliderCommit = (type: 'position' | 'rotation' | 'scale') => {
    if (!selectedModel) return;

    // 提交到历史记录
    updateModelProperty(selectedModel.id, type, localData[type], false);

    // 通知父组件
    if (onTransformChange) {
      onTransformChange(selectedModel.id, {
        [type]: localData[type],
      });
    }
  };

  // 重置当前 Tab 的变换值
  const handleReset = () => {
    if (!selectedModel) return;

    const resetData = { ...localData };

    if (transformMode === 'translate') {
      resetData.position = [0, 0, 0];
      if (selectedModel.objectRef) {
        selectedModel.objectRef.position.set(0, 0, 0);
      }
      updateModelProperty(selectedModel.id, 'position', [0, 0, 0]);
    } else if (transformMode === 'rotate') {
      resetData.rotation = [0, 0, 0];
      if (selectedModel.objectRef) {
        selectedModel.objectRef.rotation.set(0, 0, 0);
      }
      updateModelProperty(selectedModel.id, 'rotation', [0, 0, 0]);
    } else if (transformMode === 'scale') {
      resetData.scale = [1, 1, 1];
      if (selectedModel.objectRef) {
        selectedModel.objectRef.scale.set(1, 1, 1);
      }
      updateModelProperty(selectedModel.id, 'scale', [1, 1, 1]);
    }

    setLocalData(resetData);

    // 通知父组件
    if (onTransformChange) {
      onTransformChange(selectedModel.id, resetData);
    }
  };

  // 如果没有选中模型，显示占位符
  if (!selectedModel) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-white/30 text-center px-6">
        <Move className="w-12 h-12 mb-4 opacity-50" />
        <p className="text-sm font-medium mb-2">No Model Selected</p>
        <p className="text-xs opacity-60">Select an item from the scene to transform</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Tab Buttons */}
      <div className="flex-shrink-0 flex items-center gap-1 p-2 border-b border-white/10">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = transformMode === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => handleModeChange(tab.id)}
              className={`
                flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all
                ${isActive
                  ? 'bg-violet-500/20 border border-violet-500/50 text-violet-300 shadow-lg shadow-violet-500/10'
                  : 'bg-white/5 border border-white/10 text-white/60 hover:bg-white/10 hover:text-white/80'
                }
              `}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Transform Content */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-4">
        {transformMode === 'translate' && (
          <TransformSliderSection
            title="Position"
            data={localData.position}
            type="position"
            onChange={handleSliderChange}
            onCommit={handleSliderCommit}
            min={-10}
            max={10}
            step={0.01}
          />
        )}

        {transformMode === 'rotate' && (
          <TransformSliderSection
            title="Rotation"
            data={localData.rotation}
            type="rotation"
            onChange={handleSliderChange}
            onCommit={handleSliderCommit}
            min={-180}
            max={180}
            step={1}
          />
        )}

        {transformMode === 'scale' && (
          <TransformSliderSection
            title="Scale"
            data={localData.scale}
            type="scale"
            onChange={handleSliderChange}
            onCommit={handleSliderCommit}
            min={0.1}
            max={5}
            step={0.1}
          />
        )}
      </div>

      {/* Reset Button */}
      <div className="flex-shrink-0 pt-4 border-t border-white/10 px-4">
        <Button
          onClick={handleReset}
          variant="outline"
          className="w-full bg-white/5 border-white/10 text-white/70 hover:bg-white/10 hover:text-white hover:border-violet-500/30 hover:shadow-lg hover:shadow-violet-500/10 transition-all"
        >
          <RefreshCw className="w-4 h-4 mr-2" />
          <span className="text-sm">Reset {tabs.find(t => t.id === transformMode)?.label}</span>
        </Button>
      </div>
    </div>
  );
}

interface TransformSliderSectionProps {
  title: string;
  data: [number, number, number];
  type: 'position' | 'rotation' | 'scale';
  onChange: (type: 'position' | 'rotation' | 'scale', axis: 'x' | 'y' | 'z', value: number[]) => void;
  onCommit: (type: 'position' | 'rotation' | 'scale') => void;
  min: number;
  max: number;
  step: number;
}

function TransformSliderSection({
  title,
  data,
  type,
  onChange,
  onCommit,
  min,
  max,
  step,
}: TransformSliderSectionProps) {
  const axes: Array<{ label: string; value: string; color: string }> = [
    { label: 'X', value: 'x', color: 'text-red-400' },
    { label: 'Y', value: 'y', color: 'text-green-400' },
    { label: 'Z', value: 'z', color: 'text-blue-400' },
  ];

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-white/90 text-sm font-medium">{title}</h3>
      </div>

      <div className="space-y-5">
        {axes.map((axis) => {
          const axisIndex = axis.value === 'x' ? 0 : axis.value === 'y' ? 1 : 2;
          return (
            <TransformSlider
              key={axis.value}
              label={axis.label}
              value={data[axisIndex]}
              color={axis.color}
              onChange={(value) => onChange(type, axis.value as 'x' | 'y' | 'z', value)}
              onCommit={() => onCommit(type)}
              min={min}
              max={max}
              step={step}
            />
          );
        })}
      </div>
    </div>
  );
}

interface TransformSliderProps {
  label: string;
  value: number;
  color: string;
  onChange: (value: number[]) => void;
  onCommit: () => void;
  min: number;
  max: number;
  step: number;
}

function TransformSlider({
  label,
  value,
  color,
  onChange,
  onCommit,
  min,
  max,
  step,
}: TransformSliderProps) {
  const [inputValue, setInputValue] = useState(value.toFixed(2));

  // 当 value 从外部变化时，更新输入框的值
  useEffect(() => {
    setInputValue(value.toFixed(2));
  }, [value]);

  // 处理输入框变化
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setInputValue(newValue);

    // 尝试解析数值
    const parsedValue = parseFloat(newValue);
    if (!isNaN(parsedValue)) {
      onChange([parsedValue]);
    }
  };

  // 处理输入框失去焦点或按 Enter
  const handleInputCommit = () => {
    const parsedValue = parseFloat(inputValue);
    if (!isNaN(parsedValue)) {
      // 确保值在范围内
      const clampedValue = Math.max(min, Math.min(max, parsedValue));
      onChange([clampedValue]);
      onCommit();
    } else {
      // 恢复原始值
      setInputValue(value.toFixed(2));
    }
  };

  // 处理键盘事件
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleInputCommit();
    }
  };

  return (
    <div className="space-y-3">
      {/* 标签和当前值显示 */}
      <div className="flex items-center justify-between">
        <span className={`text-xs font-medium ${color}`}>{label}</span>
        <span className="text-xs text-white/60 font-mono">{value.toFixed(2)}</span>
      </div>

      {/* 滑动条 */}
      <Slider
        value={[value]}
        onValueChange={onChange}
        onValueCommit={onCommit}
        min={min}
        max={max}
        step={step}
        className="cursor-pointer"
      />

      {/* 数字输入框 */}
      <div className="relative">
        <input
          type="number"
          value={inputValue}
          onChange={handleInputChange}
          onBlur={handleInputCommit}
          onKeyDown={handleKeyDown}
          min={min}
          max={max}
          step={step}
          className="w-full h-8 px-2 rounded bg-white/5 border border-white/10 text-white text-xs text-right focus:border-violet-500/50 focus:outline-none focus:ring-1 focus:ring-violet-500/30 transition-all hover:border-white/20"
          placeholder="Enter value"
        />
      </div>
    </div>
  );
}
