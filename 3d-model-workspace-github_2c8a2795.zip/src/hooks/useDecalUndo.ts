'use client';

import { useEffect, useCallback } from 'react';
import { useDecalModeStore, MaterialSnapshot } from '@/store/decalModeStore';
import { useSceneStore } from '@/store/sceneStore';
import * as THREE from 'three';

/**
 * 处理贴花撤销的自定义 Hook
 * 监听 CTRL+Z 键盘事件，执行撤销操作
 */
export function useDecalUndo() {
  // 直接从 store 获取状态
  const historyLength = useDecalModeStore((state) => state.history.length);

  // 恢复材质
  const restoreMaterials = useCallback((snapshots: MaterialSnapshot[], modelId: string) => {
    // 每次都从 store 获取最新的 models，避免闭包问题
    const models = useSceneStore.getState().models;
    
    // 找到对应的模型
    const model = models.find(m => m.id === modelId);
    if (!model?.objectRef) {
      console.warn('Model not found for restoration:', modelId);
      return false;
    }

    let restored = false;
    // 遍历所有 mesh，根据快照恢复材质
    model.objectRef.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        const mesh = child as THREE.Mesh;
        const snapshot = snapshots.find(s => s.meshUuid === mesh.uuid);
        
        if (snapshot) {
          try {
            const materialData = JSON.parse(snapshot.materialJson);
            
            // 创建新的材质并恢复属性
            const restoredMaterial = new THREE.MeshStandardMaterial({
              color: materialData.color || 0xffffff,
              opacity: materialData.opacity ?? 1,
              transparent: materialData.transparent ?? false,
              roughness: materialData.roughness ?? 0.5,
              metalness: materialData.metalness ?? 0.1,
              side: THREE.DoubleSide,
            });
            
            mesh.material = restoredMaterial;
            restored = true;
            console.log('✅ Restored material for mesh:', snapshot.meshName);
          } catch (error) {
            console.error('Failed to restore material:', error);
          }
        }
      }
    });
    return restored;
  }, []);

  // 执行撤销操作
  const performUndo = useCallback(() => {
    const state = useDecalModeStore.getState();
    const historyEntries = state.history;
    
    if (historyEntries.length === 0) {
      console.log('No history to undo');
      return;
    }

    const entry = state.undo();
    if (!entry) return;

    console.log('🔄 Performing undo for:', entry.actionType);

    if (entry.actionType === 'full_coverage' || entry.actionType === 'single_decal') {
      // 根据 actionType 决定如何撤销
      if (entry.actionType === 'full_coverage' && entry.materialSnapshots.length > 0) {
        // 全覆盖模式：恢复原始材质
        const success = restoreMaterials(entry.materialSnapshots, entry.modelId);
        if (success) {
          console.log('✅ Undo successful: restored materials');
        }
      }
      
      // 删除贴花 mesh
      if (entry.decalMeshNames && entry.decalMeshNames.length > 0) {
        console.log('🗑️ Undo - removing meshes:', entry.decalMeshNames);
        
        // 通过自定义事件通知 ModelViewer 删除贴花
        window.dispatchEvent(new CustomEvent('undo-decal-meshes', {
          detail: { meshNames: entry.decalMeshNames, modelId: entry.modelId }
        }));
      }
    }
  }, [restoreMaterials]);

  // 键盘事件监听
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // 检测 CTRL+Z (Windows) 或 CMD+Z (Mac)
      if ((e.ctrlKey || e.metaKey) && (e.key === 'z' || e.key === 'Z')) {
        // 检查是否在输入框中
        const target = e.target as HTMLElement;
        if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
          return; // 在输入框中不拦截
        }
        
        // 如果同时按了 Shift，使用 redo（但这里只处理 undo）
        if (e.shiftKey) {
          return; // 让 ModelViewer 的 redo 处理
        }
        
        e.preventDefault();
        e.stopPropagation();
        
        console.log('⌨️ CTRL+Z detected - performing undo');
        performUndo();
      }
    };

    // 使用 capture 模式确保事件能被捕获
    window.addEventListener('keydown', handleKeyDown, true);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown, true);
    };
  }, [performUndo]);

  return {
    canUndo: historyLength > 0,
    historyLength: historyLength,
    performUndo,
  };
}
