import * as THREE from 'three';
import { DecalGeometry } from 'three/examples/jsm/geometries/DecalGeometry.js';

/**
 * Creates a decal mesh from an image and applies it to a model
 */
export async function createDecalFromImage(
  model: THREE.Object3D,
  position: THREE.Vector3,
  normal: THREE.Vector3,
  imageData: string,
  size: number = 0.5,
  rotation: number = 0
): Promise<THREE.Mesh> {
  return new Promise((resolve, reject) => {
    // Find the first mesh in the model
    let targetMesh: THREE.Mesh | null = null;
    model.traverse((child) => {
      if (child instanceof THREE.Mesh && !targetMesh) {
        targetMesh = child;
      }
    });

    if (!targetMesh) {
      reject(new Error('No mesh found in model'));
      return;
    }

    const loader = new THREE.TextureLoader();

    loader.load(
      imageData,
      (texture) => {
        texture.flipY = false;
        texture.colorSpace = THREE.SRGBColorSpace;

        // Create decal material
        const decalMaterial = new THREE.MeshPhongMaterial({
          map: texture,
          transparent: true,
          depthTest: true,
          depthWrite: false,
          polygonOffset: true,
          polygonOffsetFactor: -4,
        });

        // Create decal geometry
        const orientation = new THREE.Euler(0, 0, (rotation * Math.PI) / 180);
        const decalSize = new THREE.Vector3(size, size, size);

        const decalGeometry = new DecalGeometry(
          targetMesh!,
          position,
          orientation,
          decalSize
        );

        // Create decal mesh
        const decalMesh = new THREE.Mesh(decalGeometry, decalMaterial);
        decalMesh.name = 'decal-' + Date.now();

        resolve(decalMesh);
      },
      undefined,
      (error) => {
        reject(error);
      }
    );
  });
}

/**
 * Converts a decal mesh to a permanent mesh by merging with the model
 */
export function convertDecalToMesh(
  model: THREE.Object3D,
  decal: THREE.Mesh
): THREE.BufferGeometry {
  // Get model geometry
  const modelGeometries: THREE.BufferGeometry[] = [];
  model.traverse((child) => {
    if (child instanceof THREE.Mesh && child.geometry) {
      modelGeometries.push(child.geometry.clone());
    }
  });

  // Merge geometries
  const mergedGeometry = mergeGeometries([
    ...modelGeometries,
    decal.geometry as THREE.BufferGeometry,
  ]);

  return mergedGeometry;
}

/**
 * Merges multiple geometries into one
 */
function mergeGeometries(geometries: THREE.BufferGeometry[]): THREE.BufferGeometry {
  // Simple implementation - in production, use BufferGeometryUtils
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];

  geometries.forEach((geometry) => {
    const positionAttr = geometry.getAttribute('position');
    const normalAttr = geometry.getAttribute('normal');
    const uvAttr = geometry.getAttribute('uv');

    if (positionAttr) {
      for (let i = 0; i < positionAttr.count; i++) {
        positions.push(
          positionAttr.getX(i),
          positionAttr.getY(i),
          positionAttr.getZ(i)
        );
      }
    }

    if (normalAttr) {
      for (let i = 0; i < normalAttr.count; i++) {
        normals.push(
          normalAttr.getX(i),
          normalAttr.getY(i),
          normalAttr.getZ(i)
        );
      }
    }

    if (uvAttr) {
      for (let i = 0; i < uvAttr.count; i++) {
        uvs.push(uvAttr.getX(i), uvAttr.getY(i));
      }
    }
  });

  const mergedGeometry = new THREE.BufferGeometry();
  mergedGeometry.setAttribute(
    'position',
    new THREE.Float32BufferAttribute(positions, 3)
  );

  if (normals.length > 0) {
    mergedGeometry.setAttribute(
      'normal',
      new THREE.Float32BufferAttribute(normals, 3)
    );
  }

  if (uvs.length > 0) {
    mergedGeometry.setAttribute(
      'uv',
      new THREE.Float32BufferAttribute(uvs, 2)
    );
  }

  return mergedGeometry;
}

/**
 * Exports a decal mesh as GLB
 */
export async function exportDecalAsGLB(
  decal: THREE.Mesh,
  filename: string = 'decal.glb'
): Promise<Blob> {
  const { GLTFExporter } = await import('three/examples/jsm/exporters/GLTFExporter.js');
  const exporter = new GLTFExporter();

  return new Promise((resolve, reject) => {
    exporter.parse(
      decal,
      (result) => {
        const blob = new Blob([result as ArrayBuffer], {
          type: 'model/gltf-binary',
        });
        resolve(blob);
      },
      (error) => {
        reject(error);
      },
      { binary: true }
    );
  });
}

/**
 * Creates a simple label texture from text
 */
export function createLabelTexture(
  text: string,
  options: {
    width?: number;
    height?: number;
    fontSize?: number;
    fontFamily?: string;
    color?: string;
    backgroundColor?: string;
  } = {}
): THREE.CanvasTexture {
  const {
    width = 512,
    height = 512,
    fontSize = 48,
    fontFamily = 'Arial',
    color = '#ffffff',
    backgroundColor = 'transparent',
  } = options;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Failed to get canvas context');
  }

  // Fill background
  ctx.fillStyle = backgroundColor;
  ctx.fillRect(0, 0, width, height);

  // Draw text
  ctx.fillStyle = color;
  ctx.font = `${fontSize}px ${fontFamily}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, width / 2, height / 2);

  // Create texture
  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;

  return texture;
}

/**
 * Converts a canvas to a data URL
 */
export function canvasToDataUrl(canvas: HTMLCanvasElement): string {
  return canvas.toDataURL('image/png');
}

/**
 * Converts a data URL to a Blob
 */
export function dataUrlToBlob(dataUrl: string): Promise<Blob> {
  return new Promise((resolve) => {
    const binaryString = atob(dataUrl.split(',')[1]);
    const arrayBuffer = new ArrayBuffer(binaryString.length);
    const uint8Array = new Uint8Array(arrayBuffer);

    for (let i = 0; i < binaryString.length; i++) {
      uint8Array[i] = binaryString.charCodeAt(i);
    }

    const blob = new Blob([uint8Array], { type: 'image/png' });
    resolve(blob);
  });
}
