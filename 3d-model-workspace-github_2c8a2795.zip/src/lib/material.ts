import * as THREE from 'three';

export interface MaterialTextures {
  albedo?: string;      // 基础颜色贴图
  normal?: string;      // 法线贴图
  roughness?: string;   // 粗糙度贴图
  metallic?: string;    // 金属度贴图
  ao?: string;          // 环境光遮蔽贴图
  height?: string;      // 高度贴图
  preview?: string;     // 预览图
}

export interface MaterialPreset {
  name: string;
  color?: string;
  metalness?: number;
  roughness?: number;
  textures?: MaterialTextures;
  description?: string;
}

/**
 * 加载 PBR 材质贴图
 */
export async function loadMaterialTextures(textures: MaterialTextures): Promise<Partial<MaterialTextures & {
  albedoTexture: THREE.Texture;
  normalTexture: THREE.Texture;
  roughnessTexture: THREE.Texture;
  metallicTexture: THREE.Texture;
  aoTexture: THREE.Texture;
  heightTexture: THREE.Texture;
}>> {
  const textureLoader = new THREE.TextureLoader();
  const result: any = {};

  const loadTexture = (path?: string): Promise<THREE.Texture | undefined> => {
    if (!path) return Promise.resolve(undefined);
    return new Promise((resolve) => {
      textureLoader.load(path, (texture) => {
        texture.colorSpace = THREE.SRGBColorSpace;
        resolve(texture);
      }, undefined, () => {
        console.warn(`Failed to load texture: ${path}`);
        resolve(undefined);
      });
    });
  };

  // 加载所有贴图
  if (textures.albedo) result.albedoTexture = await loadTexture(textures.albedo);
  if (textures.normal) result.normalTexture = await loadTexture(textures.normal);
  if (textures.roughness) result.roughnessTexture = await loadTexture(textures.roughness);
  if (textures.metallic) result.metallicTexture = await loadTexture(textures.metallic);
  if (textures.ao) result.aoTexture = await loadTexture(textures.ao);
  if (textures.height) result.heightTexture = await loadTexture(textures.height);

  return result;
}

/**
 * 应用贴图材质到 Three.js 材质
 */
export function applyTextureMaterial(
  material: THREE.MeshStandardMaterial,
  textures: Awaited<ReturnType<typeof loadMaterialTextures>>,
  baseColor: string = '#ffffff'
): void {
  // 应用基础颜色
  if (textures.albedoTexture) {
    material.map = textures.albedoTexture;
    material.color.set(0xffffff); // 使用贴图颜色时设为白色
  } else {
    material.color.set(baseColor);
  }

  // 应用法线贴图
  if (textures.normalTexture) {
    material.normalMap = textures.normalTexture;
  }

  // 应用粗糙度贴图
  if (textures.roughnessTexture) {
    material.roughnessMap = textures.roughnessTexture;
  }

  // 应用金属度贴图
  if (textures.metallicTexture) {
    material.metalnessMap = textures.metallicTexture;
  }

  // 应用环境光遮蔽贴图
  if (textures.aoTexture) {
    material.aoMap = textures.aoTexture;
    material.aoMapIntensity = 1.0;
  }

  // 应用高度贴图
  if (textures.heightTexture) {
    material.displacementMap = textures.heightTexture;
    material.displacementScale = 0.05;
  }

  material.needsUpdate = true;
}

/**
 * 青铜材质预设
 */
export const bronzeMaterialPreset: MaterialPreset = {
  name: '青铜质感',
  color: '#cd7f32',
  metalness: 0.9,
  roughness: 0.3,
  textures: {
    albedo: '/assets/bronze_albedo.png',
    normal: '/assets/bronze_normal-ogl.png',
    roughness: '/assets/bronze_roughness.png',
    metallic: '/assets/bronze_metallic.png',
    ao: '/assets/bronze_ao.png',
    height: '/assets/bronze_height.png',
    preview: '/assets/bronze_preview.jpg',
  },
  description: '经典青铜材质，带有丰富的金属质感和细节',
};
