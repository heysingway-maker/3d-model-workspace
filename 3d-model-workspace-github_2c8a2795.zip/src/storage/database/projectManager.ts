import { eq, like, or, desc, SQL } from "drizzle-orm";
import { getDb } from "coze-coding-dev-sdk";
import {
  projects,
  insertProjectSchema,
  updateProjectSchema,
} from "./shared/schema";
import type { Project, InsertProject, UpdateProject } from "./shared/schema";

export class ProjectManager {
  async createProject(data: InsertProject): Promise<Project> {
    const db = await getDb();
    const validated = insertProjectSchema.parse(data);
    const [project] = await db.insert(projects).values(validated).returning();
    return project;
  }

  async getProjects(options: {
    skip?: number;
    limit?: number;
    search?: string;
  } = {}): Promise<Project[]> {
    const { skip = 0, limit = 100, search = "" } = options;
    const db = await getDb();

    if (search) {
      const searchPattern = `%${search}%`;
      return db
        .select()
        .from(projects)
        .where(
          or(
            like(projects.name, searchPattern),
            like(projects.description || "", searchPattern)
          )
        )
        .orderBy(desc(projects.createdAt))
        .limit(limit)
        .offset(skip);
    }

    return db
      .select()
      .from(projects)
      .orderBy(desc(projects.createdAt))
      .limit(limit)
      .offset(skip);
  }

  async getProjectById(id: string): Promise<Project | null> {
    const db = await getDb();
    const [project] = await db
      .select()
      .from(projects)
      .where(eq(projects.id, id));
    return project || null;
  }

  async updateProject(
    id: string,
    data: UpdateProject
  ): Promise<Project | null> {
    const db = await getDb();
    const validated = updateProjectSchema.parse(data);
    const [project] = await db
      .update(projects)
      .set({ ...validated, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return project || null;
  }

  async updateProjectPreview(
    id: string,
    previewKey: string
  ): Promise<Project | null> {
    return this.updateProject(id, { previewKey });
  }

  async updateProjectModelKey(
    id: string,
    modelKey: string
  ): Promise<Project | null> {
    const db = await getDb();
    const [project] = await db
      .update(projects)
      .set({ modelKey, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return project || null;
  }

  async deleteProject(id: string): Promise<boolean> {
    const db = await getDb();
    const result = await db.delete(projects).where(eq(projects.id, id));
    return (result.rowCount ?? 0) > 0;
  }
}

export const projectManager = new ProjectManager();
