import { pgTable, text, varchar, timestamp, index } from "drizzle-orm/pg-core"
import { createSchemaFactory } from "drizzle-zod"
import { z } from "zod"
import { sql } from "drizzle-orm"

export const projects = pgTable(
  "projects",
  {
    id: varchar("id", { length: 64 })
      .primaryKey()
      .default(sql`gen_random_uuid()`),
    name: varchar("name", { length: 255 }).notNull(),
    description: text("description"),
    modelKey: varchar("model_key", { length: 500 }).notNull(),
    previewKey: varchar("preview_key", { length: 500 }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
  },
  (table) => ({
    nameIdx: index("projects_name_idx").on(table.name),
    createdAtIdx: index("projects_created_at_idx").on(table.createdAt),
  })
)

const { createInsertSchema: createCoercedInsertSchema } = createSchemaFactory({
  coerce: { date: true },
})

export const insertProjectSchema = createCoercedInsertSchema(projects).pick({
  name: true,
  description: true,
  modelKey: true,
  previewKey: true,
})

export const updateProjectSchema = createCoercedInsertSchema(projects)
  .pick({
    name: true,
    description: true,
    previewKey: true,
  })
  .partial()

export type Project = typeof projects.$inferSelect
export type InsertProject = z.infer<typeof insertProjectSchema>
export type UpdateProject = z.infer<typeof updateProjectSchema>
