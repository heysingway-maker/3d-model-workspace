import { create } from 'zustand';

// 场景类型
export type SceneCategory = 'exhibition' | 'store';

// 场景定义
export interface MuseumScene {
  id: string;
  name: string;
  category: SceneCategory;
  previewImage: string;
  description: string;
  sceneUrl: string; // 真实的 GLB 场景文件路径
}

// 预设场景
export const PRESET_SCENES: MuseumScene[] = [
  // Exhibition Scenes - 美妆展台
  {
    id: 'exhibition-podium-2',
    name: 'Podium Art No. 2',
    category: 'exhibition',
    previewImage: '/assets/scenes/podium_art_-_no_2.glb',
    description: 'Elegant exhibition podium with minimalist design',
    sceneUrl: '/assets/scenes/podium_art_-_no_2.glb',
  },
  {
    id: 'exhibition-podium-4',
    name: 'Podium Art No. 4',
    category: 'exhibition',
    previewImage: '/assets/scenes/podium_art_-_no_4.glb',
    description: 'Contemporary podium design for premium displays',
    sceneUrl: '/assets/scenes/podium_art_-_no_4.glb',
  },
  {
    id: 'exhibition-minimal-white',
    name: 'Minimal White',
    category: 'exhibition',
    previewImage: '/assets/scenes/exhibition-minimal-white.png',
    description: 'Pure white minimalist exhibition booth with clean lines',
    sceneUrl: '/assets/scenes/podium_art_-_no_2.glb', // Use available scene as fallback
  },
  {
    id: 'exhibition-elegant-marble',
    name: 'Elegant Marble',
    category: 'exhibition',
    previewImage: '/assets/scenes/exhibition-elegant-marble.png',
    description: 'Luxurious marble texture with gold accents',
    sceneUrl: '/assets/scenes/podium_art_-_no_4.glb', // Use available scene as fallback
  },
  // Store Scenes - 美妆零售店
  {
    id: 'store-boutique-luxe',
    name: 'Boutique Luxe',
    category: 'store',
    previewImage: '/assets/scenes/store-boutique-luxe.png',
    description: 'High-end boutique with warm ambient lighting',
    sceneUrl: '/assets/scenes/podium_art_-_no_2.glb', // Use available scene as fallback
  },
  {
    id: 'store-modern-gallery',
    name: 'Modern Gallery',
    category: 'store',
    previewImage: '/assets/scenes/store-modern-gallery.png',
    description: 'Contemporary retail space with geometric displays',
    sceneUrl: '/assets/scenes/podium_art_-_no_4.glb', // Use available scene as fallback
  },
  {
    id: 'store-botanical',
    name: 'Botanical Garden',
    category: 'store',
    previewImage: '/assets/scenes/store-botanical.png',
    description: 'Natural greenery backdrop for organic beauty',
    sceneUrl: '/assets/scenes/podium_art_-_no_2.glb', // Use available scene as fallback
  },
  {
    id: 'store-industrial-chic',
    name: 'Industrial Chic',
    category: 'store',
    previewImage: '/assets/scenes/store-industrial-chic.png',
    description: 'Raw materials and concrete for edgy aesthetics',
    sceneUrl: '/assets/scenes/podium_art_-_no_4.glb', // Use available scene as fallback
  },
];

// 视角快照
export interface ViewSnapshot {
  id: string;
  name: string;
  thumbnail: string;
  cameraPosition: [number, number, number];
  cameraTarget: [number, number, number];
  timestamp: number;
}

// AI Museum 模式类型
export type AIMuseumMode = 'view' | 'move';

// 摄影参数
export interface PhotographyParams {
  contrast: number;
  saturation: number;
  brightness: number;
  exposure: number;
  temperature: number;
}

interface AIMuseumState {
  // AI Museum 模式开关
  isAIMuseumMode: boolean;

  // 切换 AI Museum 模式
  toggleAIMuseumMode: (enabled: boolean) => void;

  // 场景选择
  selectedScene: MuseumScene | null;
  sceneSelectionOpen: boolean;

  // 打开场景选择弹窗
  openSceneSelection: () => void;

  // 关闭场景选择弹窗
  closeSceneSelection: () => void;

  // 选择场景
  selectScene: (scene: MuseumScene) => void;

  // 视角快照列表
  viewSnapshots: ViewSnapshot[];

  // 添加视角快照
  addViewSnapshot: (snapshot: ViewSnapshot) => void;

  // 删除视角快照
  removeViewSnapshot: (id: string) => void;

  // 激活视角快照
  activeSnapshotId: string | null;
  setActiveSnapshot: (id: string | null) => void;

  // AI Museum 模式（view/move）
  mode: AIMuseumMode;

  // 切换模式
  setMode: (mode: AIMuseumMode) => void;

  // 摄影参数
  photographyParams: PhotographyParams;

  // 更新摄影参数
  updatePhotographyParams: (params: Partial<PhotographyParams>) => void;

  // 自定义 HDR
  customHdrUrl: string | null;

  // 设置自定义 HDR
  setCustomHdr: (url: string | null) => void;
}

export const useAIMuseumStore = create<AIMuseumState>((set) => ({
  isAIMuseumMode: false,

  toggleAIMuseumMode: (enabled) =>
    set({ isAIMuseumMode: enabled }),

  selectedScene: null,
  sceneSelectionOpen: false,

  openSceneSelection: () =>
    set({ sceneSelectionOpen: true }),

  closeSceneSelection: () =>
    set({ sceneSelectionOpen: false }),

  selectScene: (scene) =>
    set({
      selectedScene: scene,
      sceneSelectionOpen: false,
      isAIMuseumMode: true, // 选择场景时自动启用 AI Museum 模式
    }),

  viewSnapshots: [],

  addViewSnapshot: (snapshot) =>
    set((state) => ({
      viewSnapshots: [...state.viewSnapshots, snapshot],
    })),

  removeViewSnapshot: (id) =>
    set((state) => ({
      viewSnapshots: state.viewSnapshots.filter((s) => s.id !== id),
      activeSnapshotId: state.activeSnapshotId === id ? null : state.activeSnapshotId,
    })),

  activeSnapshotId: null,

  setActiveSnapshot: (id) =>
    set({ activeSnapshotId: id }),

  mode: 'move', // 默认移动模式

  setMode: (mode) =>
    set({ mode }),

  photographyParams: {
    contrast: 1.0,
    saturation: 1.0,
    brightness: 1.0,
    exposure: 1.0,
    temperature: 1.0,
  },

  updatePhotographyParams: (params) =>
    set((state) => ({
      photographyParams: {
        ...state.photographyParams,
        ...params,
      },
    })),

  customHdrUrl: null,

  setCustomHdr: (url) =>
    set({ customHdrUrl: url }),
}));
