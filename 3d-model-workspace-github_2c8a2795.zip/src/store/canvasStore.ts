import { create } from 'zustand';

export type ToolType = 'pen' | 'eraser' | 'rectangle' | 'circle' | 'line' | 'select';
export type LayerType = 'background' | 'paint' | 'image' | '3d';

export interface Stroke {
  id: string;
  points: { x: number; y: number }[];
  color: string;
  size: number;
  opacity: number;
  layerId: string;
  timestamp: number;
  tool: ToolType;
}

export interface Model3DTransform {
  rotation: { x: number; y: number; z: number };
  scale: number;
}

export interface Layer {
  id: string;
  name: string;
  type: LayerType;
  visible: boolean;
  locked: boolean;
  strokes: Stroke[];
  zIndex: number;
  backgroundImage?: string; // Base64 encoded image for image layers
  modelUrl?: string; // URL for 3D model layers
  modelTransform?: Model3DTransform; // Transform for 3D model layers
}

export interface CanvasData {
  width: number;
  height: number;
  layers: Layer[];
  activeLayerId: string | null;
}

export interface ToolState {
  tool: ToolType;
  brushSize: number;
  brushColor: string;
  brushOpacity: number;
}

interface HistoryItem {
  canvasData: CanvasData;
  timestamp: number;
}

interface CanvasState {
  // Workspace state
  isOpen: boolean;
  canvasData: CanvasData;

  // Tool state
  toolState: ToolState;

  // History state
  history: HistoryItem[];
  historyIndex: number;

  // View state
  zoom: number;

  // Actions
  openWorkspace: () => void;
  closeWorkspace: () => void;
  setCanvasData: (data: Partial<CanvasData>) => void;

  // Tool actions
  setTool: (tool: ToolType) => void;
  setBrushSize: (size: number) => void;
  setBrushColor: (color: string) => void;
  setBrushOpacity: (opacity: number) => void;

  // Layer actions
  addLayer: (name: string, type?: LayerType) => void;
  addLayerFromImage: (name: string, imageData: string) => void;
  addLayerFrom3DModel: (name: string, modelUrl: string) => void;
  updateLayerModelTransform: (layerId: string, transform: Partial<Model3DTransform>) => void;
  deleteLayer: (layerId: string) => void;
  setActiveLayer: (layerId: string | null) => void;
  toggleLayerVisibility: (layerId: string) => void;
  toggleLayerLock: (layerId: string) => void;
  updateLayerOrder: (layerIds: string[]) => void;
  updateLayerBackgroundImage: (layerId: string, imageData: string) => void;

  // Stroke actions
  addStroke: (stroke: Omit<Stroke, 'id' | 'timestamp'>) => void;
  clearLayerStrokes: (layerId: string) => void;

  // History actions
  undo: () => void;
  redo: () => void;
  canUndo: () => boolean;
  canRedo: () => boolean;
  saveHistory: () => void;

  // Export
  exportToImage: (format?: 'png' | 'jpeg') => string | null;
  exportActiveLayerToImage: (format?: 'png' | 'jpeg') => string | null;

  // Zoom actions
  setZoom: (zoom: number) => void;
  zoomIn: () => void;
  zoomOut: () => void;
  resetZoom: () => void;

  // Layer order actions
  moveLayer: (layerId: string, direction: 'up' | 'down') => void;

  // AI Generation state
  aiMode: 'render' | 'make3d';
  aiPrompt: string;
  drawingInfluence: number;
  isGenerating: boolean;
  generatedImage: string | null;
  generatedModelUrl: string | null;

  // AI actions
  setAIMode: (mode: 'render' | 'make3d') => void;
  setAIPrompt: (prompt: string) => void;
  setDrawingInfluence: (value: number) => void;
  setGenerating: (isGenerating: boolean) => void;
  setGeneratedImage: (image: string | null) => void;
  setGeneratedModelUrl: (url: string | null) => void;
  resetAIGeneration: () => void;
  importToStudio: () => void;
}

const initialCanvasData: CanvasData = {
  width: 1920,
  height: 1080,
  layers: [
    {
      id: 'background-layer',
      name: 'Background',
      type: 'background',
      visible: true,
      locked: true,
      strokes: [],
      zIndex: 0,
    },
    {
      id: 'layer-1',
      name: 'Layer 1',
      type: 'paint',
      visible: true,
      locked: false,
      strokes: [],
      zIndex: 1,
    },
  ],
  activeLayerId: 'layer-1',
};

const initialToolState: ToolState = {
  tool: 'pen',
  brushSize: 5,
  brushColor: '#ffffff',
  brushOpacity: 1,
};

export const useCanvasStore = create<CanvasState>((set, get) => ({
  isOpen: false,
  canvasData: initialCanvasData,
  toolState: initialToolState,
  history: [{ canvasData: JSON.parse(JSON.stringify(initialCanvasData)), timestamp: Date.now() }],
  historyIndex: 0,
  zoom: 1,

  // AI Generation state
  aiMode: 'render',
  aiPrompt: '',
  drawingInfluence: 0.7,
  isGenerating: false,
  generatedImage: null,
  generatedModelUrl: null,

  openWorkspace: () => set({ isOpen: true }),
  closeWorkspace: () => set({ isOpen: false }),

  setCanvasData: (data) =>
    set((state) => ({
      canvasData: { ...state.canvasData, ...data },
    })),

  // Tool actions
  setTool: (tool) => set((state) => ({ toolState: { ...state.toolState, tool } })),
  setBrushSize: (size) => set((state) => ({ toolState: { ...state.toolState, brushSize: size } })),
  setBrushColor: (color) => set((state) => ({ toolState: { ...state.toolState, brushColor: color } })),
  setBrushOpacity: (opacity) =>
    set((state) => ({ toolState: { ...state.toolState, brushOpacity: opacity } })),

  // Layer actions
  addLayer: (name, type = 'paint') =>
    set((state) => {
      const newLayer: Layer = {
        id: `layer-${Date.now()}`,
        name,
        type,
        visible: true,
        locked: type === 'background', // Background layer is locked by default
        strokes: [],
        zIndex: state.canvasData.layers.length,
      };
      return {
        canvasData: {
          ...state.canvasData,
          layers: [...state.canvasData.layers, newLayer],
          activeLayerId: newLayer.id,
        },
      };
    }),

  addLayerFromImage: (name, imageData) =>
    set((state) => {
      const newLayer: Layer = {
        id: `layer-${Date.now()}`,
        name,
        type: 'image',
        visible: true,
        locked: false,
        strokes: [],
        zIndex: state.canvasData.layers.length,
        backgroundImage: imageData,
      };
      return {
        canvasData: {
          ...state.canvasData,
          layers: [...state.canvasData.layers, newLayer],
          activeLayerId: newLayer.id,
        },
      };
    }),

  addLayerFrom3DModel: (name: string, modelUrl: string) =>
    set((state) => {
      const newLayer: Layer = {
        id: `layer-${Date.now()}`,
        name,
        type: '3d',
        visible: true,
        locked: false,
        strokes: [],
        zIndex: state.canvasData.layers.length,
        modelUrl,
        modelTransform: {
          rotation: { x: 0, y: 0, z: 0 },
          scale: 1,
        },
      };
      return {
        canvasData: {
          ...state.canvasData,
          layers: [...state.canvasData.layers, newLayer],
          activeLayerId: newLayer.id,
        },
      };
    }),

  updateLayerModelTransform: (layerId, transform) =>
    set((state) => ({
      canvasData: {
        ...state.canvasData,
        layers: state.canvasData.layers.map((l) =>
          l.id === layerId
            ? {
                ...l,
                modelTransform: l.modelTransform
                  ? {
                      ...l.modelTransform,
                      rotation: transform.rotation ?? l.modelTransform.rotation,
                      scale: transform.scale ?? l.modelTransform.scale,
                    }
                  : {
                      rotation: { x: 0, y: 0, z: 0 },
                      scale: 1,
                    },
              }
            : l
        ),
      },
    })),

  updateLayerBackgroundImage: (layerId, imageData) =>
    set((state) => ({
      canvasData: {
        ...state.canvasData,
        layers: state.canvasData.layers.map((l) =>
          l.id === layerId ? { ...l, backgroundImage: imageData } : l
        ),
      },
    })),

  deleteLayer: (layerId) =>
    set((state) => {
      const newLayers = state.canvasData.layers.filter((l) => l.id !== layerId);
      const newActiveId =
        state.canvasData.activeLayerId === layerId
          ? newLayers.length > 0
            ? newLayers[newLayers.length - 1].id
            : null
          : state.canvasData.activeLayerId;
      return {
        canvasData: {
          ...state.canvasData,
          layers: newLayers,
          activeLayerId: newActiveId,
        },
      };
    }),

  setActiveLayer: (layerId) =>
    set({
      canvasData: { ...get().canvasData, activeLayerId: layerId },
    }),

  toggleLayerVisibility: (layerId) =>
    set((state) => ({
      canvasData: {
        ...state.canvasData,
        layers: state.canvasData.layers.map((l) =>
          l.id === layerId ? { ...l, visible: !l.visible } : l
        ),
      },
    })),

  toggleLayerLock: (layerId) =>
    set((state) => ({
      canvasData: {
        ...state.canvasData,
        layers: state.canvasData.layers.map((l) =>
          l.id === layerId ? { ...l, locked: !l.locked } : l
        ),
      },
    })),

  updateLayerOrder: (layerIds) =>
    set((state) => ({
      canvasData: {
        ...state.canvasData,
        layers: layerIds
          .map((id) => state.canvasData.layers.find((l) => l.id === id))
          .filter((l): l is Layer => l !== undefined)
          .map((l, index) => ({ ...l, zIndex: index })),
      },
    })),

  // Stroke actions
  addStroke: (stroke) =>
    set((state) => ({
      canvasData: {
        ...state.canvasData,
        layers: state.canvasData.layers.map((l) =>
          l.id === stroke.layerId
            ? {
                ...l,
                strokes: [
                  ...l.strokes,
                  {
                    ...stroke,
                    id: `stroke-${Date.now()}-${Math.random()}`,
                    timestamp: Date.now(),
                  },
                ],
              }
            : l
        ),
      },
    })),

  clearLayerStrokes: (layerId) =>
    set((state) => ({
      canvasData: {
        ...state.canvasData,
        layers: state.canvasData.layers.map((l) =>
          l.id === layerId ? { ...l, strokes: [] } : l
        ),
      },
    })),

  // History actions
  saveHistory: () =>
    set((state) => {
      const newHistory = state.history.slice(0, state.historyIndex + 1);
      newHistory.push({
        canvasData: JSON.parse(JSON.stringify(state.canvasData)),
        timestamp: Date.now(),
      });
      // Limit history to 50 items
      if (newHistory.length > 50) {
        newHistory.shift();
      }
      return {
        history: newHistory,
        historyIndex: newHistory.length - 1,
      };
    }),

  undo: () =>
    set((state) => {
      if (state.historyIndex > 0) {
        const newIndex = state.historyIndex - 1;
        return {
          canvasData: JSON.parse(JSON.stringify(state.history[newIndex].canvasData)),
          historyIndex: newIndex,
        };
      }
      return state;
    }),

  redo: () =>
    set((state) => {
      if (state.historyIndex < state.history.length - 1) {
        const newIndex = state.historyIndex + 1;
        return {
          canvasData: JSON.parse(JSON.stringify(state.history[newIndex].canvasData)),
          historyIndex: newIndex,
        };
      }
      return state;
    }),

  canUndo: () => {
    const state = get();
    return state.historyIndex > 0;
  },

  canRedo: () => {
    const state = get();
    return state.historyIndex < state.history.length - 1;
  },

  // Export
  exportToImage: (format = 'png') => {
    const state = get();
    const { canvasData } = state;

    // Create a temporary canvas
    const canvas = document.createElement('canvas');
    canvas.width = canvasData.width;
    canvas.height = canvasData.height;
    const ctx = canvas.getContext('2d');

    if (!ctx) return null;

    // Fill with white background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Sort layers by zIndex
    const sortedLayers = [...canvasData.layers].sort((a, b) => a.zIndex - b.zIndex);

    // Render each layer
    sortedLayers.forEach((layer) => {
      if (!layer.visible) return;

      layer.strokes.forEach((stroke) => {
        ctx.globalAlpha = stroke.opacity;
        ctx.strokeStyle = stroke.tool === 'eraser' ? '#ffffff' : stroke.color;
        ctx.lineWidth = stroke.size;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';

        if (stroke.points.length < 2) return;

        ctx.beginPath();
        ctx.moveTo(stroke.points[0].x, stroke.points[0].y);

        for (let i = 1; i < stroke.points.length; i++) {
          ctx.lineTo(stroke.points[i].x, stroke.points[i].y);
        }

        ctx.stroke();
      });
    });

    // Export to image
    const mimeType = format === 'jpeg' ? 'image/jpeg' : 'image/png';
    const dataUrl = canvas.toDataURL(mimeType, 0.9);

    return dataUrl;
  },

  // Export active layer only
  exportActiveLayerToImage: (format = 'png') => {
    const state = get();
    const { canvasData } = state;
    const activeLayer = canvasData.layers.find((l) => l.id === canvasData.activeLayerId);

    if (!activeLayer) return null;

    // Create a temporary canvas
    const canvas = document.createElement('canvas');
    canvas.width = canvasData.width;
    canvas.height = canvasData.height;
    const ctx = canvas.getContext('2d');

    if (!ctx) return null;

    // Fill with white background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Render only the active layer
    if (activeLayer.visible) {
      // Render strokes
      activeLayer.strokes.forEach((stroke) => {
        ctx.globalAlpha = stroke.opacity;
        ctx.strokeStyle = stroke.tool === 'eraser' ? '#ffffff' : stroke.color;
        ctx.lineWidth = stroke.size;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';

        if (stroke.points.length < 2) return;

        ctx.beginPath();
        ctx.moveTo(stroke.points[0].x, stroke.points[0].y);

        for (let i = 1; i < stroke.points.length; i++) {
          ctx.lineTo(stroke.points[i].x, stroke.points[i].y);
        }

        ctx.stroke();
      });

      // Render background image if exists (for image layers)
      if (activeLayer.backgroundImage) {
        const img = new window.Image();
        img.src = activeLayer.backgroundImage;
        try {
          // Wait for image to load synchronously if already cached
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        } catch (e) {
          console.warn('Could not draw background image synchronously');
        }
      }
    }

    // Export to image
    const mimeType = format === 'jpeg' ? 'image/jpeg' : 'image/png';
    const dataUrl = canvas.toDataURL(mimeType, 0.9);

    return dataUrl;
  },

  // Zoom actions
  setZoom: (zoom) => set({ zoom: Math.max(0.1, Math.min(5, zoom)) }),

  zoomIn: () =>
    set((state) => ({
      zoom: Math.min(5, state.zoom + 0.1),
    })),

  zoomOut: () =>
    set((state) => ({
      zoom: Math.max(0.1, state.zoom - 0.1),
    })),

  resetZoom: () => set({ zoom: 1 }),

  // Layer order actions
  moveLayer: (layerId, direction) =>
    set((state) => {
      const layers = [...state.canvasData.layers];
      const index = layers.findIndex((l) => l.id === layerId);

      if (index === -1) return state;

      // Don't move background layer
      const layer = layers[index];
      if (layer.type === 'background') return state;

      let newIndex = index;

      if (direction === 'up' && index < layers.length - 1) {
        // Move up in the list (higher zIndex)
        newIndex = index + 1;
        // Swap zIndex with the layer above
        const targetLayer = layers[newIndex];
        if (targetLayer.type === 'background') return state; // Don't move above background
        [layers[index].zIndex, layers[newIndex].zIndex] = [layers[newIndex].zIndex, layers[index].zIndex];
      } else if (direction === 'down' && index > 0) {
        // Move down in the list (lower zIndex)
        newIndex = index - 1;
        // Swap zIndex with the layer below
        const targetLayer = layers[newIndex];
        if (targetLayer.type === 'background') return state; // Don't move below background
        [layers[index].zIndex, layers[newIndex].zIndex] = [layers[newIndex].zIndex, layers[index].zIndex];
      }

      return {
        canvasData: { ...state.canvasData, layers },
      };
    }),

  // AI actions
  setAIMode: (mode) => set({ aiMode: mode }),
  setAIPrompt: (prompt) => set({ aiPrompt: prompt }),
  setDrawingInfluence: (value) => set({ drawingInfluence: Math.max(0, Math.min(1, value)) }),
  setGenerating: (isGenerating) => set({ isGenerating }),
  setGeneratedImage: (image) => set({ generatedImage: image }),
  setGeneratedModelUrl: (url) => set({ generatedModelUrl: url }),
  resetAIGeneration: () =>
    set({
      aiPrompt: '',
      drawingInfluence: 0.7,
      isGenerating: false,
      generatedImage: null,
      generatedModelUrl: null,
    }),
  importToStudio: () => {
    const state = get();
    if (!state.generatedModelUrl) return;

    // 触发自定义事件 MODEL_READY
    const event = new CustomEvent('MODEL_READY', {
      detail: {
        modelUrl: state.generatedModelUrl,
        modelName: `AI Generated Model ${Date.now()}`,
      },
    });

    window.dispatchEvent(event);

    // 关闭工作区
    state.closeWorkspace();
  },
}));
