import { create } from 'zustand';

export interface ColorSwatch {
  id: string;
  labelId: string; // Associated label ID
  modelId: string; // Which model this swatch is attached to
  
  // Color info
  colorCode: string; // Hex color code, e.g., "#FF6B6B"
  colorName: string; // Color name, e.g., "珊瑚红"
  
  // Product info
  styleName: string; // 款式名称, e.g., "滋润款"
  price: string; // 价格, e.g., "¥199"
  stock: string; // 库存, e.g., "充足" / "缺货"
  
  // Position
  position: { x: number; y: number; z: number }; // 3D world position
  
  // Display
  visible: boolean;
  createdAt: number;
}

export interface ColorSwatchState {
  colorSwatches: ColorSwatch[];
  isPlacingSwatch: boolean; // Whether user is in placement mode
  activeLabelId: string | null; // Label ID being used for placement
  hoveredSwatchId: string | null;
  
  // Pending config for new swatch
  pendingConfig: {
    colorCode: string;
    colorName: string;
    styleName: string;
    price: string;
    stock: string;
  } | null;

  // Actions
  startPlacingSwatch: (labelId: string) => void;
  setPendingConfig: (config: ColorSwatchState['pendingConfig']) => void;
  cancelPlacingSwatch: () => void;
  addColorSwatch: (swatch: Omit<ColorSwatch, 'id' | 'createdAt'>) => string;
  updateColorSwatch: (id: string, updates: Partial<ColorSwatch>) => void;
  removeColorSwatch: (id: string) => void;
  removeColorSwatchByLabel: (labelId: string) => void;
  toggleSwatchVisibility: (id: string) => void;
  setHoveredSwatch: (id: string | null) => void;
  clearAllSwatches: () => void;
  undoLastSwatch: () => ColorSwatch | null;
}

export const useColorSwatchStore = create<ColorSwatchState>((set, get) => ({
  colorSwatches: [],
  isPlacingSwatch: false,
  activeLabelId: null,
  hoveredSwatchId: null,
  pendingConfig: null,

  startPlacingSwatch: (labelId) => {
    set({
      isPlacingSwatch: true,
      activeLabelId: labelId,
    });
    console.log('Started placing color swatch:', labelId);
  },

  setPendingConfig: (config) => {
    set({ pendingConfig: config });
  },

  cancelPlacingSwatch: () => {
    set({
      isPlacingSwatch: false,
      activeLabelId: null,
      pendingConfig: null,
    });
    console.log('Cancelled placing color swatch');
  },

  addColorSwatch: (swatchData) => {
    const id = `color-swatch-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const newSwatch: ColorSwatch = {
      ...swatchData,
      id,
      createdAt: Date.now(),
    };

    set((state) => ({
      colorSwatches: [...state.colorSwatches, newSwatch],
      isPlacingSwatch: false,
      activeLabelId: null,
      pendingConfig: null,
    }));

    console.log('Added color swatch:', id);
    return id;
  },

  updateColorSwatch: (id, updates) => {
    set((state) => ({
      colorSwatches: state.colorSwatches.map((swatch) =>
        swatch.id === id ? { ...swatch, ...updates } : swatch
      ),
    }));
  },

  removeColorSwatch: (id) => {
    set((state) => ({
      colorSwatches: state.colorSwatches.filter((swatch) => swatch.id !== id),
    }));
  },

  removeColorSwatchByLabel: (labelId) => {
    set((state) => ({
      colorSwatches: state.colorSwatches.filter((swatch) => swatch.labelId !== labelId),
    }));
  },

  toggleSwatchVisibility: (id) => {
    set((state) => ({
      colorSwatches: state.colorSwatches.map((swatch) =>
        swatch.id === id ? { ...swatch, visible: !swatch.visible } : swatch
      ),
    }));
  },

  setHoveredSwatch: (id) => {
    set({ hoveredSwatchId: id });
  },

  clearAllSwatches: () => {
    set({ colorSwatches: [] });
  },

  undoLastSwatch: () => {
    const state = get();
    if (state.colorSwatches.length === 0) return null;

    const lastSwatch = state.colorSwatches[state.colorSwatches.length - 1];
    set((state) => ({
      colorSwatches: state.colorSwatches.slice(0, -1),
    }));

    return lastSwatch;
  },
}));
