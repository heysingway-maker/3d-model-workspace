import { create } from 'zustand';

export type CoverageMode = 'single' | 'full';
export type SelectionType = 'click' | 'box'; // 点击模式或框选模式

// 材质快照类型
export interface MaterialSnapshot {
  meshUuid: string;
  meshName: string;
  materialJson: string; // JSON 序列化的材质属性
  textureImage?: string; // 纹理图片 base64 (如果有)
}

// 撤销历史记录类型
export interface DecalHistoryEntry {
  id: string;
  timestamp: number;
  actionType: 'full_coverage' | 'single_decal';
  labelId: string;
  modelId: string;
  materialSnapshots: MaterialSnapshot[]; // 应用贴花前的材质快照
  decalMeshNames: string[]; // 如果是 single_decal，记录创建的 decal mesh 名称
}

// 选中的面信息（用于 Click 模式选择模型面）
export interface SelectedFace {
  id: string; // 唯一标识：meshUuid_faceIndex
  meshUuid: string; // 所属 mesh 的 uuid
  meshName: string; // mesh 名称
  faceIndex: number; // 面索引
  parentId: string; // 所属模型 ID
  position: { x: number; y: number; z: number }; // 点击位置（世界坐标）
  normal: { x: number; y: number; z: number }; // 面法线（世界坐标）
}

export interface DecalModeState {
  isDecalMode: boolean;
  activeLabelImage: string | null;
  activeLabelId: string | null;
  coverageMode: CoverageMode;
  selectionType: SelectionType;
  repeatDensity: number; // 1-10, how many times the pattern repeats
  opacity: number; // 0-1, transparency of the decal
  decalRotation: number;
  decalSize: number; // 贴花大小
  placedDecals: Array<{
    id: string;
    labelId: string;
    modelId: string; // Which model the decal was applied to
    coverageMode: CoverageMode;
    repeatDensity: number;
    opacity: number;
    rotation: number;
    size?: number;
  }>;

  // 选中的面列表（用于 Click 模式选择模型面）
  selectedFaces: SelectedFace[];

  // 撤销历史
  history: DecalHistoryEntry[];
  maxHistorySize: number; // 最大历史记录数

  // 框选状态
  isSelecting: boolean; // 是否正在框选中
  selectionStart: { x: number; y: number } | null; // 框选起点（屏幕坐标）
  selectionEnd: { x: number; y: number } | null; // 框选终点（屏幕坐标）

  // Store original materials for restoration
  originalMaterials: Map<string, any>;

  // Actions
  enterDecalMode: (labelImage: string, labelId: string) => void;
  exitDecalMode: () => void;
  setCoverageMode: (mode: CoverageMode) => void;
  setSelectionType: (type: SelectionType) => void;
  setRepeatDensity: (density: number) => void;
  setOpacity: (opacity: number) => void;
  setDecalRotation: (rotation: number) => void;
  setDecalSize: (size: number) => void;
  addPlacedDecal: (decal: Omit<DecalModeState['placedDecals'][0], 'id'>) => string;
  removePlacedDecal: (id: string) => void;
  clearAllDecals: () => void;
  saveOriginalMaterial: (modelId: string, material: any) => void;
  getOriginalMaterial: (modelId: string) => any;
  
  // 选中面相关
  toggleSelectedFace: (face: SelectedFace) => void;
  clearSelectedFaces: () => void;
  setSelectedFaces: (faces: SelectedFace[]) => void;
  
  // 框选相关 Actions
  startSelection: (start: { x: number; y: number }) => void;
  updateSelection: (end: { x: number; y: number }) => void;
  endSelection: () => void;
  clearSelection: () => void;
  
  // 撤销相关 Actions
  pushHistory: (entry: Omit<DecalHistoryEntry, 'id' | 'timestamp'>) => void;
  undo: () => DecalHistoryEntry | null;
  canUndo: () => boolean;
  clearHistory: () => void;
  
  // 取消当前选择并退出 decal 模式
  cancelSelection: () => void;
}

export const useDecalModeStore = create<DecalModeState>((set, get) => ({
  isDecalMode: false,
  activeLabelImage: null,
  activeLabelId: null,
  coverageMode: 'full', // Default to full coverage
  selectionType: 'click', // Default to box selection
  repeatDensity: 3, // Default medium density
  opacity: 1.0, // Default fully opaque
  decalRotation: 0,
  decalSize: 2.0, // Default 100% size
  placedDecals: [],
  selectedFaces: [],
  originalMaterials: new Map(),
  
  // 撤销历史
  history: [],
  maxHistorySize: 50,
  
  // 框选状态
  isSelecting: false,
  selectionStart: null,
  selectionEnd: null,

  enterDecalMode: (labelImage, labelId) => {
    set({
      isDecalMode: true,
      activeLabelImage: labelImage,
      activeLabelId: labelId,
      coverageMode: 'full',
      selectionType: 'click',
      repeatDensity: 3,
      opacity: 1.0,
      decalRotation: 0,
      decalSize: 2.0,
      isSelecting: false,
      selectionStart: null,
      selectionEnd: null,
      selectedFaces: [],
    });
    console.log('Entered decal mode for label:', labelId);
  },

  exitDecalMode: () => {
    set({
      isDecalMode: false,
      activeLabelImage: null,
      activeLabelId: null,
      isSelecting: false,
      selectionStart: null,
      selectionEnd: null,
      selectedFaces: [],
    });
    console.log('Exited decal mode');
  },

  setCoverageMode: (mode) => {
    set({ coverageMode: mode, selectedFaces: [] });
    console.log('Coverage mode set to:', mode);
  },

  setSelectionType: (type) => {
    set({ selectionType: type, isSelecting: false, selectionStart: null, selectionEnd: null, selectedFaces: [] });
    console.log('Selection type set to:', type);
  },

  setRepeatDensity: (density) => {
    set({ repeatDensity: density });
  },

  setOpacity: (opacity) => {
    set({ opacity: opacity });
  },

  setDecalRotation: (rotation) => {
    set({ decalRotation: rotation });
  },
  
  setDecalSize: (size) => {
    set({ decalSize: size });
  },

  addPlacedDecal: (decal) => {
    const id = `decal-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    set((state) => ({
      placedDecals: [...state.placedDecals, { ...decal, id }],
    }));
    return id;
  },

  removePlacedDecal: (id) => {
    set((state) => ({
      placedDecals: state.placedDecals.filter((d) => d.id !== id),
    }));
  },

  clearAllDecals: () => {
    set({ placedDecals: [] });
  },

  saveOriginalMaterial: (modelId, material) => {
    const materials = get().originalMaterials;
    materials.set(modelId, material);
    set({ originalMaterials: materials });
  },

  getOriginalMaterial: (modelId) => {
    return get().originalMaterials.get(modelId);
  },
  
  // 选中面相关
  toggleSelectedFace: (face) => {
    set((state) => {
      const exists = state.selectedFaces.find(f => f.id === face.id);
      if (exists) {
        return { selectedFaces: state.selectedFaces.filter(f => f.id !== face.id) };
      } else {
        return { selectedFaces: [...state.selectedFaces, face] };
      }
    });
  },
  
  clearSelectedFaces: () => {
    set({ selectedFaces: [] });
  },
  
  setSelectedFaces: (faces) => {
    set({ selectedFaces: faces });
  },
  
  // 框选相关 Actions
  startSelection: (start) => {
    set({
      isSelecting: true,
      selectionStart: start,
      selectionEnd: start,
    });
  },

  updateSelection: (end) => {
    set({ selectionEnd: end });
  },

  endSelection: () => {
    set({ isSelecting: false });
  },

  clearSelection: () => {
    set({
      isSelecting: false,
      selectionStart: null,
      selectionEnd: null,
    });
  },
  
  // 撤销相关 Actions
  pushHistory: (entry) => {
    const historyEntry: DecalHistoryEntry = {
      ...entry,
      id: `history-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: Date.now(),
    };

    set((state) => {
      const newHistory = [...state.history, historyEntry];
      // 保持最大历史记录数
      if (newHistory.length > state.maxHistorySize) {
        return { history: newHistory.slice(-state.maxHistorySize) };
      }
      return { history: newHistory };
    });
  },

  undo: () => {
    const state = get();
    if (state.history.length === 0) {
      console.log('No history to undo');
      return null;
    }

    const lastEntry = state.history[state.history.length - 1];
    
    set((state) => ({
      history: state.history.slice(0, -1),
    }));

    return lastEntry;
  },

  canUndo: () => {
    return get().history.length > 0;
  },

  clearHistory: () => {
    set({ history: [] });
  },
  
  // 取消当前选择并退出 decal 模式
  cancelSelection: () => {
    set({
      isDecalMode: false,
      activeLabelImage: null,
      activeLabelId: null,
      isSelecting: false,
      selectionStart: null,
      selectionEnd: null,
      selectedFaces: [],
    });
    console.log('Cancelled decal selection');
    // Trigger highlight clear via window function
    if (typeof window !== 'undefined' && (window as any).clearDecalHighlight) {
      (window as any).clearDecalHighlight();
    }
  },
}));
