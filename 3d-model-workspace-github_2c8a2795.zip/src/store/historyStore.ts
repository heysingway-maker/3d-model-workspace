'use client';

import { create } from 'zustand';

/**
 * HistoryEntry - 记录每次状态变化
 *
 * Type:
 * - UPDATE: 更新现有属性（如 position.x, material.roughness）
 * - ADD: 添加新对象（如 ADD_MODEL）
 * - DELETE: 删除对象（如 DELETE_MODEL）
 */
export interface HistoryEntry {
  id: string;           // 目标 ID（Model UUID, Light ID, 或 "Environment"）
  type: 'UPDATE' | 'ADD' | 'DELETE';
  path: string;         // 点符号路径（如 "position.x", "material.roughness"）
  before: any;          // 变化前的值
  after: any;           // 变化后的值
  timestamp: number;    // 时间戳
}

interface HistoryStore {
  past: HistoryEntry[];
  future: HistoryEntry[];

  // 提交变化
  commitChange: (
    targetId: string,
    type: 'UPDATE' | 'ADD' | 'DELETE',
    path: string,
    before: any,
    after: any
  ) => void;

  // 撤销
  undo: () => void;

  // 重做
  redo: () => void;

  // 清空历史
  clearHistory: () => void;

  // 获取历史深度（用于调试）
  getHistoryDepth: () => number;
}

export const useHistoryStore = create<HistoryStore>((set, get) => ({
  past: [],
  future: [],

  commitChange: (targetId, type, path, before, after) => {
    const entry: HistoryEntry = {
      id: targetId,
      type,
      path,
      before,
      after,
      timestamp: Date.now(),
    };

    console.log('📝 Commit Change:', {
      targetId,
      type,
      path,
      before,
      after,
      depth: get().past.length,
    });

    set((state) => ({
      past: [...state.past, entry],
      future: [], // 清空 future，因为有了新的变化
    }));
  },

  undo: () => {
    const { past, future } = get();
    if (past.length === 0) {
      console.log('⚠️ No history to undo');
      return;
    }

    const lastEntry = past[past.length - 1];

    console.log('↩️ Undo:', {
      targetId: lastEntry.id,
      type: lastEntry.type,
      path: lastEntry.path,
      from: lastEntry.after,
      to: lastEntry.before,
    });

    set((state) => ({
      past: state.past.slice(0, -1),
      future: [lastEntry, ...state.future],
    }));

    // 触发自定义事件，通知其他组件执行撤销操作
    window.dispatchEvent(
      new CustomEvent('history:undo', {
        detail: lastEntry,
      })
    );
  },

  redo: () => {
    const { past, future } = get();
    if (future.length === 0) {
      console.log('⚠️ No future to redo');
      return;
    }

    const nextEntry = future[0];

    console.log('↪️ Redo:', {
      targetId: nextEntry.id,
      type: nextEntry.type,
      path: nextEntry.path,
      from: nextEntry.before,
      to: nextEntry.after,
    });

    set((state) => ({
      past: [...state.past, nextEntry],
      future: state.future.slice(1),
    }));

    // 触发自定义事件，通知其他组件执行重做操作
    window.dispatchEvent(
      new CustomEvent('history:redo', {
        detail: nextEntry,
      })
    );
  },

  clearHistory: () => {
    console.log('🗑️ Clear History');
    set({
      past: [],
      future: [],
    });
  },

  getHistoryDepth: () => {
    return get().past.length;
  },
}));
