import { create } from 'zustand';

export interface Label {
  id: string;
  name: string;
  imageData: string; // Base64 image data
  createdAt: number;
  decalMesh?: string; // Serialized decal mesh data
  textureBlob?: Blob; // Texture blob
}

export interface LabelState {
  labels: Label[];
  activeLabelId: string | null;
  isLabelEditorOpen: boolean;
  isDecalMappingOpen: boolean;
  editingLabelId: string | null;

  // Actions
  addLabel: (label: Omit<Label, 'id' | 'createdAt'>) => string;
  updateLabel: (id: string, updates: Partial<Label>) => void;
  deleteLabel: (id: string) => void;
  setActiveLabel: (id: string | null) => void;
  openLabelEditor: (labelId?: string) => void;
  closeLabelEditor: () => void;
  openDecalMapping: (labelId: string) => void;
  closeDecalMapping: () => void;
}

export const useLabelStore = create<LabelState>((set, get) => ({
  labels: [],
  activeLabelId: null,
  isLabelEditorOpen: false,
  isDecalMappingOpen: false,
  editingLabelId: null,

  addLabel: (label) => {
    const id = `label-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const newLabel: Label = {
      ...label,
      id,
      createdAt: Date.now(),
    };

    set((state) => ({
      labels: [...state.labels, newLabel],
    }));

    return id;
  },

  updateLabel: (id, updates) => {
    set((state) => ({
      labels: state.labels.map((label) =>
        label.id === id ? { ...label, ...updates } : label
      ),
    }));
  },

  deleteLabel: (id) => {
    set((state) => ({
      labels: state.labels.filter((label) => label.id !== id),
      activeLabelId: state.activeLabelId === id ? null : state.activeLabelId,
    }));
  },

  setActiveLabel: (id) => {
    set({ activeLabelId: id });
  },

  openLabelEditor: (labelId) => {
    set({
      isLabelEditorOpen: true,
      editingLabelId: labelId || null,
    });
  },

  closeLabelEditor: () => {
    set({
      isLabelEditorOpen: false,
      editingLabelId: null,
    });
  },

  openDecalMapping: (labelId) => {
    set({
      isDecalMappingOpen: true,
      activeLabelId: labelId,
    });
  },

  closeDecalMapping: () => {
    set({
      isDecalMappingOpen: false,
    });
  },
}));
