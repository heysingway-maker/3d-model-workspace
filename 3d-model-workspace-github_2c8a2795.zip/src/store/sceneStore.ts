import { create } from 'zustand';
import * as THREE from 'three';
import { useHistoryStore, HistoryEntry } from './historyStore';
import { getObjectValue, setObjectValue, deepClone, isEqual } from '@/utils/objectPath';

export interface MaterialData {
  color: string;
  roughness: number;
  metalness: number;
  transparent: number;
}

export interface SceneModel {
  id: string;          // Unique UUID for this import instance
  name: string;        // Display name (editable), default to filename
  url: string;         // Blob URL
  visible: boolean;    // Global visibility for this model
  position: [number, number, number];   // Default [0,0,0]
  rotation: [number, number, number];   // Rotation in degrees, Default [0,0,0]
  scale: [number, number, number];      // Default [1,1,1]
  material: MaterialData;               // Material properties
  objectRef: THREE.Group | null; // Reference to the actual 3D object
}

export type LightType = 'ambient' | 'directional' | 'point' | 'spot';

export interface SceneLight {
  id: string;
  type: LightType;
  name: string;
  intensity: number;
  color: string;
  position: [number, number, number];
  visible: boolean;
  distance?: number;
  decay?: number;
  target?: [number, number, number];
  angle?: number;
  penumbra?: number;
  lightRef?: THREE.Light | null;
  helperRef?: THREE.Object3D | null;
}

export type EnvironmentPreset = 'none' | 'studio_09' | 'studio_03' | 'brown_02' | 'neon' | 'warehouse';

// HDRI 环境贴图配置（使用本地 HDRI 文件）
export const HDRI_PRESETS: Record<EnvironmentPreset, string | null> = {
  none: null,
  studio_09: '/assets/studio_small_09_2k.hdr',   // Studio Small 09 - 专业摄影棚白色调
  studio_03: '/assets/studio_small_03_2k.hdr',   // Studio Small 03 - 明亮摄影棚
  brown_02: '/assets/brown_photostudio_02_2k.hdr', // Brown Photostudio 02 - 暖色调摄影棚
  neon: '/assets/neon_photostudio_2k.hdr',       // Neon Photostudio - 霓虹灯效果
  warehouse: 'https://dl.polyhaven.org/file/ph-assets/HDRIs/hdr/1k/venice_sunset_1k.hdr', // 仓库 - 使用外部资源
};

export interface EnvironmentData {
  preset: EnvironmentPreset;
  backgroundColor: string;
  environmentIntensity: number;
  environmentRotation: number;
  backgroundBlur: number;
  showEnvironmentBackground: boolean; // 是否显示环境背景（即使有HDRI，也可以选择不显示背景）
  hdriUrl?: string | null;
  environmentMap?: THREE.Texture | null;
  backgroundMap?: THREE.Texture | null;
  lightColor?: string;
  ambientColor?: string;
}

export interface PostProcessingData {
  enabled: boolean;
  bloom: {
    enabled: boolean;
    intensity: number;
    threshold: number;
    radius: number;
  };
  vignette: {
    enabled: boolean;
    darkness: number;
    offset: number;
  };
}

interface SceneState {
  // Models array
  models: SceneModel[];

  // The UUID of the currently selected object
  selectedObjectUuid: string | null;

  // Action to set selection
  setSelectedObject: (uuid: string | null) => void;

  // Add a new model
  addModel: (model: SceneModel) => void;

  // Update model data with history tracking
  updateModel: (id: string, data: Partial<SceneModel>) => void;

  // Update specific property with path (for granular history tracking)
  updateModelProperty: (id: string, path: string, value: any, skipHistory?: boolean) => void;

  // Remove a model
  removeModel: (id: string) => void;

  // Undo last change
  undo: () => void;

  // Redo next change
  redo: () => void;

  // Dictionary to track expanded tree nodes in the UI
  expandedNodes: Record<string, boolean>;

  // Toggle node expansion
  toggleNode: (uuid: string) => void;

  // Expand a node (used when selecting child)
  expandNode: (uuid: string) => void;

  // Collapse a node
  collapseNode: (uuid: string) => void;

  // Lights array
  lights: SceneLight[];

  // The ID of the currently selected light
  selectedLightId: string | null;

  // Action to set selected light
  setSelectedLight: (id: string | null) => void;

  // Add a new light
  addLight: (light: SceneLight) => void;

  // Update light data
  updateLight: (id: string, data: Partial<SceneLight>) => void;

  // Remove a light
  removeLight: (id: string) => void;

  // Environment settings
  environment: EnvironmentData;

  // Update environment settings
  updateEnvironment: (data: Partial<EnvironmentData>) => void;

  // Post processing settings
  postProcessing: PostProcessingData;

  // Update post processing settings
  updatePostProcessing: (data: Partial<PostProcessingData>) => void;
}

export const useSceneStore = create<SceneState>((set, get) => ({
  models: [],
  selectedObjectUuid: null,

  setSelectedObject: (uuid) => set({ selectedObjectUuid: uuid }),

  addModel: (model) =>
    set((state) => {
      // 记录到历史（ADD 操作）
      useHistoryStore.getState().commitChange(
        model.id,
        'ADD',
        'model',
        null, // before: 模型不存在
        model // after: 完整的模型对象
      );

      return {
        models: [...state.models, model],
      };
    }),

  updateModel: (id, data) =>
    set((state) => {
      const model = state.models.find((m) => m.id === id);
      if (!model) return state;

      // 记录所有变化的属性到历史
      for (const key of Object.keys(data)) {
        const path = key;
        const beforeValue = getObjectValue(model, path);
        const afterValue = (data as any)[key];

        // 只有当值真正变化时才记录
        if (!isEqual(beforeValue, afterValue)) {
          useHistoryStore.getState().commitChange(
            id,
            'UPDATE',
            path,
            beforeValue,
            afterValue
          );
        }
      }

      return {
        models: state.models.map((m) => (m.id === id ? { ...m, ...data } : m)),
      };
    }),

  updateModelProperty: (id, path, value, skipHistory = false) =>
    set((state) => {
      const model = state.models.find((m) => m.id === id);
      if (!model) return state;

      const beforeValue = getObjectValue(model, path);

      // 只有当值真正变化时才更新
      if (isEqual(beforeValue, value)) {
        return state;
      }

      // 记录到历史（除非跳过）
      if (!skipHistory) {
        useHistoryStore.getState().commitChange(
          id,
          'UPDATE',
          path,
          beforeValue,
          value
        );
      }

      // 创建新的模型对象并更新指定路径
      const updatedModel = deepClone(model);
      setObjectValue(updatedModel, path, value);

      return {
        models: state.models.map((m) => (m.id === id ? updatedModel : m)),
      };
    }),

  removeModel: (id) =>
    set((state) => {
      const modelToRemove = state.models.find((m) => m.id === id);
      if (!modelToRemove) return state;

      // 记录到历史（DELETE 操作）
      useHistoryStore.getState().commitChange(
        id,
        'DELETE',
        'model',
        modelToRemove, // before: 完整的模型对象
        null // after: 模型不存在
      );

      return {
        models: state.models.filter((m) => m.id !== id),
        selectedObjectUuid: state.selectedObjectUuid === id ? null : state.selectedObjectUuid,
      };
    }),

  undo: () => {
    const entry = useHistoryStore.getState().past[useHistoryStore.getState().past.length - 1];
    if (!entry) return;

    useHistoryStore.getState().undo();

    // 根据 HistoryEntry 执行撤销
    set((state) => {
      switch (entry.type) {
        case 'UPDATE':
          return handleUpdateUndo(state, entry);
        case 'ADD':
          return handleAddUndo(state, entry);
        case 'DELETE':
          return handleDeleteUndo(state, entry);
        default:
          return state;
      }
    });
  },

  redo: () => {
    const entry = useHistoryStore.getState().future[0];
    if (!entry) return;

    useHistoryStore.getState().redo();

    // 根据 HistoryEntry 执行重做
    set((state) => {
      switch (entry.type) {
        case 'UPDATE':
          return handleUpdateRedo(state, entry);
        case 'ADD':
          return handleAddRedo(state, entry);
        case 'DELETE':
          return handleDeleteRedo(state, entry);
        default:
          return state;
      }
    });
  },

  expandedNodes: {},

  toggleNode: (uuid) =>
    set((state) => ({
      expandedNodes: {
        ...state.expandedNodes,
        [uuid]: !state.expandedNodes[uuid],
      },
    })),

  expandNode: (uuid) =>
    set((state) => ({
      expandedNodes: {
        ...state.expandedNodes,
        [uuid]: true,
      },
    })),

  collapseNode: (uuid) =>
    set((state) => ({
      expandedNodes: {
        ...state.expandedNodes,
        [uuid]: false,
      },
    })),

  // Lights
  lights: [],
  selectedLightId: null,

  // Environment
  environment: {
    preset: 'studio_09',
    backgroundColor: '#1a1a2e',
    environmentIntensity: 1.2,
    environmentRotation: 0,
    backgroundBlur: 0,
    showEnvironmentBackground: false,
    hdriUrl: HDRI_PRESETS.studio_09,
  },

  // Post Processing
  postProcessing: {
    enabled: true,
    bloom: {
      enabled: true,
      intensity: 0.12,
      threshold: 0.09,
      radius: 0.12,
    },
    vignette: {
      enabled: true,
      darkness: 1.2,
      offset: 0.8,
    },
  },

  setSelectedLight: (id) => set({ selectedLightId: id }),

  addLight: (light) =>
    set((state) => {
      // 记录到历史（ADD 操作）
      useHistoryStore.getState().commitChange(
        light.id,
        'ADD',
        'light',
        null,
        light
      );

      return {
        lights: [...state.lights, light],
      };
    }),

  updateLight: (id, data) =>
    set((state) => {
      const light = state.lights.find((l) => l.id === id);
      if (!light) return state;

      // 记录到历史
      for (const key of Object.keys(data)) {
        const beforeValue = getObjectValue(light, key);
        const afterValue = (data as any)[key];

        if (!isEqual(beforeValue, afterValue)) {
          useHistoryStore.getState().commitChange(
            id,
            'UPDATE',
            key,
            beforeValue,
            afterValue
          );
        }
      }

      return {
        lights: state.lights.map((l) => (l.id === id ? { ...l, ...data } : l)),
      };
    }),

  removeLight: (id) =>
    set((state) => {
      const lightToRemove = state.lights.find((l) => l.id === id);
      if (!lightToRemove) return state;

      // 记录到历史（DELETE 操作）
      useHistoryStore.getState().commitChange(
        id,
        'DELETE',
        'light',
        lightToRemove,
        null
      );

      return {
        lights: state.lights.filter((l) => l.id !== id),
        selectedLightId: state.selectedLightId === id ? null : state.selectedLightId,
      };
    }),

  updateEnvironment: (data) =>
    set((state) => {
      const updatedEnvironment = { ...state.environment, ...data };

      // 记录到历史
      for (const key of Object.keys(data)) {
        const beforeValue = getObjectValue(state.environment, key);
        const afterValue = (data as any)[key];

        if (!isEqual(beforeValue, afterValue)) {
          useHistoryStore.getState().commitChange(
            'environment',
            'UPDATE',
            `environment.${key}`,
            beforeValue,
            afterValue
          );
        }
      }

      return {
        environment: updatedEnvironment,
      };
    }),

  updatePostProcessing: (data) =>
    set((state) => {
      const updatedPostProcessing = { ...state.postProcessing, ...data };

      // 记录到历史
      for (const key of Object.keys(data)) {
        const beforeValue = getObjectValue(state.postProcessing, key);
        const afterValue = (data as any)[key];

        if (!isEqual(beforeValue, afterValue)) {
          useHistoryStore.getState().commitChange(
            'postProcessing',
            'UPDATE',
            `postProcessing.${key}`,
            beforeValue,
            afterValue
          );
        }
      }

      return {
        postProcessing: updatedPostProcessing,
      };
    }),
}));

// 处理 UPDATE 撤销
function handleUpdateUndo(state: SceneState, entry: HistoryEntry) {
  return {
    models: state.models.map((m) => {
      if (m.id === entry.id) {
        const updated = deepClone(m);
        setObjectValue(updated, entry.path, entry.before);
        return updated;
      }
      return m;
    }),
  };
}

// 处理 UPDATE 重做
function handleUpdateRedo(state: SceneState, entry: HistoryEntry) {
  return {
    models: state.models.map((m) => {
      if (m.id === entry.id) {
        const updated = deepClone(m);
        setObjectValue(updated, entry.path, entry.after);
        return updated;
      }
      return m;
    }),
  };
}

// 处理 ADD 撤销
function handleAddUndo(state: SceneState, entry: HistoryEntry) {
  return {
    models: state.models.filter((m) => m.id !== entry.id),
    selectedObjectUuid: state.selectedObjectUuid === entry.id ? null : state.selectedObjectUuid,
  };
}

// 处理 ADD 重做
function handleAddRedo(state: SceneState, entry: HistoryEntry) {
  return {
    models: [...state.models, entry.after],
  };
}

// 处理 DELETE 撤销
function handleDeleteUndo(state: SceneState, entry: HistoryEntry) {
  return {
    models: [...state.models, entry.before],
  };
}

// 处理 DELETE 重做
function handleDeleteRedo(state: SceneState, entry: HistoryEntry) {
  return {
    models: state.models.filter((m) => m.id !== entry.id),
    selectedObjectUuid: state.selectedObjectUuid === entry.id ? null : state.selectedObjectUuid,
  };
}
