import * as THREE from 'three';

/**
 * Helper function to check if a mesh should be excluded from decal operations
 * This ensures decals are only applied to actual model meshes, not helper objects
 * like TransformControls, selection boxes, floor, or other gizmos.
 */
export const shouldExcludeMesh = (child: THREE.Mesh): boolean => {
  // Skip floor
  if (child.name === 'Floor') return true;
  
  // Skip decals
  if (child.userData.isDecal) return true;
  
  // Skip selection boxes (yellow wireframe around selected objects)
  if (child.userData.isSelectionBox) return true;
  if (child.name === 'selection-box') return true;
  if (child.parent?.name === 'selection-box') return true;
  
  // Skip any helper objects
  if (child.name && child.name.includes('helper')) return true;
  if (child.name && child.name.startsWith('decal-')) return true;
  
  // Skip objects with no geometry
  if (!child.geometry) return true;
  
  // Skip TransformControls related objects by checking the object itself
  if ((child as any).type === 'TransformControls') return true;
  if (child.name && child.name.toLowerCase().includes('transform')) return true;
  
  // Check all ancestors for TransformControls or selection boxes
  let ancestor = child.parent;
  while (ancestor) {
    // Check for TransformControls
    if ((ancestor as any).type === 'TransformControls') return true;
    if ((ancestor as any).isTransformControls) return true;
    if (ancestor.name && ancestor.name.toLowerCase().includes('transform')) return true;
    if (ancestor.constructor.name === 'TransformControls') return true;
    
    // Check for selection boxes
    if ((ancestor as any).userData?.isSelectionBox) return true;
    if (ancestor.name === 'selection-box') return true;
    
    ancestor = ancestor.parent;
  }
  
  // Skip specific geometry types that are typically gizmos or selection boxes
  const geoType = child.geometry.type;
  const gizmoGeometries = ['ConeGeometry', 'CylinderGeometry', 'TorusGeometry', 'TorusKnotGeometry', 'OctahedronGeometry'];
  if (gizmoGeometries.includes(geoType)) {
    // Check if any ancestor is TransformControls
    let parent = child.parent;
    while (parent) {
      if ((parent as any).isTransformControls || 
          (parent as any).type === 'TransformControls' ||
          parent.constructor.name === 'TransformControls') {
        return true;
      }
      parent = parent.parent;
    }
  }
  
  return false;
};
