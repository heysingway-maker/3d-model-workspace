/**
 * 通用属性路径解析器
 * 支持点符号路径（如 "position.x", "material.roughness"）
 */

/**
 * 获取对象指定路径的值
 * @param obj 目标对象
 * @param path 点符号路径
 * @returns 路径对应的值
 */
export function getObjectValue(obj: any, path: string): any {
  const keys = path.split('.');
  let current = obj;

  for (const key of keys) {
    if (current == null || typeof current !== 'object') {
      return undefined;
    }
    current = current[key];
  }

  return current;
}

/**
 * 设置对象指定路径的值
 * @param obj 目标对象
 * @param path 点符号路径
 * @param value 要设置的值
 * @returns 修改后的对象
 */
export function setObjectValue(obj: any, path: string, value: any): any {
  const keys = path.split('.');
  let current = obj;

  // 遍历到倒数第二层
  for (let i = 0; i < keys.length - 1; i++) {
    const key = keys[i];
    if (current[key] == null || typeof current[key] !== 'object') {
      // 如果路径不存在，创建空对象
      current[key] = {};
    }
    current = current[key];
  }

  // 设置最后一层的值
  const lastKey = keys[keys.length - 1];
  current[lastKey] = value;

  return obj;
}

/**
 * 深度克隆对象
 * @param obj 要克隆的对象
 * @returns 克隆后的对象
 */
export function deepClone<T>(obj: T): T {
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }

  if (obj instanceof Date) {
    return new Date(obj.getTime()) as any;
  }

  if (obj instanceof Array) {
    return obj.map((item) => deepClone(item)) as any;
  }

  if (obj instanceof Object) {
    const clonedObj = {} as any;
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        clonedObj[key] = deepClone(obj[key]);
      }
    }
    return clonedObj;
  }

  return obj;
}

/**
 * 比较两个值是否相等
 * @param a 值 a
 * @param b 值 b
 * @returns 是否相等
 */
export function isEqual(a: any, b: any): boolean {
  if (a === b) return true;

  if (typeof a !== typeof b) return false;
  if (a === null || b === null) return a === b;

  if (Array.isArray(a) && Array.isArray(b)) {
    if (a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) {
      if (!isEqual(a[i], b[i])) return false;
    }
    return true;
  }

  if (typeof a === 'object') {
    const keysA = Object.keys(a);
    const keysB = Object.keys(b);

    if (keysA.length !== keysB.length) return false;

    for (const key of keysA) {
      if (!keysB.includes(key) || !isEqual(a[key], b[key])) {
        return false;
      }
    }
    return true;
  }

  return false;
}
